"""Blender 4.5 headless refinement for GLB Generator Pro v5.1.1 Real Detail.

Run with:
  blender -b --factory-startup --python refine_glb.py -- /path/to/manifest.json

The pipeline is deliberately self-contained and uses only Blender's bundled Python.
"""
from __future__ import annotations

import json
import math
import os
import sys
import traceback
from pathlib import Path

import bpy
import bmesh
from mathutils import Vector


BODY_VIEWS = {
    "front": Vector((0.0, -1.0, 0.0)),
    "front_45": Vector((1.0, -1.0, 0.0)).normalized(),
    "right": Vector((1.0, 0.0, 0.0)),
    "back": Vector((0.0, 1.0, 0.0)),
    "back_45": Vector((-1.0, 1.0, 0.0)).normalized(),
    "left": Vector((-1.0, 0.0, 0.0)),
}
FACE_VIEWS = {
    "face_front": BODY_VIEWS["front"],
    "face_45": BODY_VIEWS["front_45"],
    "face_left_45": Vector((-1.0, -1.0, 0.0)).normalized(),
    "face_right_45": Vector((1.0, -1.0, 0.0)).normalized(),
    "face_left_profile": BODY_VIEWS["left"],
    "face_right_profile": BODY_VIEWS["right"],
}
DETAIL_VIEWS = {
    "left_hand": BODY_VIEWS["front"],
    "right_hand": BODY_VIEWS["front"],
    "hair_detail": BODY_VIEWS["front"],
    "clothes_detail": BODY_VIEWS["front"],
}


def emit(stage: str, progress: int, message: str):
    print(f"GLB_PROGRESS|{stage}|{progress}|{message}", flush=True)


def load_manifest() -> dict:
    if "--" not in sys.argv:
        raise RuntimeError("Manifest argument missing")
    args = sys.argv[sys.argv.index("--") + 1 :]
    if not args:
        raise RuntimeError("Manifest path missing")
    return json.loads(Path(args[0]).read_text(encoding="utf-8"))


def reset_scene():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    for datablocks in (bpy.data.meshes, bpy.data.materials, bpy.data.cameras, bpy.data.lights):
        for block in list(datablocks):
            if block.users == 0:
                datablocks.remove(block)


def import_and_join(path: str):
    reset_scene()
    bpy.ops.import_scene.gltf(filepath=path)
    meshes = [obj for obj in bpy.context.scene.objects if obj.type == "MESH"]
    if not meshes:
        raise RuntimeError("Input GLB contains no mesh objects")
    bpy.ops.object.select_all(action="DESELECT")
    for obj in meshes:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    if len(meshes) > 1:
        bpy.ops.object.join()
    obj = bpy.context.view_layer.objects.active
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    return obj


def cleanup_mesh(obj):
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    if not bm.verts or not bm.faces:
        bm.free()
        raise RuntimeError("Input mesh is empty")
    xs = [v.co.x for v in bm.verts]
    ys = [v.co.y for v in bm.verts]
    zs = [v.co.z for v in bm.verts]
    extent = max(max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs), 1e-6)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=extent * 1e-6)
    bmesh.ops.dissolve_degenerate(bm, dist=extent * 1e-8, edges=list(bm.edges))
    loose = [v for v in bm.verts if not v.link_faces]
    if loose:
        bmesh.ops.delete(bm, geom=loose, context="VERTS")
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()
    for poly in mesh.polygons:
        poly.use_smooth = True


def _fill_open_boundaries(obj, max_edges: int = 4096):
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    boundary_edges = [e for e in bm.edges if e.is_boundary]
    if boundary_edges:
        try:
            bmesh.ops.holes_fill(bm, edges=boundary_edges[:max_edges], sides=0)
        except Exception:
            pass
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.to_mesh(mesh)
    bm.free()
    mesh.update()


def strip_materials_for_geometry(obj):
    """Release imported PBR/image memory before dense geometry processing."""
    try:
        obj.data.materials.clear()
    except Exception:
        pass
    for material in list(bpy.data.materials):
        if material.users == 0:
            bpy.data.materials.remove(material)
    for image in list(bpy.data.images):
        if image.users == 0:
            bpy.data.images.remove(image)


def memory_safe_boundary_seal(obj):
    """Seal open boundaries without voxelizing or duplicating the provider mesh."""
    _fill_open_boundaries(obj, max_edges=32768)
    cleanup_mesh(obj)
    return obj


def optional_watertight_pass(obj, *, shell_thickness_ratio: float = 1.0 / 850.0, voxel_resolution_divisor: float = 560.0, smoothing_passes: int = 1):
    """Create one closed outer shell without adding a second inner Solidify skin.

    The previous Solidify + Voxel combination doubled surfaces and memory and could
    expose dark internal layers. A voxel remesh already produces a closed volume,
    so Pro Fidelity now hole-fills first, remeshes one shell, then restores detail.
    """
    corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    extent = max(
        max(v.x for v in corners) - min(v.x for v in corners),
        max(v.y for v in corners) - min(v.y for v in corners),
        max(v.z for v in corners) - min(v.z for v in corners),
        1e-6,
    )
    _fill_open_boundaries(obj)
    remesh = obj.modifiers.new(name='ProWatertightRemesh', type='REMESH')
    if hasattr(remesh, 'mode'):
        remesh.mode = 'VOXEL'
    if hasattr(remesh, 'voxel_size'):
        # Clamp 1 GB workers to a high-detail but bounded voxel grid. The later
        # shrinkwrap restores the source silhouette/details without a 760^3 peak.
        divisor = max(320.0, min(float(voxel_resolution_divisor), 620.0))
        remesh.voxel_size = max(extent / divisor, extent / 900.0)
    elif hasattr(remesh, 'octree_depth'):
        remesh.octree_depth = 9
    if hasattr(remesh, 'use_remove_disconnected'):
        remesh.use_remove_disconnected = False
    if hasattr(remesh, 'use_smooth_shade'):
        remesh.use_smooth_shade = True
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.modifier_apply(modifier=remesh.name)

    for idx in range(max(0, int(smoothing_passes))):
        smooth = obj.modifiers.new(name=f'ProSmooth{idx}', type='SMOOTH')
        smooth.iterations = 3
        smooth.factor = 0.18
        bpy.ops.object.modifier_apply(modifier=smooth.name)
    cleanup_mesh(obj)


def optional_voxel_remesh(obj):
    corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    extent = max(
        max(v.x for v in corners) - min(v.x for v in corners),
        max(v.y for v in corners) - min(v.y for v in corners),
        max(v.z for v in corners) - min(v.z for v in corners),
        1e-6,
    )
    modifier = obj.modifiers.new(name="ProVoxelRemesh", type="REMESH")
    if hasattr(modifier, "mode"):
        modifier.mode = "VOXEL"
    if hasattr(modifier, "voxel_size"):
        modifier.voxel_size = extent / 520.0
    elif hasattr(modifier, "octree_depth"):
        modifier.octree_depth = 9
    if hasattr(modifier, "use_smooth_shade"):
        modifier.use_smooth_shade = True
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.modifier_apply(modifier=modifier.name)
    cleanup_mesh(obj)


def duplicate_detail_target(obj):
    target = obj.copy()
    target.data = obj.data.copy()
    target.name = "ProDetailTarget"
    bpy.context.collection.objects.link(target)
    target.hide_render = True
    target.hide_set(True)
    return target


def restore_detail_from_target(obj, target):
    if target is None:
        return
    bpy.context.view_layer.objects.active = obj
    modifier = obj.modifiers.new(name="ProDetailRestore", type="SHRINKWRAP")
    modifier.target = target
    modifier.wrap_method = "NEAREST_SURFACEPOINT"
    if hasattr(modifier, "wrap_mode"):
        modifier.wrap_mode = "ON_SURFACE"
    modifier.offset = 0.0
    bpy.ops.object.modifier_apply(modifier=modifier.name)
    cleanup_mesh(obj)
    bpy.data.objects.remove(target, do_unlink=True)


def bounds(obj):
    verts = [v.co.copy() for v in obj.data.vertices]
    xmin, xmax = min(v.x for v in verts), max(v.x for v in verts)
    ymin, ymax = min(v.y for v in verts), max(v.y for v in verts)
    zmin, zmax = min(v.z for v in verts), max(v.z for v in verts)
    return xmin, xmax, ymin, ymax, zmin, zmax


def projection_params(direction: Vector, b):
    xmin, xmax, ymin, ymax, zmin, zmax = b
    center = Vector(((xmin + xmax) * 0.5, (ymin + ymax) * 0.5, (zmin + zmax) * 0.5))
    up = Vector((0.0, 0.0, 1.0))
    right = up.cross(direction).normalized()
    corners = [Vector((x, y, z)) for x in (xmin, xmax) for y in (ymin, ymax) for z in (zmin, zmax)]
    horizontal = max(abs((c - center).dot(right)) for c in corners) * 2.0
    height = max(zmax - zmin, 1e-6)
    return center, right, max(horizontal, 1e-6), height


def _region_vertex_candidate(point: Vector, b, region_type: str | None) -> bool:
    if not region_type:
        return True
    xmin, xmax, ymin, ymax, zmin, zmax = b
    width = max(xmax - xmin, 1e-6)
    height = max(zmax - zmin, 1e-6)
    cx = (xmin + xmax) * 0.5
    nx = (point.x - cx) / (width * 0.5)
    nz = (point.z - zmin) / height
    if region_type == "left_hand":
        return nx < -0.72 and 0.62 <= nz <= 0.85
    if region_type == "right_hand":
        return nx > 0.72 and 0.62 <= nz <= 0.85
    if region_type == "hair_detail":
        return nz >= 0.86 and abs(nx) <= 0.56
    if region_type == "clothes_detail":
        return 0.34 <= nz <= 0.78 and abs(nx) <= 0.68
    return True


def _fit_projection_to_candidates(candidates, center, right, horizontal, height, *, min_horizontal: float, min_height: float):
    if len(candidates) < 6:
        return center, horizontal, height
    hs = [(p - center).dot(right) for p in candidates]
    zs = [p.z for p in candidates]
    hmin, hmax = min(hs), max(hs)
    zmin, zmax = min(zs), max(zs)
    center = center + right * ((hmin + hmax) * 0.5)
    center.z = (zmin + zmax) * 0.5
    horizontal = max((hmax - hmin) * 1.14, min_horizontal)
    height = max((zmax - zmin) * 1.14, min_height)
    return center, horizontal, height


def compute_projection_fit(obj, direction: Vector, *, face_crop=False, image_crop=None, region_type: str | None = None):
    """Compute one per-view camera fit; no UV layers are allocated.

    Ultra Detail can receive 16 views, but Blender/glTF only need *one* UV0
    atlas. Allocating all 16 UV layers exceeded Blender's UV layer cap.
    """
    mesh = obj.data
    b = bounds(obj)
    xmin, xmax, ymin, ymax, zmin, zmax = b
    center, right, horizontal, height = projection_params(direction, b)
    if face_crop:
        body_width = max(xmax - xmin, ymax - ymin, 1e-6)
        face_candidates = []
        for vertex in mesh.vertices:
            p = vertex.co
            if p.z < zmin + height * 0.84:
                continue
            horizontal_offset = abs((p - center).dot(right))
            if horizontal_offset <= body_width * 0.24:
                face_candidates.append(p.copy())
        if len(face_candidates) >= 8:
            horizontal_values = [(p - center).dot(right) for p in face_candidates]
            hmin, hmax = min(horizontal_values), max(horizontal_values)
            z_face_min, z_face_max = min(p.z for p in face_candidates), max(p.z for p in face_candidates)
            center = center + right * ((hmin + hmax) * 0.5)
            center.z = (z_face_min + z_face_max) * 0.5
            horizontal = max((hmax - hmin) * 1.10, body_width * 0.20)
            height = max((z_face_max - z_face_min) * 1.08, height * 0.12)
        else:
            center.z = zmin + height * 0.91
            horizontal = body_width * 0.30
            height = height * 0.19
    elif region_type:
        body_width = max(xmax - xmin, ymax - ymin, 1e-6)
        body_height = max(zmax - zmin, 1e-6)
        candidates = [v.co.copy() for v in mesh.vertices if _region_vertex_candidate(v.co, b, region_type)]
        center, horizontal, height = _fit_projection_to_candidates(
            candidates, center, right, horizontal, height,
            min_horizontal=body_width * (0.12 if "hand" in region_type else 0.24),
            min_height=body_height * (0.10 if "hand" in region_type else 0.16),
        )

    crop_left, crop_top, crop_right, crop_bottom = image_crop or (0.0, 0.0, 1.0, 1.0)
    crop_left = max(0.0, min(1.0, float(crop_left)))
    crop_top = max(0.0, min(1.0, float(crop_top)))
    crop_right = max(crop_left + 1e-4, min(1.0, float(crop_right)))
    crop_bottom = max(crop_top + 1e-4, min(1.0, float(crop_bottom)))
    crop_v_min = 1.0 - crop_bottom
    crop_v_max = 1.0 - crop_top

    return (center, right, horizontal, height,
            crop_left, crop_right, crop_v_min, crop_v_max)


def calculate_projection_uv(point: Vector, fit):
    center, right, horizontal, height, left, right_limit, v_min, v_max = fit
    base_u = 0.5 + (point - center).dot(right) / max(horizontal, 1e-6)
    base_v = 0.5 + (point.z - center.z) / max(height, 1e-6)
    return (left + base_u * (right_limit - left), v_min + base_v * (v_max - v_min))


def make_uv_layer(obj, name: str, direction: Vector, *, face_crop=False, image_crop=None, region_type: str | None = None):
    """Compatibility path for separate materials and manual Texture Studio."""
    mesh = obj.data
    layer = mesh.uv_layers.get(name) or mesh.uv_layers.new(name=name)
    fit = compute_projection_fit(obj, direction, face_crop=face_crop,
                                 image_crop=image_crop, region_type=region_type)
    for poly in mesh.polygons:
        for loop_index in poly.loop_indices:
            point = mesh.vertices[mesh.loops[loop_index].vertex_index].co
            layer.data[loop_index].uv = calculate_projection_uv(point, fit)
    return layer


def _cap_loaded_image(image, max_size: int):
    """Bound decoded texture memory before glTF export.

    Blender's GLB exporter may temporarily hold extra image buffers while encoding.
    Keeping every phone photo at its original 12-50 MP resolution can therefore
    exceed a 1 GB worker even when Cycles baking is disabled.
    """
    if max_size <= 0:
        return image
    width, height = int(image.size[0]), int(image.size[1])
    longest = max(width, height, 1)
    if longest > max_size:
        ratio = max_size / float(longest)
        image.scale(max(1, int(width * ratio)), max(1, int(height * ratio)))
    return image


def create_projection_material(name: str, image_path: str, uv_name: str, max_size: int, *, pbr: dict | None = None, pbr_max_size: int | None = None):
    mat = bpy.data.materials.new(name=f"Photo_{name}")
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    out = nodes.new("ShaderNodeOutputMaterial")
    shader = nodes.new("ShaderNodeBsdfPrincipled")
    tex = nodes.new("ShaderNodeTexImage")
    uv = nodes.new("ShaderNodeUVMap")
    uv.uv_map = uv_name
    tex.image = _cap_loaded_image(bpy.data.images.load(image_path, check_existing=True), max_size)
    tex.extension = "EXTEND"
    tex.interpolation = "Linear"
    shader.inputs["Roughness"].default_value = 0.50 if name.startswith("face_") or name.endswith("_hand") else 0.56
    shader.inputs["Metallic"].default_value = 0.0
    links.new(uv.outputs["UV"], tex.inputs["Vector"])
    links.new(tex.outputs["Color"], shader.inputs["Base Color"])

    pbr = pbr or {}
    pbr_cap = int(pbr_max_size or max_size)
    rough_path = pbr.get("roughness")
    if rough_path and Path(rough_path).exists():
        rough = nodes.new("ShaderNodeTexImage")
        rough.image = _cap_loaded_image(bpy.data.images.load(str(rough_path), check_existing=True), pbr_cap)
        rough.image.colorspace_settings.name = "Non-Color"
        rough.extension = "EXTEND"
        links.new(uv.outputs["UV"], rough.inputs["Vector"])
        links.new(rough.outputs["Color"], shader.inputs["Roughness"])

    normal_path = pbr.get("normal")
    if normal_path and Path(normal_path).exists():
        normal_tex = nodes.new("ShaderNodeTexImage")
        normal_tex.image = _cap_loaded_image(bpy.data.images.load(str(normal_path), check_existing=True), pbr_cap)
        normal_tex.image.colorspace_settings.name = "Non-Color"
        normal_tex.extension = "EXTEND"
        normal = nodes.new("ShaderNodeNormalMap")
        normal.inputs["Strength"].default_value = 0.72 if name.startswith("face_") else (0.78 if name.endswith("_hand") else 0.58)
        links.new(uv.outputs["UV"], normal_tex.inputs["Vector"])
        links.new(normal_tex.outputs["Color"], normal.inputs["Color"])
        links.new(normal.outputs["Normal"], shader.inputs["Normal"])

    if "Alpha" in shader.inputs:
        shader.inputs["Alpha"].default_value = 1.0
    try:
        mat.diffuse_color[3] = 1.0
    except Exception:
        pass
    links.new(shader.outputs["BSDF"], out.inputs["Surface"])
    return mat




def create_atlas_material(atlas: dict):
    """One glTF-compatible PBR material shared by all projected facets.

    R,G,B of ORM are occlusion, roughness and metallic. Explicitly keep each
    channel Non-Color; accidental sRGB decoding corrupts PBR values.
    """
    mat = bpy.data.materials.new(name="PBR_Photo_Atlas")
    mat.use_nodes = True
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    nodes.clear()
    output = nodes.new('ShaderNodeOutputMaterial')
    shader = nodes.new('ShaderNodeBsdfPrincipled')
    shader.inputs['Metallic'].default_value = 0.0
    shader.inputs['Roughness'].default_value = 0.75
    uv = nodes.new('ShaderNodeUVMap')
    uv.uv_map = 'UV_PBR_Atlas'
    color = nodes.new('ShaderNodeTexImage')
    color.image = bpy.data.images.load(str(atlas['albedo']), check_existing=True)
    color.image.colorspace_settings.name = 'sRGB'
    color.extension = 'EXTEND'
    normal_tex = nodes.new('ShaderNodeTexImage')
    normal_tex.image = bpy.data.images.load(str(atlas['normal']), check_existing=True)
    normal_tex.image.colorspace_settings.name = 'Non-Color'
    normal_tex.extension = 'EXTEND'
    normal_map = nodes.new('ShaderNodeNormalMap')
    normal_map.space = 'TANGENT'
    normal_map.uv_map = 'UV_PBR_Atlas'
    normal_map.inputs['Strength'].default_value = 0.35
    orm = nodes.new('ShaderNodeTexImage')
    orm.image = bpy.data.images.load(str(atlas['orm']), check_existing=True)
    orm.image.colorspace_settings.name = 'Non-Color'
    orm.extension = 'EXTEND'
    channels = nodes.new('ShaderNodeSeparateColor')
    channels.mode = 'RGB'
    for node in (color, normal_tex, orm):
        links.new(uv.outputs['UV'], node.inputs['Vector'])
    links.new(color.outputs['Color'], shader.inputs['Base Color'])
    links.new(normal_tex.outputs['Color'], normal_map.inputs['Color'])
    links.new(normal_map.outputs['Normal'], shader.inputs['Normal'])
    links.new(orm.outputs['Color'], channels.inputs['Color'])
    links.new(channels.outputs['Green'], shader.inputs['Roughness'])
    links.new(channels.outputs['Blue'], shader.inputs['Metallic'])
    # Blender's glTF exporter recognises the glTF Settings node group when
    # it is present, and encodes the red AO channel as occlusionTexture.
    try:
        group = bpy.data.node_groups.get('glTF Settings')
        if group is None:
            group = bpy.data.node_groups.new('glTF Settings', 'ShaderNodeTree')
            group.interface.new_socket(name='Occlusion', in_out='INPUT', socket_type='NodeSocketFloat')
        settings_node = nodes.new('ShaderNodeGroup')
        settings_node.node_tree = group
        links.new(channels.outputs['Red'], settings_node.inputs['Occlusion'])
    except (AttributeError, RuntimeError, TypeError, KeyError):
        pass  # Neutral AO is 1.0, so omission is safe.
    links.new(shader.outputs['BSDF'], output.inputs['Surface'])
    return mat


def apply_pbr_atlas_uv(obj, assigned_views: dict, atlas: dict, projection_fits: dict):
    """Project directly to a single UV0 atlas without creating 16 UV maps."""
    mesh = obj.data
    rects = atlas.get('rects', {})
    available = {key: fit for key, fit in projection_fits.items() if key in rects}
    if not available:
        return False
    # Imported UVs were associated with old provider materials, which are
    # discarded by this process. Clear them to enforce one canonical UV0.
    for old in list(mesh.uv_layers):
        mesh.uv_layers.remove(old)
    atlas_uv = mesh.uv_layers.new(name='UV_PBR_Atlas')
    first = 'front' if 'front' in available else next(iter(available))
    for poly in mesh.polygons:
        key = assigned_views.get(poly.index, first)
        if key not in available:
            key = first
        fit = available[key]
        u0, v0, u1, v1 = rects[key]
        du, dv = u1 - u0, v1 - v0
        for loop_index in poly.loop_indices:
            point = mesh.vertices[mesh.loops[loop_index].vertex_index].co
            u, v = calculate_projection_uv(point, fit)
            atlas_uv.data[loop_index].uv = (
                u0 + du * max(0.0, min(1.0, u)),
                v0 + dv * max(0.0, min(1.0, v)),
            )
    mesh.uv_layers.active = atlas_uv
    mesh.materials.clear()
    mesh.materials.append(create_atlas_material(atlas))
    for poly in mesh.polygons:
        poly.material_index = 0
    mesh.update()
    return True


def is_face_zone(point: Vector, b) -> bool:
    xmin, xmax, ymin, ymax, zmin, zmax = b
    width_x = max(xmax - xmin, 1e-6)
    width_y = max(ymax - ymin, 1e-6)
    height = max(zmax - zmin, 1e-6)
    cx = (xmin + xmax) * 0.5
    cy = (ymin + ymax) * 0.5
    head_half_extent = max(width_x, width_y) * 0.25
    return (
        point.z >= zmin + height * 0.84
        and abs(point.x - cx) <= head_half_extent
        and abs(point.y - cy) <= head_half_extent * 1.25
    )



def is_hand_zone(point: Vector, b, side: str) -> bool:
    xmin, xmax, _ymin, _ymax, zmin, zmax = b
    width = max(xmax - xmin, 1e-6)
    height = max(zmax - zmin, 1e-6)
    cx = (xmin + xmax) * 0.5
    nx = (point.x - cx) / (width * 0.5)
    nz = (point.z - zmin) / height
    if side == "left":
        return nx < -0.72 and 0.62 <= nz <= 0.85
    return nx > 0.72 and 0.62 <= nz <= 0.85


def is_hair_zone(point: Vector, b) -> bool:
    xmin, xmax, _ymin, _ymax, zmin, zmax = b
    width = max(xmax - xmin, 1e-6)
    height = max(zmax - zmin, 1e-6)
    cx = (xmin + xmax) * 0.5
    nx = abs((point.x - cx) / (width * 0.5))
    nz = (point.z - zmin) / height
    return nz >= 0.86 and nx <= 0.58


def is_clothing_zone(point: Vector, b) -> bool:
    xmin, xmax, _ymin, _ymax, zmin, zmax = b
    width = max(xmax - xmin, 1e-6)
    height = max(zmax - zmin, 1e-6)
    cx = (xmin + xmax) * 0.5
    nx = abs((point.x - cx) / (width * 0.5))
    nz = (point.z - zmin) / height
    return 0.34 <= nz <= 0.78 and nx <= 0.68


def adaptive_feature_subdivide(obj, *, hq_max_triangles: int, face_budget: int, hand_budget: int, clothing_budget: int, hair_budget: int = 0):
    """Increase local sampling around face/hands/clothing without inventing anatomy.

    New vertices are interpolated on the provider surface; this preserves existing
    geometry while giving high-value regions more triangles for smooth projection.
    """
    current = triangle_count(obj)
    if current >= hq_max_triangles * 0.92:
        return current
    b = bounds(obj)
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    candidates = []
    for edge in bm.edges:
        mid = (edge.verts[0].co + edge.verts[1].co) * 0.5
        if is_face_zone(mid, b) or is_hand_zone(mid, b, "left") or is_hand_zone(mid, b, "right") or is_clothing_zone(mid, b) or is_hair_zone(mid, b):
            candidates.append(edge)
    if not candidates:
        bm.free()
        return current
    gap = max(0, hq_max_triangles - current)
    requested = max(0, int(face_budget) + int(hand_budget) + int(clothing_budget) + int(hair_budget))
    # One edge subdivision may add multiple triangles. Stay deliberately below
    # the remaining triangle gap and below a 1 GB-safe edge count.
    edge_limit = min(len(candidates), max(1000, min(45000, gap // 3, requested // 4 if requested else 12000)))
    if edge_limit < len(candidates):
        stride = max(1, len(candidates) // edge_limit)
        candidates = candidates[::stride][:edge_limit]
    try:
        bmesh.ops.subdivide_edges(bm, edges=candidates, cuts=1, use_grid_fill=True)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.to_mesh(obj.data)
    finally:
        bm.free()
    obj.data.update()
    for poly in obj.data.polygons:
        poly.use_smooth = True
    return triangle_count(obj)

def assign_photo_materials(
    obj,
    images: dict[str, str],
    *,
    body_max_size: int,
    face_max_size: int,
    hand_max_size: int | None = None,
    pbr_maps: dict[str, dict[str, str]] | None = None,
    projection_atlas: dict | None = None,
    pbr_max_size: int | None = None,
    projection_crops: dict[str, list[float]] | None = None,
    face_projection_crops: dict[str, list[float]] | None = None,
    force_texture_coverage: bool = False,
):
    original_material_count = len(obj.data.materials)
    view_materials = {}
    projection_fits = {}
    pbr_maps = pbr_maps or {}
    atlas = projection_atlas or {}
    use_atlas = bool(atlas.get("rects") and all(Path(atlas.get(k, "")).is_file() for k in ("albedo", "normal", "orm")))
    view_defs = {**BODY_VIEWS, **FACE_VIEWS, **DETAIL_VIEWS}
    for name, direction in view_defs.items():
        path = images.get(name)
        if not path or not Path(path).exists():
            continue
        uv_name = f"UV_{name}"
        is_face = name.startswith("face_")
        region_type = name if name in DETAIL_VIEWS else None
        crop = ((face_projection_crops or {}).get(name) if is_face else None) or (projection_crops or {}).get(name)
        if use_atlas:
            projection_fits[name] = compute_projection_fit(
                obj, direction, face_crop=is_face, image_crop=crop, region_type=region_type)
        else:
            make_uv_layer(obj, uv_name, direction, face_crop=is_face,
                          image_crop=crop, region_type=region_type)
        max_size = face_max_size if is_face else ((hand_max_size or body_max_size) if name.endswith("_hand") else body_max_size)
        if use_atlas:
            # Assign a temporary integer ID to track which source view colors
            # each polygon; do not instantiate 12 separate GPU materials.
            if name not in atlas['rects']:
                continue
            view_materials[name] = len(view_materials)
        else:
            mat = create_projection_material(
                name, path, uv_name, max_size,
                pbr=pbr_maps.get(name), pbr_max_size=pbr_max_size,
            )
            obj.data.materials.append(mat)
            view_materials[name] = len(obj.data.materials) - 1
    if not view_materials:
        return False

    b = bounds(obj)
    body_candidates = [name for name in BODY_VIEWS if name in view_materials]
    face_candidates = [name for name in FACE_VIEWS if name in view_materials]
    if not body_candidates:
        body_candidates = [name for name in view_materials if name not in DETAIL_VIEWS]

    assigned_views = {}
    for poly in obj.data.polygons:
        n = poly.normal.normalized()

        # Close-up face references are accepted only on the matching front-facing / side-facing head hemisphere.
        if face_candidates and is_face_zone(poly.center, b):
            face_best = max(face_candidates, key=lambda key: n.dot(FACE_VIEWS[key])
                            + (0.075 if key == 'face_front' else 0.0))
            face_score = n.dot(FACE_VIEWS[face_best])
            if face_score >= 0.20:
                poly.material_index = view_materials[face_best]
                assigned_views[poly.index] = face_best
                continue

        if "left_hand" in view_materials and is_hand_zone(poly.center, b, "left") and n.dot(BODY_VIEWS["front"]) >= -0.08:
            poly.material_index = view_materials["left_hand"]
            assigned_views[poly.index] = "left_hand"
            continue
        if "right_hand" in view_materials and is_hand_zone(poly.center, b, "right") and n.dot(BODY_VIEWS["front"]) >= -0.08:
            poly.material_index = view_materials["right_hand"]
            assigned_views[poly.index] = "right_hand"
            continue
        if "hair_detail" in view_materials and is_hair_zone(poly.center, b) and n.dot(BODY_VIEWS["front"]) >= -0.30:
            poly.material_index = view_materials["hair_detail"]
            assigned_views[poly.index] = "hair_detail"
            continue
        if "clothes_detail" in view_materials and is_clothing_zone(poly.center, b) and n.dot(BODY_VIEWS["front"]) >= 0.05:
            poly.material_index = view_materials["clothes_detail"]
            assigned_views[poly.index] = "clothes_detail"
            continue

        if body_candidates:
            body_best = max(body_candidates, key=lambda key: n.dot(BODY_VIEWS[key])
                            + (0.08 if key in ('front', 'back', 'left', 'right') else 0.0))
            body_score = n.dot(BODY_VIEWS[body_best])
            threshold = 0.08 if force_texture_coverage else 0.20
            if body_score >= threshold or original_material_count == 0 or force_texture_coverage or use_atlas:
                poly.material_index = view_materials[body_best]
                assigned_views[poly.index] = body_best
                continue
    if use_atlas:
        return apply_pbr_atlas_uv(obj, assigned_views, atlas, projection_fits)
    return True


def _normalized_point(point: Vector, b):
    xmin, xmax, ymin, ymax, zmin, zmax = b
    wx = max(xmax - xmin, 1e-6)
    wy = max(ymax - ymin, 1e-6)
    h = max(zmax - zmin, 1e-6)
    nx = (point.x - xmin) / wx
    ny = (point.y - ymin) / wy
    nz = (point.z - zmin) / h
    sx = (point.x - (xmin + xmax) * 0.5) / (wx * 0.5)
    return nx, ny, nz, sx


def _region_matches(region: str, point: Vector, normal: Vector, b, spec: dict) -> bool:
    nx, _ny, nz, sx = _normalized_point(point, b)
    absx = abs(sx)
    left = sx < 0.0
    right = not left
    front_score = normal.normalized().dot(BODY_VIEWS["front"])
    back_score = normal.normalized().dot(BODY_VIEWS["back"])
    feather = max(0.0, min(0.5, float(spec.get("feather", 0.0) or 0.0)))
    pad = feather * 0.12

    rules = {
        "face": nz >= 0.84 - pad and absx <= 0.34 + pad,
        "head": nz >= 0.80 - pad and absx <= 0.48 + pad,
        "neck": 0.74 - pad <= nz <= 0.84 + pad and absx <= 0.30 + pad,
        "chest_upper": 0.65 - pad <= nz <= 0.78 + pad and absx <= 0.54 + pad and front_score >= -0.15,
        "chest_lower": 0.55 - pad <= nz <= 0.67 + pad and absx <= 0.50 + pad and front_score >= -0.15,
        "abdomen": 0.45 - pad <= nz <= 0.58 + pad and absx <= 0.46 + pad and front_score >= -0.20,
        "pelvis": 0.34 - pad <= nz <= 0.48 + pad and absx <= 0.52 + pad,
        "back_upper": 0.60 - pad <= nz <= 0.78 + pad and absx <= 0.56 + pad and back_score >= -0.10,
        "back_lower": 0.43 - pad <= nz <= 0.62 + pad and absx <= 0.50 + pad and back_score >= -0.10,
        "shoulder_left": 0.66 - pad <= nz <= 0.79 + pad and left and 0.35 - pad <= absx <= 0.78 + pad,
        "shoulder_right": 0.66 - pad <= nz <= 0.79 + pad and right and 0.35 - pad <= absx <= 0.78 + pad,
        "upper_arm_left": 0.64 - pad <= nz <= 0.83 + pad and left and 0.37 - pad <= absx <= 0.70 + pad,
        "upper_arm_right": 0.64 - pad <= nz <= 0.83 + pad and right and 0.37 - pad <= absx <= 0.70 + pad,
        "forearm_left": 0.64 - pad <= nz <= 0.84 + pad and left and 0.62 - pad <= absx <= 0.88 + pad,
        "forearm_right": 0.64 - pad <= nz <= 0.84 + pad and right and 0.62 - pad <= absx <= 0.88 + pad,
        "hand_left": 0.64 - pad <= nz <= 0.86 + pad and left and absx >= 0.82 - pad,
        "hand_right": 0.64 - pad <= nz <= 0.86 + pad and right and absx >= 0.82 - pad,
        "thigh_left": 0.16 - pad <= nz <= 0.40 + pad and left and 0.06 <= absx <= 0.58 + pad,
        "thigh_right": 0.16 - pad <= nz <= 0.40 + pad and right and 0.06 <= absx <= 0.58 + pad,
        "calf_left": 0.04 <= nz <= 0.22 + pad and left and 0.04 <= absx <= 0.62 + pad,
        "calf_right": 0.04 <= nz <= 0.22 + pad and right and 0.04 <= absx <= 0.62 + pad,
        "foot_left": nz <= 0.09 + pad and left,
        "foot_right": nz <= 0.09 + pad and right,
    }
    matched = bool(rules.get(region, False))
    if not matched:
        return False

    xmin = spec.get("x_min")
    xmax = spec.get("x_max")
    zmin = spec.get("z_min")
    zmax = spec.get("z_max")
    if xmin is not None and nx < float(xmin):
        return False
    if xmax is not None and nx > float(xmax):
        return False
    if zmin is not None and nz < float(zmin):
        return False
    if zmax is not None and nz > float(zmax):
        return False
    return True


def _transform_uv_layer(layer, *, offset_x, offset_y, scale_x, scale_y, rotation_deg, mirror_x, mirror_y):
    scale_x = max(0.05, float(scale_x))
    scale_y = max(0.05, float(scale_y))
    angle = math.radians(float(rotation_deg))
    ca, sa = math.cos(angle), math.sin(angle)
    for item in layer.data:
        u, v = float(item.uv.x), float(item.uv.y)
        u = (u - 0.5) / scale_x
        v = (v - 0.5) / scale_y
        if mirror_x:
            u = -u
        if mirror_y:
            v = -v
        ru = u * ca - v * sa
        rv = u * sa + v * ca
        item.uv = (0.5 + ru + float(offset_x), 0.5 + rv + float(offset_y))


def assign_manual_regions(
    obj,
    manual_regions: list[dict],
    *,
    body_max_size: int,
    face_max_size: int,
):
    if not manual_regions:
        return 0
    b = bounds(obj)
    applied = 0
    for index, spec in enumerate(manual_regions):
        image_path = str(spec.get("image_path") or "")
        if not image_path or not Path(image_path).exists():
            continue
        region = str(spec.get("region") or "")
        direction_name = str(spec.get("direction") or "front")
        direction = BODY_VIEWS.get(direction_name, BODY_VIEWS["front"])
        uv_name = f"UV_manual_{index}_{region}"[:63]
        layer = make_uv_layer(
            obj,
            uv_name,
            direction,
            face_crop=(region == "face"),
            image_crop=None,
        )
        _transform_uv_layer(
            layer,
            offset_x=spec.get("offset_x", 0.0),
            offset_y=spec.get("offset_y", 0.0),
            scale_x=spec.get("scale_x", 1.0),
            scale_y=spec.get("scale_y", 1.0),
            rotation_deg=spec.get("rotation_deg", 0.0),
            mirror_x=bool(spec.get("mirror_x", False)),
            mirror_y=bool(spec.get("mirror_y", False)),
        )
        max_size = face_max_size if region == "face" else body_max_size
        mat = create_projection_material(f"manual_{index}_{region}", image_path, uv_name, max_size)
        opacity = max(0.0, min(1.0, float(spec.get("opacity", 1.0) or 1.0)))
        if mat.use_nodes:
            for node in mat.node_tree.nodes:
                if node.type == "BSDF_PRINCIPLED" and "Alpha" in node.inputs:
                    node.inputs["Alpha"].default_value = opacity
                    break
        try:
            mat.diffuse_color[3] = opacity
        except Exception:
            pass
        obj.data.materials.append(mat)
        material_index = len(obj.data.materials) - 1
        direction_threshold = -0.10 if region in {"head", "neck", "pelvis"} else 0.02
        region_count = 0
        for poly in obj.data.polygons:
            normal = poly.normal.normalized()
            if normal.dot(direction) < direction_threshold:
                continue
            if _region_matches(region, poly.center, normal, b, spec):
                poly.material_index = material_index
                region_count += 1
        if region_count:
            applied += 1
    return applied



def triangle_count(obj) -> int:
    return sum(max(1, len(poly.vertices) - 2) for poly in obj.data.polygons)


def limit_triangles(obj, max_triangles: int, label: str):
    triangles = triangle_count(obj)
    if max_triangles <= 0 or triangles <= max_triangles:
        return triangles
    modifier = obj.modifiers.new(name=label, type="DECIMATE")
    modifier.decimate_type = "COLLAPSE"
    modifier.ratio = max(0.01, min(1.0, max_triangles / float(triangles)))
    if hasattr(modifier, "use_collapse_triangulate"):
        modifier.use_collapse_triangulate = True
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.modifier_apply(modifier=modifier.name)
    cleanup_mesh(obj)
    return triangle_count(obj)

def export_glb(filepath: Path):
    filepath.parent.mkdir(parents=True, exist_ok=True)
    bpy.ops.export_scene.gltf(
        filepath=str(filepath), export_format="GLB", export_apply=True,
        export_texcoords=True, export_normals=True, export_materials="EXPORT",
        export_image_format="AUTO", export_jpeg_quality=95,
    )
    if not filepath.exists() or filepath.stat().st_size < 4:
        raise RuntimeError(f"GLB export failed: {filepath}")


def optimize_preview(obj, preview_size: int, max_triangles: int):
    # HQ is exported first. Preview then reuses the same materials at 1K and a
    # much smaller mesh. Never pack images here: packing duplicates buffers.
    seen = set()
    for mat in obj.data.materials:
        if not mat or not mat.use_nodes:
            continue
        for node in mat.node_tree.nodes:
            if node.type != "TEX_IMAGE" or node.image is None:
                continue
            image = node.image
            key = image.as_pointer()
            if key in seen:
                continue
            seen.add(key)
            _cap_loaded_image(image, preview_size)
    return limit_triangles(obj, max_triangles, "PreviewDecimate")


def main():
    manifest = load_manifest()
    base_glb = Path(manifest["base_glb"])
    preview_glb = Path(manifest["preview_glb"])
    high_quality_glb = Path(manifest["high_quality_glb"])
    quality_mode = str(manifest.get("quality_mode", "pro_hq"))
    memory_profile = str(manifest.get("memory_profile", "1gb")).lower()
    body_max_size = int(manifest.get("projection_body_max_size", 1536 if memory_profile == "1gb" else 2048))
    face_max_size = int(manifest.get("projection_face_max_size", 2304 if memory_profile == "1gb" else 3072))
    hand_max_size = int(manifest.get("projection_hand_max_size", min(face_max_size, 2048)))
    pbr_max_size = int(manifest.get("pbr_map_max_size", min(face_max_size, 2048)))
    hq_max_triangles = int(manifest.get("hq_max_triangles", 150000 if memory_profile == "1gb" else 300000))
    shell_thickness_ratio = float(manifest.get("shell_thickness_ratio", 1.0 / 850.0))
    voxel_resolution_divisor = float(manifest.get("voxel_resolution_divisor", 760.0))
    smoothing_passes = int(manifest.get("smoothing_passes", 2))
    watertight_pass = bool(manifest.get("watertight_pass", quality_mode in {"pro_fidelity", "ultra_detail"}))
    watertight_strategy = str(manifest.get("watertight_strategy", "voxel")).lower()
    preview_size = min(int(manifest.get("preview_texture_size", 2048)), 1024 if memory_profile == "1gb" else 1536)
    preview_triangles = int(manifest.get("preview_max_triangles", 60000 if memory_profile == "1gb" else 100000))
    if memory_profile == "1gb":
        preview_triangles = min(preview_triangles, 60000)
    images = dict(manifest.get("images") or {})
    projection_crops = dict(manifest.get("projection_crops") or {})
    texture_mode = str(manifest.get("texture_mode", "auto")).lower()
    manual_regions = list(manifest.get("manual_regions") or [])
    face_projection_crops = dict(manifest.get("face_projection_crops") or {})
    force_texture_coverage = bool(manifest.get("force_texture_coverage", quality_mode in {"pro_fidelity", "ultra_detail"}))
    pbr_maps = dict(manifest.get("pbr_maps") or {})
    projection_atlas = dict(manifest.get("projection_atlas") or {})
    multiview_baking = bool(manifest.get('multiview_baking', False))
    multiview_images = dict(manifest.get('multiview_images') or {})
    multiview_landmarks = dict(manifest.get('multiview_landmarks') or {})
    multiview_bake_size = int(manifest.get('multiview_bake_size', 1024))
    strict_projection = bool(manifest.get('strict_projection', True))

    def aligned_surface_bake(obj):
        # Loaded lazily because geometry-only jobs must not initialize 500MB
        # of photo/baking state. Run inside Blender, not the FastAPI process.
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        from multiview_baker import bake_aligned_multiview
        out_dir = Path(high_quality_glb).parent / 'surface_bake_v540'
        _, metrics = bake_aligned_multiview(
            obj, multiview_images, out_dir, atlas_size=multiview_bake_size,
            landmarks=multiview_landmarks, require_calibration=strict_projection,
            pixel_visibility=True,
            create_material=create_atlas_material, progress=emit,
        )
        emit('texture_baking', 87, f"Surface texture bake coverage: {metrics['valid_pixels']} texels / {metrics['mesh_covered_pixels']} UV texels")
    feature_subdivide = bool(manifest.get("feature_subdivide", False))
    face_subdivide_budget = int(manifest.get("face_subdivide_budget", 0))
    hand_subdivide_budget = int(manifest.get("hand_subdivide_budget", 0))
    clothing_subdivide_budget = int(manifest.get("clothing_subdivide_budget", 0))
    hair_subdivide_budget = int(manifest.get("hair_subdivide_budget", 0))

    pipeline_stage = str(manifest.get("pipeline_stage", "full")).lower()

    if pipeline_stage == "geometry":
        stage_geometry_glb = Path(manifest["stage_geometry_glb"])
        emit("watertight_repair", 64, "Geometry stage: importing provider mesh")
        obj = import_and_join(str(base_glb))
        cleanup_mesh(obj)
        strip_materials_for_geometry(obj)
        restore_detail = bool(manifest.get("restore_detail", True))
        detail_target = duplicate_detail_target(obj) if watertight_pass and restore_detail else None
        if watertight_pass:
            if watertight_strategy == "boundary_seal":
                emit("watertight_repair", 70, "Geometry stage: sealing boundaries while preserving original surface detail")
                memory_safe_boundary_seal(obj)
            else:
                emit("watertight_repair", 70, "Geometry stage: closing holes with a single memory-safe voxel shell")
                optional_watertight_pass(
                    obj,
                    shell_thickness_ratio=shell_thickness_ratio,
                    voxel_resolution_divisor=voxel_resolution_divisor,
                    smoothing_passes=smoothing_passes,
                )
            if detail_target is not None:
                emit("geometry_refinement", 78, "Geometry stage: restoring source surface detail")
                restore_detail_from_target(obj, detail_target)
        if feature_subdivide:
            emit("geometry_refinement", 82, "Geometry stage: adaptively subdividing face, hands and clothing regions")
            adaptive_feature_subdivide(
                obj,
                hq_max_triangles=hq_max_triangles,
                face_budget=face_subdivide_budget,
                hand_budget=hand_subdivide_budget,
                clothing_budget=clothing_subdivide_budget,
                hair_budget=hair_subdivide_budget,
            )
        before = triangle_count(obj)
        after = limit_triangles(obj, hq_max_triangles, "HQMemoryGuard")
        emit("geometry_refinement", 86, f"Geometry stage mesh: {before} -> {after} triangles")
        export_glb(stage_geometry_glb)
        emit("completed", 99, "Geometry stage completed")
        return

    if pipeline_stage == "hq":
        emit("texture_baking", 72, "HQ stage: importing repaired geometry")
        obj = import_and_join(str(base_glb))
        cleanup_mesh(obj)
        if multiview_baking and texture_mode in {"auto", "hybrid"}:
            aligned_surface_bake(obj)
        elif images and texture_mode in {"auto", "hybrid"}:
            assigned = assign_photo_materials(
                obj,
                images,
                body_max_size=body_max_size,
                face_max_size=face_max_size,
                hand_max_size=hand_max_size,
                pbr_maps=pbr_maps,
            projection_atlas=projection_atlas,
                pbr_max_size=pbr_max_size,
                projection_crops=projection_crops,
                face_projection_crops=face_projection_crops,
                force_texture_coverage=force_texture_coverage,
            )
            if assigned:
                emit("texture_baking", 86, f"HQ stage textures applied: body <= {body_max_size}px, face <= {face_max_size}px, views={len(images)}")
        if manual_regions and texture_mode in {"manual", "hybrid"}:
            applied = assign_manual_regions(obj, manual_regions, body_max_size=body_max_size, face_max_size=face_max_size)
            emit("texture_baking", 90, f"HQ manual regions applied: {applied}/{len(manual_regions)}")
        export_glb(high_quality_glb)
        emit("completed", 99, "HQ texture stage completed")
        return

    if pipeline_stage == "preview":
        emit("optimizing_preview", 86, "Preview stage: importing HQ model")
        obj = import_and_join(str(base_glb))
        cleanup_mesh(obj)
        optimize_preview(obj, preview_size, preview_triangles)
        export_glb(preview_glb)
        emit("completed", 99, "Preview stage completed")
        return

    # A 1 GB Blender worker cannot safely hold eight decoded phone photos while
    # exporting a dense Hunyuan mesh. Keep all six body directions plus two face closeups after preprocessing;
    # edge-filled crops are substantially smaller than raw phone photographs.
    if memory_profile == "1gb":
        safe_keys = {"front", "back", "left", "right", "front_45", "back_45", "face_front", "face_45"}
        images = {k: v for k, v in images.items() if k in safe_keys}

    emit("refining", 61, "Importing and validating provider geometry")
    obj = import_and_join(str(base_glb))
    cleanup_mesh(obj)
    detail_target = duplicate_detail_target(obj) if watertight_pass and quality_mode in {"pro_fidelity", "ultra_detail"} else None
    if watertight_pass:
        emit("watertight_repair", 66, "Applying fuller watertight shell and voxel remesh")
        optional_watertight_pass(obj, shell_thickness_ratio=shell_thickness_ratio, voxel_resolution_divisor=voxel_resolution_divisor, smoothing_passes=smoothing_passes)
        if detail_target is not None:
            emit("geometry_refinement", 68, "Restoring provider surface detail onto repaired watertight topology")
            restore_detail_from_target(obj, detail_target)
            detail_target = None
    elif manifest.get("remesh"):
        emit("refining", 66, "Applying high-density voxel remesh")
        optional_voxel_remesh(obj)

    if feature_subdivide:
        emit("geometry_refinement", 69, "Adaptively subdividing face, hands and clothing regions")
        adaptive_feature_subdivide(
            obj,
            hq_max_triangles=hq_max_triangles,
            face_budget=face_subdivide_budget,
            hand_budget=hand_subdivide_budget,
            clothing_budget=clothing_subdivide_budget,
            hair_budget=hair_subdivide_budget,
        )
    before = triangle_count(obj)
    after = limit_triangles(obj, hq_max_triangles, "HQMemoryGuard")
    emit("refining", 70, f"HQ mesh memory guard: {before} -> {after} triangles")

    if multiview_baking and texture_mode in {"auto", "hybrid"}:
        emit('texture_baking', 73, 'Calibrating view cameras and baking occlusion-tested UV atlas')
        aligned_surface_bake(obj)
    elif images and texture_mode in {"auto", "hybrid"}:
        emit("texture_baking", 73, "Projecting cleaned multi-view and face photographs")
        assigned = assign_photo_materials(
            obj,
            images,
            body_max_size=body_max_size,
            face_max_size=face_max_size,
            hand_max_size=hand_max_size,
            pbr_maps=pbr_maps,
            projection_atlas=projection_atlas,
            pbr_max_size=pbr_max_size,
            projection_crops=projection_crops,
            face_projection_crops=face_projection_crops,
            force_texture_coverage=force_texture_coverage,
        )
        if assigned:
            emit(
                "texture_baking",
                78,
                f"1GB-safe textures / Pro Fidelity projection: body <= {body_max_size}px, face <= {face_max_size}px, views={len(images)}",
            )

    if manual_regions and texture_mode in {"manual", "hybrid"}:
        emit("texture_baking", 81, "Applying manual body-region texture overrides")
        applied = assign_manual_regions(
            obj,
            manual_regions,
            body_max_size=body_max_size,
            face_max_size=face_max_size,
        )
        emit("texture_baking", 86, f"Manual Texture Studio regions applied: {applied}/{len(manual_regions)}")

    emit("validation", 88, "Exporting validated high-quality GLB")
    export_glb(high_quality_glb)
    emit("optimizing_preview", 93, "Creating lightweight preview without Cycles bake")
    optimize_preview(obj, preview_size, preview_triangles)
    export_glb(preview_glb)
    emit("completed", 99, "Blender refinement completed")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        sys.exit(2)
