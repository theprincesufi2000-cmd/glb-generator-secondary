"""Geometry-aware orthographic photo baking for Blender 4.5.

One UV unwrap is used for all PBR images. Multi-view source weighting is done
per texel, with actual BVH-ray tests at each candidate polygon's centroid.
An optional calibrated 2D/3D landmark map refines camera scale and position;
without such landmarks silhouette alignment is approximate. This script does
not hallucinate data on unseen surfaces or infer measured BRDFs from RGB.
"""
from __future__ import annotations
import os
import sys
import struct
import zlib
from pathlib import Path

import bpy
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree

# Blender runs this file as a sibling module of refine_glb.py.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.multiview_core import (DIRECTIONS, camera_basis, calibrate_orthographic,
                                barycentric_pixels, project_points, sample_rgba_bilinear,
                                seam_dilate)
from app.strict_projection import validate_calibration, choose_consistent_color


def _read_rgba(path: Path, max_dim: int = 2048):
    image = bpy.data.images.load(str(path), check_existing=False)
    try:
        width, height = image.size
        raw = np.empty(width * height * 4, dtype=np.float32)
        image.pixels.foreach_get(raw)
        rgba = raw.reshape((height, width, 4))[::-1].copy()
        # Blender stores sample data as scene-linear for sRGB textures. Bring
        # source pixels back to display/sRGB, which is the PNG export encoding.
        rgb = np.clip(rgba[:, :, :3], 0., 1.)
        rgba[:, :, :3] = np.where(rgb <= .0031308, 12.92 * rgb,
                                  1.055 * np.power(rgb, 1. / 2.4) - .055)
        # Eagerly free oversized source images after baking.
        if max(width, height) > max_dim:
            stride = max(1, int(np.ceil(max(width, height) / max_dim)))
            rgba = rgba[::stride, ::stride].copy()
        return rgba
    finally:
        bpy.data.images.remove(image)


def _write_png(path: Path, rgb: np.ndarray):
    """Write exact display RGB PNG from NumPy without external Pillow deps."""
    pixels = np.clip(rgb * 255. + .5, 0, 255).astype(np.uint8)
    height, width = pixels.shape[:2]
    def chunk(name, data):
        return struct.pack('>I', len(data)) + name + data + struct.pack('>I', zlib.crc32(name + data) & 0xffffffff)
    path.parent.mkdir(parents=True, exist_ok=True)
    compressor = zlib.compressobj(level=6)
    with path.open('wb') as out:
        out.write(b'\x89PNG\r\n\x1a\n')
        out.write(chunk(b'IHDR', struct.pack('>2I5B', width, height, 8, 2, 0, 0, 0)))
        compressed = bytearray()
        for line in pixels:
            compressed.extend(compressor.compress(b'\x00' + line.tobytes()))
            if len(compressed) > 512 * 1024:
                out.write(chunk(b'IDAT', bytes(compressed)))
                compressed.clear()
        compressed.extend(compressor.flush())
        if compressed:
            out.write(chunk(b'IDAT', bytes(compressed)))
        out.write(chunk(b'IEND', b''))


def _uv_unwrap(obj, atlas_size: int):
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    mesh = obj.data
    for uv in list(mesh.uv_layers):
        mesh.uv_layers.remove(uv)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    try:
        # 2% of UV space separates islands for 8-12px seam expansion;
        # complexity and chart count remain Blender's responsibility.
        bpy.ops.uv.smart_project(island_margin=max(.004, 10.0 / atlas_size),
                                 correct_aspect=True)
    finally:
        bpy.ops.object.mode_set(mode='OBJECT')
    if not mesh.uv_layers:
        raise RuntimeError('Blender UV unwrap produced no UV coordinates')
    uv = mesh.uv_layers.active
    uv.name = 'UV_PBR_Atlas'
    uv.active_render = True
    return uv


def _triangle_iterator(mesh, uv):
    """Use Blender triangulation while retaining each original loop's UVs."""
    mesh.calc_loop_triangles()
    for tri in mesh.loop_triangles:
        loops = list(tri.loops)
        xyz = np.array([mesh.vertices[mesh.loops[i].vertex_index].co[:] for i in loops], dtype=np.float32)
        t_uv = np.array([uv.data[i].uv[:] for i in loops], dtype=np.float32)
        normal = np.cross(xyz[1] - xyz[0], xyz[2] - xyz[0])
        length = np.linalg.norm(normal)
        if length < 1e-8:
            continue
        yield xyz, t_uv, normal / length


def _region_weights(name: str, centroid, bound):
    """Strict geometric masks stop facial close-ups from reaching clothing."""
    lo, hi = bound
    height = max(float(hi[2]-lo[2]), 1e-6)
    width = max(float(hi[0]-lo[0]), 1e-6)
    z = float((centroid[2]-lo[2])/height)
    x = abs(float((centroid[0]-(lo[0]+hi[0])*.5) / width))
    if name.startswith('face_'):
        return 3.0 if z >= .845 and x < .21 else 0.
    if name == 'hair_detail':
        return 3.0 if z >= .91 else 0.
    if name == 'clothes_detail':
        return 1.8 if .36 <= z <= .80 and x < .38 else 0.
    if name in ('left_hand', 'right_hand'):
        side = -1 if name.startswith('left') else 1
        center_x = float((lo[0] + hi[0]) * .5)
        return 2.8 if z >= .64 and z <= .83 and (centroid[0] - center_x)*side > width*.36 else 0.
    # Suppress general body photos in face zone when calibrated face photos
    # exist; otherwise leave fallback possible through geometric masking.
    return 1.0


def _visible_from_view(bvh, centroid, normal, direction, extent):
    """Hard BVH visibility test from the viewing direction towards a facet."""
    if float(np.dot(normal, direction)) <= .06:
        return False
    camera_side = Vector((float(direction[0]), float(direction[1]), float(direction[2])))
    center = Vector((float(centroid[0]), float(centroid[1]), float(centroid[2])))
    # Cast from safely outside towards the surface. The first hit must be the
    # candidate itself; back surfaces and occluded folds are rejected.
    hit, _, _, _ = bvh.ray_cast(center + camera_side * (extent * 2.0),
                               -camera_side, extent * 3.0)
    return hit is not None and (hit - center).length <= extent * .004


def bake_aligned_multiview(obj, paths: dict, output_dir: Path, *,
                           atlas_size: int = 1536, landmarks: dict | None = None,
                           create_material=None, progress=None,
                           require_calibration=True, pixel_visibility=True):
    """Bake all photos to one UV0 PBR set, rejecting visible background pixels.

    Returns a dict compatible with refine_glb.create_atlas_material().
    """
    if create_material is None:
        raise ValueError('A glTF-compatible material factory is required')
    usable = {key: Path(path) for key, path in paths.items()
              if key in DIRECTIONS and Path(path).is_file()}
    if not usable:
        raise ValueError('No valid multiview photographs')
    atlas_size = max(256, min(4096, int(atlas_size)))
    uv = _uv_unwrap(obj, atlas_size)
    mesh = obj.data
    all_xyz = np.asarray([v.co[:] for v in mesh.vertices], dtype=np.float32)
    lo, hi = all_xyz.min(axis=0), all_xyz.max(axis=0)
    bound = (lo, hi)
    extent = float(np.max(hi-lo))
    head_xyz = all_xyz[(all_xyz[:, 2] >= lo[2] + .845 * (hi[2] - lo[2])) &
                       (np.abs(all_xyz[:, 0] - (lo[0]+hi[0])*.5) < .22 * (hi[0]-lo[0]))]
    if len(head_xyz) < 20:
        head_xyz = all_xyz
    loaded = {}
    calibration_checks = {}
    for name, path in usable.items():
        data = _read_rgba(path)
        alpha = data[:, :, 3]
        if np.count_nonzero(alpha > .25) < 12:
            continue
        target_xyz = head_xyz if name.startswith('face_') else all_xyz
        supplied = (landmarks or {}).get(name, [])
        check = validate_calibration(target_xyz, data, name, supplied,
                                     face=name.startswith('face_'))
        calibration_checks[name] = check.as_dict()
        if require_calibration and not check.accepted:
            # Do not bake a silhouette-aligned approximation and call it HQ.
            output_dir.mkdir(parents=True, exist_ok=True)
            import json
            (output_dir / 'calibration_report.json').write_text(json.dumps(calibration_checks, indent=2))
            raise RuntimeError('UNVERIFIED_GEOMETRY: ' + name + ': ' + check.reason)
        cam = calibrate_orthographic(target_xyz, alpha, name, landmarks=supplied,
                                    face=name.startswith('face_'))
        loaded[name] = {'rgba': data, 'cam': cam,
                        'direction': cam[1], 'face': name.startswith('face_')}
    if require_calibration and any(name not in loaded for name in ('front', 'back', 'left', 'right')):
        raise RuntimeError('Missing one or more obligatory calibrated body views')
    if not loaded:
        raise RuntimeError('All source images are fully transparent')
    bvh = BVHTree.FromObject(obj, bpy.context.evaluated_depsgraph_get())
    accum = np.zeros((atlas_size, atlas_size, 3), dtype=np.float32)
    weight = np.zeros((atlas_size, atlas_size), dtype=np.float32)
    ambiguous_pixels = np.zeros((atlas_size, atlas_size), dtype=bool)
    source_confidence = np.zeros((atlas_size, atlas_size), dtype=np.float32)
    overlapped_uv_pixels = np.zeros((atlas_size, atlas_size), dtype=bool)
    coverage = np.zeros((atlas_size, atlas_size), dtype=bool)
    tris = list(_triangle_iterator(mesh, uv))
    has_face_reference = any(name.startswith('face_') for name in loaded)
    micro_triangles = 0
    total_triangles = 0

    for idx, (xyz, t_uv, normal) in enumerate(tris):
        # Quantify whether this unwrap can resolve facial and fabric detail.
        d1 = t_uv[1] - t_uv[0]
        d2 = t_uv[2] - t_uv[0]
        area_px2 = abs(float(d1[0]*d2[1] - d1[1]*d2[0])) * (atlas_size * atlas_size * .5)
        total_triangles += 1
        micro_triangles += int(area_px2 < 2.0)
        raster = barycentric_pixels(t_uv, atlas_size)
        if raster is None:
            continue
        px, py, bary = raster
        overlapped_uv_pixels[py, px] |= coverage[py, px]
        coverage[py, px] = True
        centroid = xyz.mean(axis=0)
        # Per-face rays prevent hidden surfaces from receiving photo detail.
        candidates = []
        for name, entry in loaded.items():
            region_weight = _region_weights(name, centroid, bound)
            if has_face_reference and not name.startswith('face_') and float(centroid[2] - lo[2]) / max(float(hi[2]-lo[2]), 1e-6) > .86:
                region_weight *= .12
            if region_weight <= 0.:
                continue
            face_dot = float(np.dot(normal, entry['direction']))
            if face_dot < .12:
                continue
            if not _visible_from_view(bvh, centroid, normal,
                                      entry['direction'], extent):
                continue
            candidates.append((entry, region_weight * face_dot**3))
        if not candidates:
            continue
        world_points = bary @ xyz
        # All candidates are projected at the actual UV texel barycentric point.
        # Centroid visibility is only an early rejection; strict mode re-tests
        # the same surface at the texel itself (occlusion on folds and edges).
        candidate_samples = []
        candidate_weights = []
        for entry, camera_weight in candidates:
            uv_src = project_points(world_points, entry['cam'])
            sample = sample_rgba_bilinear(entry['rgba'], uv_src)
            w = np.where(sample[:, 3] >= .35,
                         camera_weight * sample[:, 3]**2, 0.).astype(np.float32)
            if not np.any(w):
                continue
            if pixel_visibility:
                indices = np.flatnonzero(w > .00001)
                visible = np.zeros(len(w), dtype=bool)
                for k in indices:
                    visible[k] = _visible_from_view(
                        bvh, world_points[k], normal, entry['direction'], extent)
                w[~visible] = 0.
            candidate_samples.append(sample)
            candidate_weights.append(w)
        if candidate_samples:
            rgb, accepted, ambiguous, conf = choose_consistent_color(
                candidate_samples, candidate_weights)
            accum[py, px] += rgb * accepted[:, None]
            weight[py, px] += accepted.astype(np.float32)
            ambiguous_pixels[py, px] |= ambiguous
            source_confidence[py, px] = np.maximum(source_confidence[py, px], conf)
        if progress is not None and idx % 30000 == 0:
            progress('texture_baking', 80, f'Visible multiview texels: {idx}/{len(tris)}')
    valid = (weight > 1e-7) & ~ambiguous_pixels
    albedo = np.full((atlas_size, atlas_size, 3), .62, dtype=np.float32)
    albedo[valid] = accum[valid] / weight[valid, None]
    # Unknown UV texels get neutral color rather than an unverified black.
    # Pad UV island gutters. This fills only nearby texels, never recreates
    # invisible anatomy or fabric details.
    albedo, _ = seam_dilate(albedo, valid, iterations=8)
    normal = np.empty_like(albedo)
    normal[:] = (.5, .5, 1.)
    orm = np.empty_like(albedo)
    orm[:] = (1., .76, 0.)  # AO neutral, roughness conservative, metallic 0
    output_dir.mkdir(parents=True, exist_ok=True)
    paths_out = {key: output_dir / f'baked_{key}.png' for key in ('albedo', 'normal', 'orm')}
    _write_png(paths_out['albedo'], albedo)
    _write_png(paths_out['normal'], normal)
    _write_png(paths_out['orm'], orm)
    # Explicit QA image: green = observed; red = contradictory views;
    # gray = UV texels with no trustworthy photograph.
    diagnostic = np.zeros_like(albedo)
    diagnostic[:] = (.06, .09, .13)
    diagnostic[coverage] = (.36, .36, .36)
    diagnostic[valid] = (.1, .73, .2)
    diagnostic[ambiguous_pixels & coverage] = (.96, .16, .13)
    _write_png(output_dir / 'uv_observation_confidence.png', diagnostic)
    mesh.materials.clear()
    mesh.materials.append(create_material({k: str(v) for k, v in paths_out.items()}))
    for face in mesh.polygons:
        face.material_index = 0
    mesh.update()
    from app.bake_quality import assess_bake_metrics
    metrics = {'valid_pixels': int(valid.sum()), 'mesh_covered_pixels': int(coverage.sum()),
               'views_loaded': list(loaded), 'atlas_size': atlas_size,
               'triangle_count': total_triangles,
               'sub_2px_triangle_count': micro_triangles,
               'conflicting_texels': int(np.count_nonzero(ambiguous_pixels & coverage)),
               'overlapping_uv_texels': int(np.count_nonzero(overlapped_uv_pixels)),
               'strict_projection': bool(require_calibration),
               'calibration_verified': bool(require_calibration and
                                            all(c['accepted'] for c in calibration_checks.values())),
               'calibration': calibration_checks,
               'visibility_mode': 'per_texel_bvh' if pixel_visibility else 'face_centroid',
               'unobserved_texels': int(np.count_nonzero(coverage & ~valid))}
    quality = assess_bake_metrics(metrics)
    metrics.update(quality)
    (output_dir / 'bake_metrics.json').write_text(__import__('json').dumps(metrics, indent=2))
    if not quality['quality_ok']:
        raise RuntimeError('PHOTO_BAKE_QUALITY_FAILED: ' + '; '.join(quality['issues']) +
                           '. Increase GLB_MULTIVIEW_BAKE_SIZE or provide matched 2D/3D landmarks; do not release this GLB as High Quality.')
    return {k: str(v) for k, v in paths_out.items()}, metrics
