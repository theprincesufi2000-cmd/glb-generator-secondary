import numpy as np
from app.bake_quality import assess_bake_metrics
from app.multiview_core import sample_rgba_bilinear


def test_reject_uploaded_glb_density_and_coverage():
    outcome = assess_bake_metrics({'mesh_covered_pixels': 377278,
                                   'valid_pixels': 350600,
                                   'triangle_count': 320000,
                                   'sub_2px_triangle_count': 294495})
    assert not outcome['quality_ok']
    assert outcome['covered_ratio'] < .95
    assert outcome['sub_2px_triangle_fraction'] > .9


def test_allow_resolved_uv_with_full_photo_coverage():
    outcome = assess_bake_metrics({'mesh_covered_pixels': 100000,
                                   'valid_pixels': 98000,
                                   'triangle_count': 320000,
                                   'sub_2px_triangle_count': 30000})
    assert outcome['quality_ok']


def test_alpha_interpolation_prevents_black_halo():
    img = np.array([[[1.,0.,0.,1.],[0.,0.,0.,0.]]], dtype=np.float32)
    result = sample_rgba_bilinear(img, np.array([[.5,.5]]))
    assert abs(result[0,0] - 1.) < .01
    assert abs(result[0,3] - .5) < .01
    assert result[0,1] == 0


def test_outside_image_cannot_clamp_edge_color():
    img = np.ones((2,2,4), dtype=np.float32)
    result = sample_rgba_bilinear(img, np.array([[-.01,.5],[.5,1.01]]))
    assert np.all(result == 0)
