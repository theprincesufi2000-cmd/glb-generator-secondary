"""v5.2.8 PBR-albedo/normal/ORM shared-UV regression tests."""
from pathlib import Path

from PIL import Image, ImageDraw

from app.texture_atlas import build_projection_atlas
from app.imagefit import estimate_projection_crop


def test_all_atlas_channels_share_pixel_layout_and_nonblack_values(tmp_path: Path):
    palette = {'front': (17, 165, 192), 'back': (20, 70, 162),
               'right': (186, 94, 67), 'face_front': (211, 151, 121),
               'left': (85, 63, 42)}
    sources = {}
    for name, rgb in palette.items():
        file = tmp_path / f'{name}.png'
        Image.new('RGB', (130, 320), rgb).save(file)
        sources[name] = file
    atlas = build_projection_atlas(sources, tmp_path/'maps', max_size=1024)
    rects = atlas['rects']
    assert set(rects) == set(palette)
    with Image.open(atlas['albedo']) as color, Image.open(atlas['normal']) as normal, Image.open(atlas['orm']) as orm:
        assert color.size == normal.size == orm.size
        for key, rect in rects.items():
            u0,v0,u1,v1 = rect
            assert 0 <= u0 < u1 <= 1
            assert 0 <= v0 < v1 <= 1
            sx = int(color.width * (u0+u1)/2)
            sy = int(color.height * (1-(v0+v1)/2))
            assert color.getpixel((sx,sy)) == palette[key]
            nx,ny,nz = normal.getpixel((sx,sy))
            assert 116 <= nx <= 140 and 116 <= ny <= 140 and nz >= 254
            ao,rough,metallic = orm.getpixel((sx,sy))
            assert ao == 255 and 150 <= rough <= 220 and metallic == 0


def test_atlas_gracefully_falls_back_for_bad_image(tmp_path: Path):
    broken = tmp_path/'broken.jpg'
    broken.write_bytes(b'not an image')
    assert build_projection_atlas({'front': broken}, tmp_path/'atlases', max_size=512) == {}


def test_wall_floor_background_does_not_scale_shoes_to_floor(tmp_path: Path):
    image = Image.new('RGB', (320, 640), (150, 146, 136))
    draw = ImageDraw.Draw(image)
    draw.rectangle((0,500,319,639), fill=(205,201,189))
    draw.ellipse((132,95,188,190), fill=(118,73,51))
    draw.rectangle((118,180,201,350), fill=(30,176,166))
    draw.rectangle((20,203,300,215), fill=(188,124,104))
    draw.rectangle((125,350,152,554), fill=(95,73,115))
    draw.rectangle((170,350,197,554), fill=(95,73,115))
    path = tmp_path/'floor.png'
    image.save(path)
    x0,y0,x1,y1 = estimate_projection_crop(path)
    assert y1 < 0.90
    assert x0 < 0.17 and x1 > 0.83


def test_blender_atlas_uses_shared_uv_and_packed_orm():
    script = (Path(__file__).resolve().parents[1]/'blender'/'refine_glb.py').read_text()
    assert 'UV_PBR_Atlas' in script
    assert 'def apply_pbr_atlas_uv' in script
    assert "links.new(channels.outputs['Green'], shader.inputs['Roughness'])" in script
    assert "links.new(channels.outputs['Blue'], shader.inputs['Metallic'])" in script
    assert 'projection_atlas=projection_atlas' in script
