import numpy as np
from app.multiview_core import project_points, camera_basis
from app.strict_projection import validate_calibration, choose_consistent_color, validate_multiview_request
from app.bake_quality import assess_bake_metrics


def make_points():
    # Viewfront projection u=.25*x+.5 v=-.2*z+.75; x and z vary well.
    world=np.array([[-1,0,0.2],[-.5,0,2],[.3,0,.5],[1,0,1.4],[.7,0,3],[-.9,0,2.7],[0,0,1.8]])
    _,right=camera_basis('front')
    uv=np.column_stack((.25*(world@right)+.5,-.2*world[:,2]+.75))
    return world,[dict(world_xyz=a.tolist(),image_uv=b.tolist()) for a,b in zip(world,uv)]


def test_sufficient_correspondences_pass_and_provide_pixel_residual():
    xyz,landmarks=make_points()
    img=np.ones((512,512,4),dtype=np.float32)
    result=validate_calibration(xyz,img,'front',landmarks)
    assert result.accepted, result
    assert result.rms_px<.01
    assert result.max_px<.01


def test_missing_landmarks_fail_closed():
    xyz,_=make_points()
    c=validate_calibration(xyz,np.ones((512,512,4)), 'front',[])
    assert not c.accepted and 'CALIBRATION_REQUIRED' in c.reason
    assert validate_multiview_request(dict.fromkeys(('front','back','left','right')), {})


def test_misplaced_2d_landmark_rejected_even_with_five_others():
    xyz,landmarks=make_points()
    landmarks[3]['image_uv']=[.01,.99]
    verdict=validate_calibration(xyz,np.ones((512,512,4)), 'front',landmarks)
    assert not verdict.accepted
    assert 'ALIGNMENT_ERROR' in verdict.reason


def test_poorly_distributed_landmarks_rejected():
    xyz,points=make_points()
    for a in points: a['image_uv'][0]=.52
    v=validate_calibration(xyz,np.ones((512,512,4)), 'front',points)
    assert not v.accepted and 'span' in v.reason


def test_multiview_color_conflict_wont_ghost():
    a=np.array([[1,0,0,1],[.3,.4,.5,1]],dtype=np.float32)
    b=np.array([[0,0,1,1],[.31,.41,.51,1]],dtype=np.float32)
    colors,valid,conflict,conf=choose_consistent_color([a,b],[np.ones(2),np.ones(2)])
    assert conflict[0] and not valid[0]
    assert valid[1] and not conflict[1]
    assert np.allclose(colors[1],b[1,:3],atol=.02)


def test_strict_bake_gate_checks_uv_and_view_ambiguity():
    base=dict(strict_projection=True,valid_pixels=99000,mesh_covered_pixels=100000,
              triangle_count=1000,sub_2px_triangle_count=10,calibration_verified=True,
              visibility_mode='per_texel_bvh',conflicting_texels=900,overlapping_uv_texels=0)
    v=assess_bake_metrics(base)
    assert not v['quality_ok'] and any('Photometric' in i for i in v['issues'])
    base['conflicting_texels']=0
    assert assess_bake_metrics(base)['quality_ok']
    base['calibration_verified']=False
    assert not assess_bake_metrics(base)['quality_ok']


def test_blender_baker_integrates_strict_ray_checks():
    from pathlib import Path
    script=(Path(__file__).parents[1]/'blender'/'multiview_baker.py').read_text()
    assert 'choose_consistent_color' in script
    assert 'pixel_visibility' in script
    assert 'UNVERIFIED_GEOMETRY' in script
    assert 'conflicting_texels' in script


def test_true_strict_refiner_rejects_missing_source_photos(tmp_path, monkeypatch):
    from app.config import Settings
    from app.refiner import BlenderRefiner, RefinementError
    import pytest
    monkeypatch.setenv('GLB_STRICT_GEOMETRIC_TEXTURES','1')
    source=tmp_path/'source.glb';source.write_bytes(b'glTF-base-stub')
    with pytest.raises(RefinementError,match='STRICT_TEXTURE_BAKE_UNAVAILABLE'):
        BlenderRefiner(Settings(data_dir=tmp_path, disable_worker=True)).refine(
            base_glb=source,image_paths={},preview_glb=tmp_path/'preview.glb',
            high_quality_glb=tmp_path/'hq.glb',quality_mode='pro_hq',remesh=False,
            on_update=lambda *args:None)


def test_calibration_studio_is_served_without_exposing_secret(tmp_path):
    from fastapi.testclient import TestClient
    from app.main import create_app
    from app.config import Settings
    with TestClient(create_app(Settings(data_dir=tmp_path,disable_worker=True))) as client:
        response=client.get('/calibration-studio')
        assert response.status_code == 200
        assert 'GLB Calibration Studio' in response.text
        assert 'X-GLB-Token' in response.text


def test_failed_calibration_report_can_be_inspected(tmp_path):
    from fastapi.testclient import TestClient
    from app.main import create_app
    from app.config import Settings
    import json
    with TestClient(create_app(Settings(data_dir=tmp_path,disable_worker=True))) as client:
        files={n:('p.png',b'\x89PNG\r\n\x1a\n', 'image/png')
               for n in ('front','back','left','right')}
        response=client.post('/v4/jobs',files=files)
        assert response.status_code==202
        job_id=response.json()['job_id']
        r=tmp_path/'jobs'/job_id/'work'/'surface_bake_v540'/'calibration_report.json'
        r.parent.mkdir(parents=True)
        r.write_text(json.dumps({'front':{'accepted':False,'reason':'missing anchors'}}))
        response=client.get(f'/v4/jobs/{job_id}/calibration-report')
        assert response.status_code==200
        assert response.json()['front']['accepted'] is False
