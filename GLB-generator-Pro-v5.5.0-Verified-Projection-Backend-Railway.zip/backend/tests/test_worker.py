from pathlib import Path
import asyncio

from app.config import Settings
from app.provider import HunyuanProvider
from app.store import JobStore
from app.worker import process_job


def make_job(store: JobStore, tmp_path: Path, job_id: str = "job1"):
    inp = tmp_path / "jobs" / job_id / "input"
    inp.mkdir(parents=True)
    paths = {}
    for name in ("front", "back", "left", "right"):
        p = inp / f"{name}.jpg"
        p.write_bytes(b"jpg")
        paths[name] = str(p)
    return store.create_job(job_id=job_id, paths=paths)


def test_store_normalizes_interrupted_jobs_for_restart(tmp_path: Path):
    store = JobStore(tmp_path / "jobs.sqlite3")
    make_job(store, tmp_path)
    store.update_job("job1", status="generating", progress=63, message="GPU work")
    assert store.normalize_interrupted() == 1
    job = store.get_job("job1")
    assert job["status"] == "queued"
    assert job["progress"] == 5


def test_worker_completes_and_persists_model(tmp_path: Path):
    store = JobStore(tmp_path / "jobs.sqlite3")
    make_job(store, tmp_path)
    settings = Settings(data_dir=tmp_path, disable_worker=True, provider_retry_minutes=1)

    class FakeProvider:
        def generate(self, *, front, back, left, right, output, on_update):
            assert all(Path(p).exists() for p in (front, back, left, right))
            on_update("Hunyuan3D-test", "generating", 70, "Generating")
            Path(output).parent.mkdir(parents=True, exist_ok=True)
            Path(output).write_bytes(b"glTF-result")
            return Path(output)

    asyncio.run(process_job(store, settings, "job1", provider=FakeProvider()))
    job = store.get_job("job1")
    assert job["status"] == "completed"
    assert job["progress"] == 100
    assert Path(job["output_path"]).read_bytes() == b"glTF-result"


def test_worker_failure_keeps_original_images_for_retry(tmp_path: Path):
    store = JobStore(tmp_path / "jobs.sqlite3")
    make_job(store, tmp_path)
    settings = Settings(data_dir=tmp_path, disable_worker=True, provider_retry_minutes=1)

    class FailingProvider:
        def generate(self, **kwargs):
            raise RuntimeError("provider unavailable")

    asyncio.run(process_job(store, settings, "job1", provider=FailingProvider()))
    job = store.get_job("job1")
    assert job["status"] == "failed"
    assert "provider unavailable" in job["last_error"]
    assert all(Path(job[f"{name}_path"]).exists() for name in ("front", "back", "left", "right"))


def test_provider_falls_back_to_second_space_without_waiting(tmp_path: Path):
    for name in ("front", "back", "left", "right"):
        (tmp_path / f"{name}.jpg").write_bytes(b"jpg")
    generated = tmp_path / "remote.glb"
    generated.write_bytes(b"glTF")
    calls = []

    class FakeClient:
        def __init__(self, space_id):
            self.space_id = space_id
        def predict(self, **kwargs):
            calls.append(self.space_id)
            if self.space_id == "tencent/Hunyuan3D-2mv":
                raise RuntimeError("503 Service Unavailable")
            return (str(generated), "ok", {"faces": 100}, 1234)

    provider = HunyuanProvider(
        Settings(data_dir=tmp_path, provider_retry_minutes=1),
        client_factory=lambda space_id: FakeClient(space_id),
        file_adapter=lambda path: path,
        sleep_fn=lambda seconds: None,
    )
    out = tmp_path / "character.glb"
    provider.generate(
        front=tmp_path / "front.jpg",
        back=tmp_path / "back.jpg",
        left=tmp_path / "left.jpg",
        right=tmp_path / "right.jpg",
        output=out,
        on_update=lambda *args: None,
    )
    assert calls[:2] == ["tencent/Hunyuan3D-2mv", "tencent/Hunyuan3D-2.1"]
    assert out.read_bytes() == b"glTF"


def test_provider_accepts_nested_filedata_result(tmp_path: Path):
    for name in ("front", "back", "left", "right"):
        (tmp_path / f"{name}.jpg").write_bytes(b"jpg")
    generated = tmp_path / "remote.glb"
    generated.write_bytes(b"glTF-nested")

    class FakeClient:
        def __init__(self, space_id):
            self.space_id = space_id
        def predict(self, **kwargs):
            return ([{"meta": {"_type": "gradio.FileData"}, "path": str(generated)}], "ok", {}, 1234)

    provider = HunyuanProvider(
        Settings(data_dir=tmp_path, provider_retry_minutes=1),
        client_factory=lambda space_id: FakeClient(space_id),
        file_adapter=lambda path: path,
        sleep_fn=lambda seconds: None,
    )
    out = tmp_path / "character.glb"
    provider.generate(
        front=tmp_path / "front.jpg",
        back=tmp_path / "back.jpg",
        left=tmp_path / "left.jpg",
        right=tmp_path / "right.jpg",
        output=out,
        on_update=lambda *args: None,
    )
    assert out.read_bytes() == b"glTF-nested"


def test_malformed_provider_result_falls_back_instead_of_failing_job(tmp_path: Path):
    for name in ("front", "back", "left", "right"):
        (tmp_path / f"{name}.jpg").write_bytes(b"jpg")
    generated = tmp_path / "fallback.glb"
    generated.write_bytes(b"glTF-fallback")
    calls = []

    class FakeClient:
        def __init__(self, space_id):
            self.space_id = space_id
        def predict(self, **kwargs):
            calls.append(self.space_id)
            if self.space_id == "tencent/Hunyuan3D-2mv":
                return ({"unexpected": "shape"}, "ok", {}, 1234)
            return ({"path": str(generated), "meta": {"_type": "gradio.FileData"}}, "ok", {}, 1234)

    provider = HunyuanProvider(
        Settings(data_dir=tmp_path, provider_retry_minutes=1),
        client_factory=lambda space_id: FakeClient(space_id),
        file_adapter=lambda path: path,
        sleep_fn=lambda seconds: None,
    )
    out = tmp_path / "character.glb"
    provider.generate(
        front=tmp_path / "front.jpg",
        back=tmp_path / "back.jpg",
        left=tmp_path / "left.jpg",
        right=tmp_path / "right.jpg",
        output=out,
        on_update=lambda *args: None,
    )
    assert calls[:2] == ["tencent/Hunyuan3D-2mv", "tencent/Hunyuan3D-2.1"]
    assert out.read_bytes() == b"glTF-fallback"


def test_v3_worker_generates_base_then_dual_blender_outputs(tmp_path: Path):
    store = JobStore(tmp_path / "jobs.sqlite3")
    inp = tmp_path / "jobs" / "pro1" / "input"
    inp.mkdir(parents=True)
    paths = {}
    for name in ("front", "back", "left", "right"):
        p = inp / f"{name}.jpg"
        p.write_bytes(b"jpg")
        paths[name] = str(p)
    face = inp / "face_front.jpg"
    face.write_bytes(b"face")
    store.create_job(
        job_id="pro1", paths=paths, quality_mode="pro_hq", remesh=True,
        optional_paths={"face_front": str(face)},
    )
    settings = Settings(data_dir=tmp_path, disable_worker=True)
    order = []

    class FakeProvider:
        def generate(self, *, output, on_update, **kwargs):
            order.append("provider")
            Path(output).parent.mkdir(parents=True, exist_ok=True)
            Path(output).write_bytes(b"glTF-base")
            on_update("Hunyuan3D-test", "generating", 55, "geometry")
            return Path(output)

    class FakeRefiner:
        def refine(self, *, base_glb, image_paths, preview_glb, high_quality_glb, quality_mode, remesh, on_update):
            order.append("refiner")
            assert Path(base_glb).read_bytes() == b"glTF-base"
            assert Path(image_paths["face_front"]).exists()
            assert quality_mode == "pro_hq"
            assert remesh is True
            on_update("texture_baking", 82, "8K texture")
            Path(preview_glb).parent.mkdir(parents=True, exist_ok=True)
            Path(preview_glb).write_bytes(b"glTF-preview")
            Path(high_quality_glb).write_bytes(b"glTF-hq")

    asyncio.run(process_job(store, settings, "pro1", provider=FakeProvider(), refiner=FakeRefiner()))
    job = store.get_job("pro1")
    assert order == ["provider", "refiner"]
    assert job["status"] == "completed"
    assert Path(job["base_path"]).read_bytes() == b"glTF-base"
    assert Path(job["preview_path"]).read_bytes() == b"glTF-preview"
    assert Path(job["high_quality_path"]).read_bytes() == b"glTF-hq"
    assert job["output_path"] == job["high_quality_path"]


def test_v3_refiner_failure_retains_base_and_optional_images(tmp_path: Path):
    store = JobStore(tmp_path / "jobs.sqlite3")
    inp = tmp_path / "jobs" / "pro2" / "input"
    inp.mkdir(parents=True)
    paths = {}
    for name in ("front", "back", "left", "right"):
        p = inp / f"{name}.jpg"
        p.write_bytes(b"jpg")
        paths[name] = str(p)
    front45 = inp / "front_45.jpg"
    front45.write_bytes(b"45")
    store.create_job(
        job_id="pro2", paths=paths, quality_mode="pro_hq",
        optional_paths={"front_45": str(front45)},
    )
    settings = Settings(data_dir=tmp_path, disable_worker=True)

    class FakeProvider:
        def generate(self, *, output, **kwargs):
            Path(output).parent.mkdir(parents=True, exist_ok=True)
            Path(output).write_bytes(b"glTF-base")
            return Path(output)

    class FailingRefiner:
        def refine(self, **kwargs):
            raise RuntimeError("texture bake failed")

    asyncio.run(process_job(store, settings, "pro2", provider=FakeProvider(), refiner=FailingRefiner()))
    job = store.get_job("pro2")
    assert job["status"] == "failed"
    assert "texture bake failed" in job["last_error"]
    assert Path(job["base_path"]).exists()
    assert Path(job["front_45_path"]).exists()


def test_v3_retry_reuses_existing_base_without_provider_call(tmp_path: Path):
    store = JobStore(tmp_path / "jobs.sqlite3")
    inp = tmp_path / "jobs" / "pro3" / "input"
    inp.mkdir(parents=True)
    paths = {}
    for name in ("front", "back", "left", "right"):
        p = inp / f"{name}.jpg"
        p.write_bytes(b"jpg")
        paths[name] = str(p)
    store.create_job(job_id="pro3", paths=paths, quality_mode="pro_hq", remesh=False)
    base = tmp_path / "jobs" / "pro3" / "work" / "base.glb"
    base.parent.mkdir(parents=True, exist_ok=True)
    base.write_bytes(b"glTF-existing-base")
    store.update_job("pro3", base_path=str(base), status="queued", progress=5)
    settings = Settings(data_dir=tmp_path, disable_worker=True)

    class ProviderMustNotRun:
        def generate(self, **kwargs):
            raise AssertionError("provider should not run when a valid base.glb already exists")

    class FakeRefiner:
        def refine(self, *, base_glb, preview_glb, high_quality_glb, on_update, **kwargs):
            assert Path(base_glb).read_bytes() == b"glTF-existing-base"
            on_update("texture_baking", 80, "reuse base")
            Path(preview_glb).parent.mkdir(parents=True, exist_ok=True)
            Path(preview_glb).write_bytes(b"glTF-preview")
            Path(high_quality_glb).write_bytes(b"glTF-hq")

    asyncio.run(process_job(store, settings, "pro3", provider=ProviderMustNotRun(), refiner=FakeRefiner()))
    job = store.get_job("pro3")
    assert job["status"] == "completed"
    assert Path(job["base_path"]).read_bytes() == b"glTF-existing-base"


def test_provider_turns_zerogpu_quota_into_retry_hint(tmp_path: Path):
    from app.provider import ProviderQuotaExceeded

    for name in ("front", "back", "left", "right"):
        (tmp_path / f"{name}.jpg").write_bytes(b"jpg")

    class FakeClient:
        def __init__(self, space_id):
            self.space_id = space_id
        def predict(self, **kwargs):
            raise RuntimeError(
                "You have exceeded your ZeroGPU quota (60s requested vs. 43s left). "
                "Try again in 13:42:50. Authenticate with a Hugging Face token for more quota"
            )

    provider = HunyuanProvider(
        Settings(data_dir=tmp_path, provider_retry_minutes=1),
        client_factory=lambda space_id: FakeClient(space_id),
        file_adapter=lambda path: path,
        sleep_fn=lambda seconds: None,
    )
    out = tmp_path / "character.glb"
    try:
        provider.generate(
            front=tmp_path / "front.jpg",
            back=tmp_path / "back.jpg",
            left=tmp_path / "left.jpg",
            right=tmp_path / "right.jpg",
            output=out,
            on_update=lambda *args: None,
        )
    except ProviderQuotaExceeded as exc:
        assert exc.retry_after_seconds >= 13 * 3600 + 42 * 60 + 50
        assert "ZeroGPU quota" in str(exc)
    else:
        raise AssertionError("ZeroGPU quota should be surfaced as ProviderQuotaExceeded")


def test_worker_defers_quota_job_without_marking_failure(tmp_path: Path):
    from app.provider import ProviderQuotaExceeded

    store = JobStore(tmp_path / "jobs.sqlite3")
    make_job(store, tmp_path)
    settings = Settings(data_dir=tmp_path, disable_worker=True, provider_retry_minutes=1)

    class QuotaProvider:
        def generate(self, **kwargs):
            raise ProviderQuotaExceeded(
                "ZeroGPU quota exhausted; retry later",
                retry_after_seconds=3600,
            )

    asyncio.run(process_job(store, settings, "job1", provider=QuotaProvider()))
    job = store.get_job("job1")
    assert job["status"] == "queued"
    assert job["retry_after_at"] is not None
    assert "quota" in job["message"].lower()
    assert store.next_queued() is None


def test_v3_retry_reuses_base_from_previous_identical_job(tmp_path: Path):
    store = JobStore(tmp_path / "jobs.sqlite3")
    settings = Settings(data_dir=tmp_path, disable_worker=True)

    def create_inputs(job_id: str, payloads: dict[str, bytes]):
        inp = tmp_path / "jobs" / job_id / "input"
        inp.mkdir(parents=True)
        paths = {}
        for name in ("front", "back", "left", "right"):
            p = inp / f"{name}.jpg"
            p.write_bytes(payloads[name])
            paths[name] = str(p)
        return paths

    payloads = {
        "front": b"same-front-photo",
        "back": b"same-back-photo",
        "left": b"same-left-photo",
        "right": b"same-right-photo",
    }
    old_paths = create_inputs("old-job", payloads)
    store.create_job(job_id="old-job", paths=old_paths, quality_mode="pro_hq", remesh=False)
    old_base = tmp_path / "jobs" / "old-job" / "work" / "base.glb"
    old_base.parent.mkdir(parents=True, exist_ok=True)
    old_base.write_bytes(b"glTF-cached-geometry")
    store.update_job("old-job", base_path=str(old_base), status="completed", progress=100)

    new_paths = create_inputs("new-job", payloads)
    store.create_job(job_id="new-job", paths=new_paths, quality_mode="pro_hq", remesh=False)

    class ProviderMustNotRun:
        def generate(self, **kwargs):
            raise AssertionError("provider should not run when identical photos already have cached geometry")

    class FakeRefiner:
        def refine(self, *, base_glb, preview_glb, high_quality_glb, on_update, **kwargs):
            assert Path(base_glb).read_bytes() == b"glTF-cached-geometry"
            on_update("texture_baking", 80, "reuse cached geometry")
            Path(preview_glb).parent.mkdir(parents=True, exist_ok=True)
            Path(preview_glb).write_bytes(b"glTF-preview")
            Path(high_quality_glb).write_bytes(b"glTF-hq")

    asyncio.run(process_job(store, settings, "new-job", provider=ProviderMustNotRun(), refiner=FakeRefiner()))
    job = store.get_job("new-job")
    assert job["status"] == "completed"
    assert Path(job["base_path"]).read_bytes() == b"glTF-cached-geometry"
    assert job["provider"] == "Hunyuan + Blender 4.5 Pro"


def test_v4_auto_quota_switches_to_awaiting_local(tmp_path: Path):
    from app.provider import ProviderQuotaExceeded

    store = JobStore(tmp_path / "jobs.sqlite3")
    inp = tmp_path / "jobs" / "v4auto" / "input"
    inp.mkdir(parents=True)
    paths = {}
    for name in ("front", "back", "left", "right"):
        p = inp / f"{name}.jpg"
        p.write_bytes(b"jpg")
        paths[name] = str(p)
    store.create_job(
        job_id="v4auto",
        paths=paths,
        quality_mode="pro_hq",
        generation_mode="auto",
        output_mode="full_glb",
        texture_mode="auto",
    )
    settings = Settings(data_dir=tmp_path, disable_worker=True, provider_retry_minutes=1)

    class QuotaProvider:
        def generate(self, **kwargs):
            raise ProviderQuotaExceeded("quota", retry_after_seconds=7200)

    asyncio.run(process_job(store, settings, "v4auto", provider=QuotaProvider()))
    job = store.get_job("v4auto")
    assert job["status"] == "awaiting_local"
    assert job["local_fallback_required"] == 1
    assert job["retry_after_at"] is None


def test_v4_cloud_only_quota_stays_queued(tmp_path: Path):
    from app.provider import ProviderQuotaExceeded

    store = JobStore(tmp_path / "jobs.sqlite3")
    inp = tmp_path / "jobs" / "v4cloud" / "input"
    inp.mkdir(parents=True)
    paths = {}
    for name in ("front", "back", "left", "right"):
        p = inp / f"{name}.jpg"
        p.write_bytes(b"jpg")
        paths[name] = str(p)
    store.create_job(
        job_id="v4cloud",
        paths=paths,
        quality_mode="pro_hq",
        generation_mode="cloud_only",
        output_mode="full_glb",
        texture_mode="auto",
    )
    settings = Settings(data_dir=tmp_path, disable_worker=True, provider_retry_minutes=1)

    class QuotaProvider:
        def generate(self, **kwargs):
            raise ProviderQuotaExceeded("quota", retry_after_seconds=3600)

    asyncio.run(process_job(store, settings, "v4cloud", provider=QuotaProvider()))
    job = store.get_job("v4cloud")
    assert job["status"] == "queued"
    assert job["local_fallback_required"] == 0
    assert job["retry_after_at"] is not None


def test_v5_mesh_only_with_uploaded_base_runs_zero_geometry_refiner(tmp_path: Path):
    store = JobStore(tmp_path / "jobs.sqlite3")
    inp = tmp_path / "jobs" / "v4mesh" / "input"
    inp.mkdir(parents=True)
    paths = {}
    for name in ("front", "back", "left", "right"):
        p = inp / f"{name}.jpg"
        p.write_bytes(b"jpg")
        paths[name] = str(p)
    store.create_job(
        job_id="v4mesh",
        paths=paths,
        quality_mode="pro_hq",
        generation_mode="local_only",
        output_mode="mesh_only",
        texture_mode="none",
    )
    base = tmp_path / "jobs" / "v4mesh" / "work" / "base.glb"
    base.parent.mkdir(parents=True, exist_ok=True)
    base.write_bytes(b"glTF-local-base")
    store.update_job("v4mesh", base_path=str(base), status="queued")

    class ProviderMustNotRun:
        def generate(self, **kwargs):
            raise AssertionError("provider must not run")

    class ZeroGeometryRefiner:
        def refine(self, **kwargs):
            # v5.0: ZERO/no-texture still receives the geometry-only Pro refinement pass.
            kwargs["high_quality_glb"].parent.mkdir(parents=True, exist_ok=True)
            kwargs["high_quality_glb"].write_bytes(b"glTF-zero-hq")
            kwargs["preview_glb"].write_bytes(b"glTF-zero-preview")

    asyncio.run(
        process_job(
            store,
            Settings(data_dir=tmp_path, disable_worker=True),
            "v4mesh",
            provider=ProviderMustNotRun(),
            refiner=ZeroGeometryRefiner(),
        )
    )
    job = store.get_job("v4mesh")
    assert job["status"] == "completed"
    assert job["output_path"].endswith("high_quality.glb")
    assert job["high_quality_path"] == job["output_path"]
    assert job["preview_path"].endswith("preview.glb")


def test_mesh_only_job_with_texture_project_runs_refiner(tmp_path: Path):
    import json
    store = JobStore(tmp_path / "jobs.sqlite3")
    job_id = "meshmanual"
    inp = tmp_path / "jobs" / job_id / "input"
    inp.mkdir(parents=True, exist_ok=True)
    paths = {}
    for name in ("front", "back", "left", "right"):
        path = inp / f"{name}.jpg"
        path.write_bytes(b"img")
        paths[name] = str(path)
    store.create_job(job_id=job_id, paths=paths, quality_mode="pro_hq", generation_mode="local_only", output_mode="mesh_only", texture_mode="none")
    settings = Settings(data_dir=tmp_path, disable_worker=True)
    base = settings.jobs_dir / job_id / "base.glb"
    base.parent.mkdir(parents=True, exist_ok=True)
    base.write_bytes(b"glTF" + b"0" * 32)
    project_dir = settings.jobs_dir / job_id / "texture_project"
    project_dir.mkdir(parents=True, exist_ok=True)
    project = project_dir / "texture_project.json"
    project.write_text(json.dumps({"mode":"hybrid","regions":[{"region":"chest_upper","source":"front","direction":"front"}]}))
    store.update_job(job_id, base_path=str(base), texture_project_path=str(project), status="queued")

    class FakeRefiner:
        def refine(self, **kwargs):
            kwargs["preview_glb"].write_bytes(b"glTFpreview")
            kwargs["high_quality_glb"].write_bytes(b"glTFhq")
    asyncio.run(process_job(store, settings, job_id, provider=object(), refiner=FakeRefiner()))
    done = store.get_job(job_id)
    assert done["status"] == "completed"
    assert done["high_quality_path"]
