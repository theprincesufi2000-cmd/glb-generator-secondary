from pathlib import Path
import json

from app.config import Settings


def test_blender_refiner_writes_hq_manifest_and_validates_outputs(tmp_path: Path, monkeypatch):
    # Legacy test uses intentionally invalid JPEG stubs; explicitly opt out
    # of strict geometry mode instead of weakening the production gate.
    monkeypatch.setenv("GLB_STRICT_GEOMETRIC_TEXTURES", "0")
    from app.refiner import BlenderRefiner

    fake = tmp_path / "fake_blender.py"
    fake.write_text(
        """#!/usr/bin/env python3
import json, pathlib, sys
manifest = json.loads(pathlib.Path(sys.argv[-1]).read_text())
pathlib.Path(manifest['manifest_echo']).write_text(json.dumps(manifest))
pathlib.Path(manifest['preview_glb']).parent.mkdir(parents=True, exist_ok=True)
pathlib.Path(manifest['preview_glb']).write_bytes(b'glTF-preview')
pathlib.Path(manifest['high_quality_glb']).write_bytes(b'glTF-hq')
"""
    )
    fake.chmod(0o755)

    base = tmp_path / "base.glb"
    base.write_bytes(b"glTF-base")
    images = {}
    for name in ("front", "back", "left", "right", "front_45", "face_front"):
        p = tmp_path / f"{name}.jpg"
        p.write_bytes(b"jpg")
        images[name] = p

    preview = tmp_path / "output" / "preview.glb"
    hq = tmp_path / "output" / "high_quality.glb"
    echo = tmp_path / "manifest-echo.json"
    settings = Settings(
        data_dir=tmp_path,
        disable_worker=True,
        blender_executable=str(fake),
        hq_texture_size=8192,
        preview_texture_size=2048,
    )
    refiner = BlenderRefiner(settings)
    updates = []
    result = refiner.refine(
        base_glb=base,
        image_paths=images,
        preview_glb=preview,
        high_quality_glb=hq,
        quality_mode="pro_hq",
        remesh=True,
        on_update=lambda status, progress, message: updates.append((status, progress, message)),
        manifest_extra={"manifest_echo": str(echo)},
    )

    assert result.preview_glb == preview
    assert result.high_quality_glb == hq
    manifest = json.loads(echo.read_text())
    assert manifest["texture_size"] == 8192
    assert manifest["preview_texture_size"] == 2048
    assert manifest["remesh"] is True
    assert manifest["quality_mode"] == "pro_hq"
    assert manifest["images"]["face_front"].endswith("face_front.jpg")
    assert manifest["memory_profile"] == "1gb"
    assert manifest["hq_max_triangles"] == 150000
    assert manifest["projection_body_max_size"] == 1536
    assert manifest["projection_face_max_size"] == 2304
    assert manifest["preview_max_triangles"] == 60000
    assert any(status == "texture_baking" for status, _, _ in updates)


def test_blender_refiner_rejects_missing_outputs(tmp_path: Path, monkeypatch):
    # Legacy test uses intentionally invalid JPEG stubs; explicitly opt out
    # of strict geometry mode instead of weakening the production gate.
    monkeypatch.setenv("GLB_STRICT_GEOMETRIC_TEXTURES", "0")
    from app.refiner import BlenderRefiner, RefinementError

    fake = tmp_path / "bad_blender.py"
    fake.write_text("#!/usr/bin/env python3\n")
    fake.chmod(0o755)
    base = tmp_path / "base.glb"
    base.write_bytes(b"glTF-base")
    settings = Settings(data_dir=tmp_path, disable_worker=True, blender_executable=str(fake))
    refiner = BlenderRefiner(settings)

    try:
        refiner.refine(
            base_glb=base,
            image_paths={},
            preview_glb=tmp_path / "preview.glb",
            high_quality_glb=tmp_path / "hq.glb",
            quality_mode="standard",
            remesh=False,
            on_update=lambda *_: None,
        )
    except RefinementError as exc:
        assert "output" in str(exc).lower()
    else:
        raise AssertionError("missing Blender outputs must fail")


def test_blender_main_avoids_cycles_bake_under_low_memory_runtime():
    script = (Path(__file__).resolve().parents[1] / "blender" / "refine_glb.py").read_text(encoding="utf-8")
    main_body = script.split("def main():", 1)[1]
    assert "HQ mesh memory guard" in main_body
    assert "1GB-safe textures" in main_body
    assert "projection_body_max_size" in main_body
    assert "projection_face_max_size" in main_body
    assert "bake_albedo(" not in script
    assert "bpy.ops.object.bake" not in script
    assert 'export_image_format="AUTO"' in script
    assert "export_jpeg_quality=95" in script


def test_refiner_manifest_declares_projection_strategy(tmp_path: Path, monkeypatch):
    # Legacy test uses intentionally invalid JPEG stubs; explicitly opt out
    # of strict geometry mode instead of weakening the production gate.
    monkeypatch.setenv("GLB_STRICT_GEOMETRIC_TEXTURES", "0")
    from app.refiner import BlenderRefiner

    fake = tmp_path / "fake_blender.py"
    fake.write_text(
        """#!/usr/bin/env python3
import json, pathlib, sys
manifest = json.loads(pathlib.Path(sys.argv[-1]).read_text())
pathlib.Path(manifest['manifest_echo']).write_text(json.dumps(manifest))
pathlib.Path(manifest['preview_glb']).parent.mkdir(parents=True, exist_ok=True)
pathlib.Path(manifest['preview_glb']).write_bytes(b'glTF-preview')
pathlib.Path(manifest['high_quality_glb']).write_bytes(b'glTF-hq')
"""
    )
    fake.chmod(0o755)
    base = tmp_path / "base.glb"
    base.write_bytes(b"glTF-base")
    front = tmp_path / "front.jpg"
    front.write_bytes(b"jpg")
    echo = tmp_path / "manifest-echo.json"
    settings = Settings(data_dir=tmp_path, disable_worker=True, blender_executable=str(fake))
    BlenderRefiner(settings).refine(
        base_glb=base,
        image_paths={"front": front},
        preview_glb=tmp_path / "preview.glb",
        high_quality_glb=tmp_path / "hq.glb",
        quality_mode="pro_hq",
        remesh=False,
        on_update=lambda *_: None,
        manifest_extra={"manifest_echo": str(echo)},
    )
    manifest = json.loads(echo.read_text())
    assert manifest["texture_strategy"] == "subject_fitted_edgefilled_multi_view_projection_v3"


def test_projection_texture_preparation_fills_background_gaps(tmp_path: Path):
    from PIL import Image, ImageDraw
    from app.imagefit import prepare_projection_texture

    image = Image.new("RGB", (240, 420), (248, 248, 248))
    draw = ImageDraw.Draw(image)
    # Two body regions with a background channel between them, similar to the
    # gap between an arm and torso in a full-body photograph.
    draw.rectangle((55, 25, 115, 395), fill=(35, 70, 125))
    draw.rectangle((135, 25, 195, 395), fill=(45, 80, 135))
    source = tmp_path / "front.jpg"
    image.save(source, quality=95)
    output = tmp_path / "prepared.jpg"

    prepare_projection_texture(source, output, face=False)

    prepared = Image.open(output).convert("RGB")
    center = prepared.getpixel((prepared.width // 2, prepared.height // 2))
    # The white channel between the subject parts must be edge-filled rather
    # than projected as a white stripe onto the GLB surface.
    assert max(center) < 220


def test_blender_projection_keeps_original_fallback_and_rejects_backface_face_texture():
    script = (Path(__file__).resolve().parents[1] / "blender" / "refine_glb.py").read_text(encoding="utf-8")
    assert "strip_materials_for_geometry" in script
    assert 'pipeline_stage == "geometry"' in script
    assert "face_score >=" in script
    assert "body_score >=" in script
    assert "front-facing" in script


def test_low_memory_pipeline_keeps_45_degree_body_views():
    script = (Path(__file__).resolve().parents[1] / "blender" / "refine_glb.py").read_text(encoding="utf-8")
    assert '"front_45"' in script.split("safe_keys =", 1)[1].split("}", 1)[0]
    assert '"back_45"' in script.split("safe_keys =", 1)[1].split("}", 1)[0]
