from pathlib import Path

from fastapi.testclient import TestClient
from PIL import Image

from app.config import Settings
from app.main import create_app
from app.ultra_detail import build_ultra_detail_plan
from app.feature_regions import build_feature_reference_plan
from app.pbr_maps import generate_pbr_maps


def _settings(tmp_path: Path) -> Settings:
    return Settings(data_dir=tmp_path, public_base_url="http://testserver", disable_worker=True, max_upload_mb=20)


def _image_part(name: str):
    return (name, b"\xff\xd8\xff\xe0fakejpeg", "image/jpeg")


def test_v4_ultra_detail_accepts_feature_closeups(tmp_path: Path):
    app = create_app(_settings(tmp_path))
    with TestClient(app) as client:
        response = client.post(
            "/v4/jobs",
            files={
                "front": _image_part("front.jpg"),
                "back": _image_part("back.jpg"),
                "left": _image_part("left.jpg"),
                "right": _image_part("right.jpg"),
                "face_front": _image_part("face_front.jpg"),
                "face_left_45": _image_part("face_left_45.jpg"),
                "face_right_45": _image_part("face_right_45.jpg"),
                "face_left_profile": _image_part("face_left_profile.jpg"),
                "face_right_profile": _image_part("face_right_profile.jpg"),
                "left_hand": _image_part("left_hand.jpg"),
                "right_hand": _image_part("right_hand.jpg"),
                "hair_detail": _image_part("hair_detail.jpg"),
                "clothes_detail": _image_part("clothes_detail.jpg"),
            },
            data={"quality_mode": "ultra_detail", "generation_mode": "cloud_only", "output_mode": "full_glb", "texture_mode": "auto"},
        )
        assert response.status_code == 202, response.text
        body = response.json()
        assert body["quality_mode"] == "ultra_detail"
        stored = app.state.store.get_job(body["job_id"])
        assert stored is not None
        for key in (
            "face_left_45_path", "face_right_45_path", "face_left_profile_path", "face_right_profile_path",
            "left_hand_path", "right_hand_path", "hair_detail_path", "clothes_detail_path",
        ):
            assert stored[key]
            assert Path(stored[key]).exists()


def test_ultra_plan_scales_with_memory():
    one = build_ultra_detail_plan("ultra_detail", "1gb")
    two = build_ultra_detail_plan("ultra_detail", "2gb")
    high = build_ultra_detail_plan("ultra_detail", "high")
    assert one.enabled and two.enabled and high.enabled
    assert one.target_hq_triangles < two.target_hq_triangles < high.target_hq_triangles
    assert one.face_texture_cap < two.face_texture_cap < high.face_texture_cap
    assert one.staged_blender is True


def test_feature_plan_prioritizes_face_hands_hair_and_clothes(tmp_path: Path):
    refs = {}
    for key in ("face_front", "face_left_45", "right_hand", "hair_detail", "clothes_detail"):
        path = tmp_path / f"{key}.jpg"
        path.write_bytes(b"x")
        refs[key] = path
    plan = build_feature_reference_plan(refs, "ultra_detail")
    assert "face_front" in plan.face_sources
    assert "right_hand" in plan.hand_sources
    assert plan.hair_source == "hair_detail"
    assert plan.clothes_source == "clothes_detail"
    assert plan.feature_subdivide is True
    assert plan.face_weight > plan.clothing_weight


def test_pbr_maps_are_generated_as_png(tmp_path: Path):
    src = tmp_path / "face.jpg"
    Image.new("RGB", (96, 128), (150, 120, 105)).save(src, quality=95)
    maps = generate_pbr_maps(src, tmp_path / "pbr", key="face_front", max_size=128)
    assert set(maps) == {"normal", "roughness", "ao"}
    for value in maps.values():
        path = Path(value)
        assert path.exists() and path.stat().st_size > 0
        with Image.open(path) as image:
            assert image.width <= 128 and image.height <= 128


def test_android_sources_expose_ultra_detail_and_new_photo_slots():
    source_root = Path(__file__).resolve().parents[2] / "app" / "src" / "main" / "java" / "com" / "mustafa" / "glbgenerator"
    quality = (source_root / "data" / "model" / "QualityMode.kt").read_text(encoding="utf-8")
    photos = (source_root / "data" / "model" / "PhotoType.kt").read_text(encoding="utf-8")
    assert 'ULTRA_DETAIL("ultra_detail"' in quality
    for marker in ("FACE_LEFT_45", "FACE_RIGHT_45", "FACE_LEFT_PROFILE", "FACE_RIGHT_PROFILE", "LEFT_HAND", "RIGHT_HAND", "HAIR_DETAIL", "CLOTHES_DETAIL"):
        assert marker in photos


def test_blender_ultra_detail_contains_feature_subdivision_and_pbr_normal_maps():
    script = (Path(__file__).resolve().parents[1] / "blender" / "refine_glb.py").read_text(encoding="utf-8")
    assert "adaptive_feature_subdivide" in script
    assert "is_hand_zone" in script
    assert "is_hair_zone" in script
    assert "is_clothing_zone" in script
    assert "ShaderNodeNormalMap" in script
    assert "pbr_maps" in script
