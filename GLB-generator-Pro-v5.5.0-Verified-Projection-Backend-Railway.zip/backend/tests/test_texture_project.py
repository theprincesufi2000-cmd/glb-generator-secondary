from pathlib import Path
import json

from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app
from app.texture_project import TextureProjectSpec, TextureRegionSpec


def settings_for(tmp_path: Path) -> Settings:
    return Settings(
        data_dir=tmp_path,
        public_base_url="http://testserver",
        disable_worker=True,
        client_token="",
        max_upload_mb=20,
    )


def image_part(name: str):
    return (name, b"\xff\xd8\xff\xe0fakejpeg", "image/jpeg")


def create_v4(client: TestClient):
    response = client.post(
        "/v4/jobs",
        files={
            "front": image_part("front.jpg"),
            "back": image_part("back.jpg"),
            "left": image_part("left.jpg"),
            "right": image_part("right.jpg"),
        },
        data={"generation_mode": "auto", "output_mode": "full_glb", "texture_mode": "hybrid"},
    )
    assert response.status_code == 202, response.text
    return response.json()["job_id"]


def test_texture_region_validation_and_defaults():
    region = TextureRegionSpec(region="face", source="face_front", offset_x=0.1, scale_x=1.2)
    assert region.direction == "front"
    assert region.scale_y == 1.0
    project = TextureProjectSpec(mode="hybrid", regions=[region])
    assert project.mode == "hybrid"
    assert project.regions[0].region == "face"


def test_texture_project_endpoint_persists_json_and_custom_asset(tmp_path: Path):
    app = create_app(settings_for(tmp_path))
    with TestClient(app) as client:
        job_id = create_v4(client)
        base = tmp_path / "jobs" / job_id / "work" / "base.glb"
        base.parent.mkdir(parents=True, exist_ok=True)
        base.write_bytes(b"glTFbase")
        app.state.store.update_job(job_id, base_path=str(base), status="completed", progress=100)
        project = {
            "mode": "manual",
            "regions": [
                {
                    "region": "chest_upper",
                    "source": "asset:shirt",
                    "direction": "front",
                    "offset_x": 0.05,
                    "offset_y": -0.03,
                    "scale_x": 1.15,
                    "scale_y": 1.1,
                    "rotation_deg": 2.0,
                    "mirror_x": False,
                    "mirror_y": False,
                    "opacity": 1.0,
                    "feather": 0.05,
                }
            ],
        }
        response = client.post(
            f"/v4/jobs/{job_id}/texture-project",
            files={"asset_shirt": ("shirt.png", b"\x89PNG\r\n\x1a\nasset", "image/png")},
            data={"project_json": json.dumps(project)},
        )
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["texture_mode"] == "manual"
        assert body["status"] == "queued"
        stored = app.state.store.get_job(job_id)
        project_path = Path(stored["texture_project_path"])
        assert project_path.exists()
        saved = json.loads(project_path.read_text())
        assert saved["regions"][0]["source"] == "asset:shirt"
        assert (project_path.parent / "manual_textures" / "shirt.png").exists()


def test_texture_project_rejects_unknown_region(tmp_path: Path):
    app = create_app(settings_for(tmp_path))
    with TestClient(app) as client:
        job_id = create_v4(client)
        response = client.post(
            f"/v4/jobs/{job_id}/texture-project",
            data={"project_json": json.dumps({"mode": "manual", "regions": [{"region": "wing", "source": "front"}]})},
        )
        assert response.status_code == 422
