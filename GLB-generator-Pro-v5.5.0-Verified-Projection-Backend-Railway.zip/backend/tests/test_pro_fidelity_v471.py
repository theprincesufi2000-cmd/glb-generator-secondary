from pathlib import Path


def test_pro_fidelity_geometry_plan_is_watertight_and_dense():
    from app.geometry_repair import build_geometry_repair_plan
    plan = build_geometry_repair_plan(
        quality_mode="pro_fidelity",
        remesh=False,
        memory_profile="1gb",
        requested_hq_triangles=150000,
        requested_preview_triangles=60000,
    )
    assert plan.watertight_pass is True
    assert plan.hq_max_triangles >= 240000
    assert 400 <= plan.voxel_resolution_divisor <= 620


def test_pro_fidelity_uv_policy_prioritizes_face():
    from app.uv_pipeline import build_uv_policy
    policy = build_uv_policy("pro_fidelity", 8192)
    assert policy.segmented is True
    assert policy.face_weight > policy.body_weight
    assert policy.padding_px >= 32


def test_glb_validator_accepts_binary_magic(tmp_path: Path):
    from app.glb_validation import validate_glb_file
    path = tmp_path / "model.glb"
    path.write_bytes(b"glTF-test")
    result = validate_glb_file(path)
    assert result.ok is True


def test_terminal_job_retention_keeps_two_newest(tmp_path: Path):
    from app.store import JobStore
    store = JobStore(tmp_path / "jobs.sqlite3")
    jobs_dir = tmp_path / "jobs"
    for index in range(4):
        jid = f"j{index}"
        inp = jobs_dir / jid / "input"
        inp.mkdir(parents=True)
        paths = {}
        for key in ("front", "back", "left", "right"):
            p = inp / f"{key}.jpg"
            p.write_bytes(f"{jid}-{key}".encode())
            paths[key] = str(p)
        store.create_job(job_id=jid, paths=paths, quality_mode="pro_fidelity")
        store.update_job(jid, status="completed", progress=100)
    removed = store.prune_terminal_jobs(jobs_dir, keep_recent=2)
    assert removed == 2
    remaining = [jid for jid in ("j0", "j1", "j2", "j3") if store.get_job(jid) is not None]
    assert remaining == ["j2", "j3"]


def test_pro_fidelity_quality_mode_is_available_in_android_source():
    source = Path(__file__).resolve().parents[2] / "app" / "src" / "main" / "java" / "com" / "mustafa" / "glbgenerator" / "data" / "model" / "QualityMode.kt"
    text = source.read_text(encoding="utf-8")
    assert 'PRO_FIDELITY("pro_fidelity"' in text
