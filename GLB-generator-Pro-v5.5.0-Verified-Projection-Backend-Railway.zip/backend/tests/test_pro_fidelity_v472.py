from pathlib import Path


def test_refiner_splits_one_gb_pro_fidelity_into_three_processes():
    src = (Path(__file__).resolve().parents[1] / "app" / "refiner.py").read_text(encoding="utf-8")
    assert "pipeline_stage': 'geometry'" in src
    assert "pipeline_stage': 'hq'" in src
    assert "pipeline_stage': 'preview'" in src
    assert "geometry-rescue" in src
    assert "hq-rescue" in src


def test_blender_watertight_uses_single_shell_not_solidify():
    src = (Path(__file__).resolve().parents[1] / "blender" / "refine_glb.py").read_text(encoding="utf-8")
    block = src[src.index("def optional_watertight_pass"):src.index("def optional_voxel_remesh")]
    assert "type='REMESH'" in block
    assert "type='SOLIDIFY'" not in block
    assert "restore_detail" in src
