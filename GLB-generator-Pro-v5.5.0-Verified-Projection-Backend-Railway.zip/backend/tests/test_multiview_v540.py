from __future__ import annotations
import numpy as np
import pytest
from PIL import Image, ImageDraw

from app.multiview_core import (
    calibrate_orthographic, project_points, silhouette_rect,
    barycentric_pixels, sample_rgba_nearest, seam_dilate,
)
from app.multiview_schema import CalibrationProject
from app.bake_prepare import prepare_multiview_inputs


def test_calibration_fits_known_3d_landmarks():
    points = np.array([[-2, 0, 1], [2, 0, 1], [0, 0, 3.], [0, 0, 0.]])
    image_uv = [[.1,.5],[.9,.5],[.5,.1],[.5,.7]]
    landmark = [{'world_xyz': p.tolist(), 'image_uv': uv} for p, uv in zip(points,image_uv)]
    alpha = np.ones((32, 32), dtype=np.float32)
    camera = calibrate_orthographic(points, alpha, 'front', landmarks=landmark)
    np.testing.assert_allclose(project_points(points,camera), image_uv, atol=.0001)


def test_invalid_landmark_coordinates_rejected():
    with pytest.raises(Exception):
        CalibrationProject.model_validate({'landmarks': {'front': [
            {'world_xyz':[0,1,2], 'image_uv':[1.3,.2]}]}})
    with pytest.raises(Exception):
        CalibrationProject.model_validate({'landmarks': {'bad_camera': []}})
    with pytest.raises(Exception):
        CalibrationProject.model_validate({'landmarks': {'front': [
            {'world_xyz':[float('nan'),1,2], 'image_uv':[.1,.2]}]}})


def test_image_top_left_mask_bounds():
    a = np.zeros((100,200),dtype=np.float32)
    a[20:80,50:150]=1
    assert silhouette_rect(a)==(.25,.2,.75,.8)


def test_triangle_uv_raster_orientation_and_no_leak():
    tri = np.array([[.1,.9],[.9,.9],[.1,.1]])
    raster=barycentric_pixels(tri, 64)
    assert raster is not None
    x,y,w = raster
    assert len(x)>50
    assert np.all((w>=-1e-5)&(w<=1+1e-5))
    assert np.allclose(w.sum(axis=1),1)
    assert x.min()>=0 and y.min()>=0


def test_sample_rejects_outside_and_alpha_holes():
    img = np.ones((4,4,4), dtype=np.float32)
    img[1:3,1:3,3] = 0.
    out = sample_rgba_nearest(img, [[-.1,.5],[.5,.5],[.9,.9]])
    assert out[0,3]==0 and out[1,3]==0 and out[2,3]==1


def test_seam_dilate_does_not_wrap_across_border():
    img=np.zeros((10,10,3),dtype=np.float32)
    img[3,3]=(.9,.2,.1)
    mask=np.zeros((10,10),dtype=bool);mask[3,3]=True
    padded,filled=seam_dilate(img,mask,iterations=2)
    assert filled[3,5] and not filled[9,9]
    assert np.allclose(padded[3,5],(.9,.2,.1))


def test_prepare_preserves_alpha_and_aspect(tmp_path):
    img=Image.new('RGBA',(200,400),(0,0,0,0))
    d=ImageDraw.Draw(img)
    d.rectangle((20,100,180,320), fill=(10,5,7,255))
    source=tmp_path/'front.png';img.save(source)
    prepared=prepare_multiview_inputs({'front':source},tmp_path/'prepared',body_cap=512)
    with Image.open(prepared['front']) as result:
        assert result.size==(200,400)
        assert result.getpixel((0,0))[3]==0
        assert result.getpixel((50,200))==(10,5,7,255)


def test_blender_script_links_true_bake_into_both_stages():
    from pathlib import Path
    source = (Path(__file__).parents[1]/'blender'/'refine_glb.py').read_text()
    baker = (Path(__file__).parents[1]/'blender'/'multiview_baker.py').read_text()
    assert source.count('aligned_surface_bake(obj)') >= 2
    assert 'BVHTree.FromObject' in baker
    assert 'barycentric_pixels' in baker
    assert 'seam_dilate' in baker
    assert 'uv.smart_project' in baker


def test_face_head_box_excludes_wide_shirt_region():
    from app.multiview_core import face_head_rect
    alpha=np.zeros((300,200),dtype=np.float32)
    alpha[20:180,50:150]=1
    alpha[180:300,0:200]=1  # shoulders and torso wider than head
    u0,v0,u1,v1=face_head_rect(alpha)
    assert u0>.1 and u1<.9
    assert v1<.85


def test_existing_4_direction_camera_basis():
    from app.multiview_core import camera_basis
    f,r=camera_basis('front')
    np.testing.assert_allclose(f, (0,-1,0))
    np.testing.assert_allclose(r, (1,0,0))
    b,rb=camera_basis('back')
    np.testing.assert_allclose(rb, (-1,0,0))


def test_version_and_calibration_endpoint_in_backend():
    from app.main import VERSION
    assert VERSION.startswith(('5.4.', '5.5.'))
    from pathlib import Path
    src=(Path(__file__).parents[1]/'app'/'main.py').read_text()
    assert '/v4/jobs/{job_id}/calibration' in src


def test_calibration_api_persists_and_validates_pair(tmp_path):
    from fastapi.testclient import TestClient
    from app.config import Settings
    from app.main import create_app
    app=create_app(Settings(data_dir=tmp_path, disable_worker=True))
    fake=('portrait.png',b'\x89PNG\r\n\x1a\nheaders', 'image/png')
    with TestClient(app) as client:
        response=client.post('/v4/jobs',files={n:fake for n in ('front','back','left','right')},
                             data={'generation_mode':'cloud_only'})
        assert response.status_code==202, response.text
        job_id=response.json()['job_id']
        calibration={'landmarks':{'front':[{'world_xyz':[0.,0.,1.], 'image_uv':[.5,.5]}]}}
        response=client.post(f'/v4/jobs/{job_id}/calibration',json=calibration)
        assert response.status_code==200, response.text
        import json
        saved=json.loads((tmp_path/'jobs'/job_id/'calibration.json').read_text())
        assert saved['landmarks']['front'][0]['image_uv']==[.5,.5]
        bad={'landmarks':{'front':[{'world_xyz':[0,0,1], 'image_uv':[2,0]}]}}
        assert client.post(f'/v4/jobs/{job_id}/calibration',json=bad).status_code==422


def test_bake_report_endpoint_returns_real_saved_metrics(tmp_path):
    from fastapi.testclient import TestClient
    from app.config import Settings
    from app.main import create_app
    import json
    app=create_app(Settings(data_dir=tmp_path, disable_worker=True))
    with TestClient(app) as client:
        files={n:('p.png',b'\x89PNG\r\n\x1a\n', 'image/png')
               for n in ('front','back','left','right')}
        created=client.post('/v4/jobs', files=files)
        assert created.status_code==202
        job_id=created.json()['job_id']
        assert client.get(f'/v4/jobs/{job_id}/bake-report').status_code==404
        path=tmp_path/'jobs'/job_id/'work'/'surface_bake_v540'/'bake_metrics.json'
        path.parent.mkdir(parents=True)
        path.write_text(json.dumps({'valid_pixels':800, 'mesh_covered_pixels':1000, 'views_loaded':['front']}))
        response=client.get(f'/v4/jobs/{job_id}/bake-report')
        assert response.status_code==200
        assert response.json()['valid_pixels']==800
