from pathlib import Path

from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app


def settings_for(tmp_path: Path) -> Settings:
    return Settings(
        data_dir=tmp_path,
        public_base_url="http://testserver",
        disable_worker=True,
        client_token="",
        max_upload_mb=20,
    )


def image_part(name: str):
    # The API validates transport/content type and durable storage, not image decoding.
    return (name, b"\xff\xd8\xff\xe0fakejpeg", "image/jpeg")


def test_create_job_persists_inputs_before_returning(tmp_path: Path):
    app = create_app(settings_for(tmp_path))
    with TestClient(app) as client:
        response = client.post(
            "/v1/jobs",
            files={
                "front": image_part("front.jpg"),
                "back": image_part("back.jpg"),
                "left": image_part("left.jpg"),
                "right": image_part("right.jpg"),
            },
        )
        assert response.status_code == 202, response.text
        body = response.json()
        assert body["status"] == "queued"
        job_id = body["job_id"]

        status = client.get(f"/v1/jobs/{job_id}")
        assert status.status_code == 200
        assert status.json()["job_id"] == job_id
        assert status.json()["status"] == "queued"

        input_dir = tmp_path / "jobs" / job_id / "input"
        assert {p.name for p in input_dir.iterdir()} == {
            "front.jpg", "back.jpg", "left.jpg", "right.jpg"
        }
        assert all((input_dir / n).stat().st_size > 0 for n in [
            "front.jpg", "back.jpg", "left.jpg", "right.jpg"
        ])


def test_missing_required_view_is_rejected(tmp_path: Path):
    app = create_app(settings_for(tmp_path))
    with TestClient(app) as client:
        response = client.post(
            "/v1/jobs",
            files={
                "front": image_part("front.jpg"),
                "back": image_part("back.jpg"),
                "left": image_part("left.jpg"),
            },
        )
        assert response.status_code == 422


def test_retry_requeues_failed_job_without_reupload(tmp_path: Path):
    app = create_app(settings_for(tmp_path))
    with TestClient(app) as client:
        created = client.post(
            "/v1/jobs",
            files={
                "front": image_part("front.jpg"),
                "back": image_part("back.jpg"),
                "left": image_part("left.jpg"),
                "right": image_part("right.jpg"),
            },
        ).json()
        job_id = created["job_id"]
        app.state.store.update_job(job_id, status="failed", message="provider unavailable", last_error="503")

        response = client.post(f"/v1/jobs/{job_id}/retry")
        assert response.status_code == 200
        body = response.json()
        assert body["status"] == "queued"
        assert body["last_error"] is None


def test_model_endpoint_streams_completed_glb(tmp_path: Path):
    app = create_app(settings_for(tmp_path))
    with TestClient(app) as client:
        created = client.post(
            "/v1/jobs",
            files={
                "front": image_part("front.jpg"),
                "back": image_part("back.jpg"),
                "left": image_part("left.jpg"),
                "right": image_part("right.jpg"),
            },
        ).json()
        job_id = created["job_id"]
        out = tmp_path / "jobs" / job_id / "output" / "character.glb"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(b"glTFfake")
        app.state.store.update_job(job_id, status="completed", progress=100, output_path=str(out))

        response = client.get(f"/v1/jobs/{job_id}/model")
        assert response.status_code == 200
        assert response.content == b"glTFfake"
        assert response.headers["content-type"].startswith("model/gltf-binary")


def test_v3_job_accepts_optional_views_and_quality_settings(tmp_path: Path):
    app = create_app(settings_for(tmp_path))
    with TestClient(app) as client:
        response = client.post(
            "/v3/jobs",
            files={
                "front": image_part("front.jpg"),
                "back": image_part("back.jpg"),
                "left": image_part("left.jpg"),
                "right": image_part("right.jpg"),
                "front_45": image_part("front_45.jpg"),
                "back_45": image_part("back_45.jpg"),
                "face_front": image_part("face_front.jpg"),
                "face_45": image_part("face_45.jpg"),
            },
            data={"quality_mode": "pro_hq", "remesh": "true"},
        )
        assert response.status_code == 202, response.text
        body = response.json()
        assert body["quality_mode"] == "pro_hq"
        assert body["remesh"] is True
        assert body["preview_url"] is None
        assert body["high_quality_url"] is None
        job = app.state.store.get_job(body["job_id"])
        assert job is not None
        for name in ("front_45", "back_45", "face_front", "face_45"):
            assert Path(job[f"{name}_path"]).exists()


def test_v3_dual_output_endpoints_stream_completed_glbs(tmp_path: Path):
    app = create_app(settings_for(tmp_path))
    with TestClient(app) as client:
        created = client.post(
            "/v3/jobs",
            files={
                "front": image_part("front.jpg"),
                "back": image_part("back.jpg"),
                "left": image_part("left.jpg"),
                "right": image_part("right.jpg"),
            },
            data={"quality_mode": "pro_hq", "remesh": "false"},
        ).json()
        job_id = created["job_id"]
        out_dir = tmp_path / "jobs" / job_id / "output"
        out_dir.mkdir(parents=True, exist_ok=True)
        preview = out_dir / "preview.glb"
        hq = out_dir / "high_quality.glb"
        preview.write_bytes(b"glTFpreview")
        hq.write_bytes(b"glTFhighquality")
        app.state.store.update_job(
            job_id,
            status="completed",
            progress=100,
            preview_path=str(preview),
            high_quality_path=str(hq),
        )

        status_response = client.get(f"/v3/jobs/{job_id}")
        assert status_response.status_code == 200
        status_body = status_response.json()
        assert status_body["preview_url"].endswith(f"/v3/jobs/{job_id}/preview")
        assert status_body["high_quality_url"].endswith(f"/v3/jobs/{job_id}/high-quality")

        preview_response = client.get(f"/v3/jobs/{job_id}/preview")
        hq_response = client.get(f"/v3/jobs/{job_id}/high-quality")
        assert preview_response.content == b"glTFpreview"
        assert hq_response.content == b"glTFhighquality"
        assert preview_response.headers["content-disposition"].endswith('filename="preview.glb"')
        assert hq_response.headers["content-disposition"].endswith('filename="high_quality.glb"')


def test_v3_retry_reuses_optional_images(tmp_path: Path):
    app = create_app(settings_for(tmp_path))
    with TestClient(app) as client:
        created = client.post(
            "/v3/jobs",
            files={
                "front": image_part("front.jpg"),
                "back": image_part("back.jpg"),
                "left": image_part("left.jpg"),
                "right": image_part("right.jpg"),
                "face_front": image_part("face_front.jpg"),
            },
            data={"quality_mode": "pro_hq", "remesh": "false"},
        ).json()
        job_id = created["job_id"]
        app.state.store.update_job(job_id, status="failed", last_error="texture bake failed")
        response = client.post(f"/v3/jobs/{job_id}/retry")
        assert response.status_code == 200
        assert response.json()["status"] == "queued"
        job = app.state.store.get_job(job_id)
        assert Path(job["face_front_path"]).exists()


def glb_part(name: str = "base.glb"):
    return (name, b"glTF" + b"\x00" * 32, "model/gltf-binary")


def test_v4_job_exposes_modes_and_local_fallback_contract(tmp_path: Path):
    app = create_app(settings_for(tmp_path))
    with TestClient(app) as client:
        response = client.post(
            "/v4/jobs",
            files={
                "front": image_part("front.jpg"),
                "back": image_part("back.jpg"),
                "left": image_part("left.jpg"),
                "right": image_part("right.jpg"),
            },
            data={
                "quality_mode": "pro_hq",
                "generation_mode": "auto",
                "output_mode": "full_glb",
                "texture_mode": "hybrid",
                "remesh": "false",
            },
        )
        assert response.status_code == 202, response.text
        body = response.json()
        assert body["generation_mode"] == "auto"
        assert body["output_mode"] == "full_glb"
        assert body["texture_mode"] == "hybrid"
        assert body["local_fallback_required"] is False
        stored = app.state.store.get_job(body["job_id"])
        assert stored["generation_mode"] == "auto"
        assert stored["output_mode"] == "full_glb"
        assert stored["texture_mode"] == "hybrid"


def test_v4_base_mesh_upload_is_durable_and_requeues_refinement(tmp_path: Path):
    app = create_app(settings_for(tmp_path))
    with TestClient(app) as client:
        created = client.post(
            "/v4/jobs",
            files={
                "front": image_part("front.jpg"),
                "back": image_part("back.jpg"),
                "left": image_part("left.jpg"),
                "right": image_part("right.jpg"),
            },
            data={
                "generation_mode": "auto",
                "output_mode": "full_glb",
                "texture_mode": "auto",
            },
        ).json()
        job_id = created["job_id"]
        app.state.store.update_job(
            job_id,
            status="awaiting_local",
            progress=30,
            message="Local fallback required",
            local_fallback_required=1,
        )

        response = client.post(
            f"/v4/jobs/{job_id}/base-mesh",
            files={"base_mesh": glb_part()},
        )
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["status"] == "queued"
        assert body["local_fallback_required"] is False
        stored = app.state.store.get_job(job_id)
        base = Path(stored["base_path"])
        assert base.exists()
        assert base.read_bytes().startswith(b"glTF")


def test_v4_rejects_invalid_base_mesh(tmp_path: Path):
    app = create_app(settings_for(tmp_path))
    with TestClient(app) as client:
        created = client.post(
            "/v4/jobs",
            files={
                "front": image_part("front.jpg"),
                "back": image_part("back.jpg"),
                "left": image_part("left.jpg"),
                "right": image_part("right.jpg"),
            },
            data={"generation_mode": "auto", "output_mode": "mesh_only", "texture_mode": "none"},
        ).json()
        response = client.post(
            f"/v4/jobs/{created['job_id']}/base-mesh",
            files={"base_mesh": ("bad.glb", b"not-a-glb", "application/octet-stream")},
        )
        assert response.status_code == 400


def test_v4_mesh_endpoint_streams_base_or_completed_mesh(tmp_path: Path):
    app = create_app(settings_for(tmp_path))
    with TestClient(app) as client:
        created = client.post(
            "/v4/jobs",
            files={
                "front": image_part("front.jpg"),
                "back": image_part("back.jpg"),
                "left": image_part("left.jpg"),
                "right": image_part("right.jpg"),
            },
            data={"generation_mode": "local_only", "output_mode": "mesh_only", "texture_mode": "none"},
        ).json()
        job_id = created["job_id"]
        base = tmp_path / "jobs" / job_id / "work" / "base.glb"
        base.parent.mkdir(parents=True, exist_ok=True)
        base.write_bytes(b"glTFmesh")
        app.state.store.update_job(job_id, base_path=str(base), output_path=str(base), status="completed", progress=100)
        response = client.get(f"/v4/jobs/{job_id}/mesh")
        assert response.status_code == 200
        assert response.content == b"glTFmesh"


def test_v4_cancel_marks_job_cancelled(tmp_path: Path):
    app = create_app(settings_for(tmp_path))
    with TestClient(app) as client:
        created = client.post(
            "/v4/jobs",
            files={
                "front": image_part("front.jpg"),
                "back": image_part("back.jpg"),
                "left": image_part("left.jpg"),
                "right": image_part("right.jpg"),
            },
            data={
                "quality_mode": "pro_fidelity",
                "remesh": "false",
                "generation_mode": "cloud_only",
                "output_mode": "full_glb",
                "texture_mode": "hybrid",
            },
        )
        assert created.status_code == 202, created.text
        job_id = created.json()["job_id"]
        cancelled = client.post(f"/v4/jobs/{job_id}/cancel")
        assert cancelled.status_code == 200, cancelled.text
        body = cancelled.json()
        assert body["status"] == "cancelled"
        assert body["local_fallback_required"] is False
        assert app.state.store.next_queued() is None


def test_cancel_unknown_v4_job_returns_404(tmp_path: Path):
    app = create_app(settings_for(tmp_path))
    with TestClient(app) as client:
        response = client.post("/v4/jobs/does-not-exist/cancel")
        assert response.status_code == 404
