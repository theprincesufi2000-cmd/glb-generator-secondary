from pathlib import Path
from PIL import Image, ImageDraw


def test_alpha_cutout_subject_survives_real_black_background(tmp_path):
    from app.imagefit import estimate_projection_crop, prepare_projection_texture
    photo = tmp_path/'subject.png'
    rgba = Image.new('RGBA',(400,800),(0,0,0,0))
    d = ImageDraw.Draw(rgba)
    d.rectangle((120,100,280,740), fill=(12,10,16,255))
    rgba.save(photo)
    crop = estimate_projection_crop(photo)
    assert 0.24 < crop[0] < 0.37
    assert 0.65 < crop[2] < 0.76
    dest=tmp_path/'prepared.png'
    prepare_projection_texture(photo,dest)
    with Image.open(dest) as im:
        assert im.format == 'PNG'
        assert min(im.getpixel((im.width//2,im.height//2))) < 25


def test_real_legacy_glb_rejected_by_pbr_atlas_validator(tmp_path):
    import json, struct
    from app.glb_validation import validate_single_pbr_atlas
    legacy={'asset':{'version':'2.0'},'materials':[{'name':f'Photo_{i}'} for i in range(8)]}
    jb=json.dumps(legacy).encode();jb+=b' '*(-len(jb)%4)
    binary=b'\0'*4
    f=tmp_path/'legacy.glb'
    f.write_bytes(struct.pack('<4sII',b'glTF',2,12+8+len(jb)+8+len(binary))+
                  struct.pack('<I4s',len(jb),b'JSON')+jb+
                  struct.pack('<I4s',len(binary),b'BIN\0')+binary)
    result=validate_single_pbr_atlas(f)
    assert not result.ok and 'multi-material' in result.message
