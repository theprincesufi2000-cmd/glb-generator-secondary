from pathlib import Path

from PIL import Image, ImageDraw


def _make_body_photo(path: Path):
    image = Image.new('RGB', (400, 800), (242, 242, 242))
    draw = ImageDraw.Draw(image)
    # synthetic full body, deliberately leaving large photo margins
    draw.rectangle((120, 70, 280, 730), fill=(40, 70, 115))
    image.save(path, quality=95)


def test_body_crop_tracks_subject_instead_of_full_photo(tmp_path: Path):
    from app.imagefit import estimate_projection_crop

    photo = tmp_path / 'front.jpg'
    _make_body_photo(photo)
    crop = estimate_projection_crop(photo, face=False)

    # crop is normalized in image coordinates: left, top, right, bottom.
    assert 0.24 <= crop[0] <= 0.31
    assert 0.04 <= crop[1] <= 0.12
    assert 0.69 <= crop[2] <= 0.76
    assert 0.88 <= crop[3] <= 0.96


def test_face_crop_excludes_shoulders_and_bottom_margin(tmp_path: Path):
    from app.imagefit import estimate_projection_crop

    image = Image.new('RGB', (500, 700), (245, 245, 245))
    draw = ImageDraw.Draw(image)
    # head + neck/shoulders. Face fitting should stop before the shoulder band.
    draw.ellipse((135, 35, 365, 430), fill=(110, 80, 65))
    draw.rectangle((40, 420, 460, 690), fill=(140, 100, 80))
    photo = tmp_path / 'face.jpg'
    image.save(photo, quality=95)

    crop = estimate_projection_crop(photo, face=True)

    assert crop[0] > 0.15
    assert crop[2] < 0.85
    assert crop[1] < 0.10
    assert crop[3] < 0.75


def test_refiner_manifest_contains_per_view_projection_crops(tmp_path: Path):
    from app.config import Settings
    from app.refiner import BlenderRefiner

    fake = tmp_path / 'fake_blender.py'
    fake.write_text(
        '''#!/usr/bin/env python3
import json, pathlib, sys
manifest = json.loads(pathlib.Path(sys.argv[-1]).read_text())
pathlib.Path(manifest['manifest_echo']).write_text(json.dumps(manifest))
pathlib.Path(manifest['preview_glb']).write_bytes(b'glTF-preview')
pathlib.Path(manifest['high_quality_glb']).write_bytes(b'glTF-hq')
'''
    )
    fake.chmod(0o755)

    base = tmp_path / 'base.glb'
    base.write_bytes(b'glTF-base')
    front = tmp_path / 'front.jpg'
    _make_body_photo(front)
    preview = tmp_path / 'preview.glb'
    high = tmp_path / 'high.glb'
    echo = tmp_path / 'manifest.json'

    refiner = BlenderRefiner(Settings(data_dir=tmp_path, disable_worker=True, blender_executable=str(fake)))
    refiner.refine(
        base_glb=base,
        image_paths={'front': front},
        preview_glb=preview,
        high_quality_glb=high,
        quality_mode='pro_hq',
        remesh=False,
        on_update=lambda *_: None,
        manifest_extra={'manifest_echo': str(echo)},
    )

    manifest = __import__('json').loads(echo.read_text())
    crop = manifest['projection_crops']['front']
    assert crop == [0.0, 0.0, 1.0, 1.0]
    prepared = Path(manifest['images']['front'])
    assert prepared.name == 'front.png'
    assert prepared.parent.name == 'prepared_projection_v309'
    assert prepared.exists()
    assert Image.open(prepared).width < Image.open(front).width
    assert manifest['texture_strategy'] == 'subject_fitted_edgefilled_multi_view_projection_v3'


def test_blender_projection_uses_subject_crop_and_limits_face_zone():
    script = (Path(__file__).resolve().parents[1] / 'blender' / 'refine_glb.py').read_text(encoding='utf-8')
    assert 'projection_crops' in script
    assert 'crop_left' in script and 'crop_bottom' in script
    assert 'def is_face_zone' in script
    assert 'point.z >= zmin + height * 0.84' in script


def test_body_crop_ignores_floor_shadow_near_bottom_edge(tmp_path: Path):
    from app.imagefit import estimate_projection_crop

    image = Image.new('RGB', (400, 800), (242, 242, 242))
    draw = ImageDraw.Draw(image)
    draw.rectangle((120, 70, 280, 730), fill=(40, 70, 115))
    draw.ellipse((245, 700, 390, 770), fill=(205, 205, 205))
    photo = tmp_path / 'shadow.jpg'
    image.save(photo, quality=95)

    crop = estimate_projection_crop(photo, face=False)
    assert crop[2] < 0.80


def test_face_crop_rejects_edge_foreground_artifacts(tmp_path: Path):
    from app.imagefit import estimate_projection_crop

    image = Image.new('RGB', (500, 700), (245, 245, 245))
    draw = ImageDraw.Draw(image)
    draw.ellipse((135, 35, 365, 440), fill=(90, 70, 60))
    draw.rectangle((40, 430, 460, 690), fill=(135, 95, 80))
    # Simulate a watermark / non-background artifact at an image edge.
    draw.rectangle((470, 40, 495, 300), fill=(210, 210, 210))
    photo = tmp_path / 'face_artifact.jpg'
    image.save(photo, quality=95)

    crop = estimate_projection_crop(photo, face=True)
    assert crop[2] - crop[0] <= 0.82
    assert abs((crop[0] + crop[2]) * 0.5 - 0.5) < 0.01
