# Railway deployment — GLB Generator Pro v3.0.6

Deploy the `backend/` directory as a Dockerfile service.

Required persistent volume:
- Mount path: `/data`

Recommended environment variables:
- `GLB_DATA_DIR=/data`
- `GLB_BLENDER_EXECUTABLE=/home/headless/blender/blender`
- `GLB_BLENDER_TIMEOUT_SECONDS=5400`
- `GLB_HQ_TEXTURE_SIZE=8192`
- `GLB_STANDARD_TEXTURE_SIZE=4096`
- `GLB_PREVIEW_TEXTURE_SIZE=2048`
- `GLB_BLENDER_MEMORY_PROFILE=1gb`
- `GLB_HQ_MAX_TRIANGLES=150000`
- `GLB_PREVIEW_MAX_TRIANGLES=60000`
- `GLB_WORKER_POLL_SECONDS=2`
- `GLB_PUBLIC_BASE_URL=https://YOUR-SERVICE.up.railway.app`
- `GLB_CLIENT_TOKEN=<same token configured in the Android build>`

Health check path: `/health`
Container port: `8000`
Restart policy: `ON_FAILURE`

The v3.0.6 backend requires `Pillow==11.3.0`; it is already included in `requirements.txt`.
