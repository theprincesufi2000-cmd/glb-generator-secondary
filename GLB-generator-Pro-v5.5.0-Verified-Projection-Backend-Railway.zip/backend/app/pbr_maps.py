"""Conservative image-derived PBR hints.

These are *not* measured photogrammetric normals/roughness. The color image
is the only reliable measurement; unobserved AO is neutral, metallic is zero,
and normals are kept close to (0,0,1) to avoid false shading artifacts.
"""
from __future__ import annotations

from pathlib import Path
from typing import Mapping

from PIL import Image, ImageChops, ImageFilter, ImageOps


def _bounded_rgb(path: Path, max_size: int) -> Image.Image:
    with Image.open(path) as opened:
        image = opened.convert('RGB')
    longest = max(image.size)
    if max_size > 0 and longest > max_size:
        ratio = max_size / float(longest)
        image = image.resize((max(1, round(image.width * ratio)), max(1, round(image.height * ratio))), Image.Resampling.LANCZOS)
    return image


def _kind(key: str) -> str:
    if key.startswith('face_'):
        return 'face'
    if key.endswith('_hand'):
        return 'hand'
    if key == 'hair_detail':
        return 'hair'
    if key == 'clothes_detail':
        return 'clothes'
    return 'body'


def _normal_from_image(image: Image.Image, strength: float) -> Image.Image:
    # Only tiny high-frequency displacement hints; avoid treating photo lighting
    # and large shadows as real topography. Tangent-space flat = (128,128,255).
    luminance = ImageOps.grayscale(image)
    smooth = luminance.filter(ImageFilter.GaussianBlur(3.5))
    high = ImageChops.subtract(luminance, smooth, offset=128)
    horizontal = high.filter(ImageFilter.Kernel((3, 3), [-1, 0, 1, -2, 0, 2, -1, 0, 1], scale=8, offset=128))
    vertical = high.filter(ImageFilter.Kernel((3, 3), [-1, -2, -1, 0, 0, 0, 1, 2, 1], scale=8, offset=128))
    amp = max(0.0, min(0.23, float(strength) * 0.16))
    clamp = lambda c: c.point(lambda x: max(116, min(140, round(128 + (x - 128) * amp))))
    return Image.merge('RGB', (clamp(horizontal), clamp(vertical), Image.new('L', image.size, 254)))


def _roughness_from_image(image: Image.Image, kind: str) -> Image.Image:
    # Conservative dielectric presets; a photograph cannot uniquely determine
    # roughness because ambient light and albedo also affect its brightness.
    base = {'face': 176, 'hand': 182, 'hair': 176, 'clothes': 206, 'body': 198}.get(kind, 194)
    gray = ImageOps.grayscale(image)
    soft = gray.filter(ImageFilter.GaussianBlur(2.0))
    detail = ImageChops.difference(gray, soft).point(lambda x: min(24, x // 3))
    return ImageChops.subtract(Image.new('L', image.size, base), detail)


def _ao_hint_from_image(image: Image.Image) -> Image.Image:
    # AO cannot be determined from photo brightness. Neutral AO (white) prevents
    # shadows, hair and black garments from being interpreted as occlusion.
    return Image.new('L', image.size, 255)


def build_pbr_channels(image: Image.Image, kind: str):
    strength = {'face': 0.35, 'hand': 0.30, 'hair': 0.20, 'clothes': 0.52}.get(kind, 0.26)
    normal = _normal_from_image(image, strength)
    roughness = _roughness_from_image(image, kind)
    ao = _ao_hint_from_image(image)
    orm = Image.merge('RGB', (ao, roughness, Image.new('L', image.size, 0)))
    return normal, roughness, ao, orm


def generate_pbr_maps(source: Path, output_dir: Path, *, key: str, max_size: int) -> dict[str, str]:
    output_dir.mkdir(parents=True, exist_ok=True)
    image = _bounded_rgb(Path(source), max_size)
    normal, roughness, ao, orm = build_pbr_channels(image, _kind(key))
    normal_path = output_dir / f'{key}_normal.png'
    rough_path = output_dir / f'{key}_roughness.png'
    ao_path = output_dir / f'{key}_ao.png'
    orm_path = output_dir / f'{key}_orm.png'
    normal.save(normal_path, format='PNG', optimize=True)
    roughness.save(rough_path, format='PNG', optimize=True)
    ao.save(ao_path, format='PNG', optimize=True)
    orm.save(orm_path, format='PNG', optimize=True)
    return {'normal': str(normal_path.resolve()), 'roughness': str(rough_path.resolve()),
            'ao': str(ao_path.resolve())}


def generate_pbr_set(images: Mapping[str, Path], output_dir: Path, max_size: int) -> dict[str, dict[str, str]]:
    return {key: generate_pbr_maps(Path(path), output_dir, key=key, max_size=max_size)
            for key, path in images.items() if Path(path).exists()}
