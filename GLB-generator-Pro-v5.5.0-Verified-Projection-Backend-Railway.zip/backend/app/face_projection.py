from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Any

from .imagefit import estimate_projection_crop


@dataclass(frozen=True)
class FaceProjectionPlan:
    available: bool
    preferred_keys: tuple[str, ...]
    crop_weight: float
    warp_strength: float


def build_face_projection_plan(image_paths: Mapping[str, Path], quality_mode: str) -> FaceProjectionPlan:
    preferred = (
        'face_front', 'face_left_45', 'face_right_45',
        'face_left_profile', 'face_right_profile',
        'face_45', 'front_45', 'front'
    )
    keys = tuple(key for key in preferred if key in image_paths and Path(image_paths[key]).exists())
    mode = (quality_mode or 'pro_hq').lower()
    if mode == 'ultra_detail':
        crop_weight, warp_strength = 0.84, 0.94
    elif mode == 'pro_fidelity':
        crop_weight, warp_strength = 0.74, 0.88
    else:
        crop_weight, warp_strength = 0.62, 0.66
    return FaceProjectionPlan(bool(keys), keys, crop_weight, warp_strength)


def estimate_face_crops(image_paths: Mapping[str, Path], plan: FaceProjectionPlan) -> dict[str, list[float]]:
    out: dict[str, list[float]] = {}
    for key in plan.preferred_keys:
        path = Path(image_paths[key])
        try:
            out[key] = list(estimate_projection_crop(path, face=True))
        except Exception:
            out[key] = [0.0, 0.0, 1.0, 1.0]
    return out


def manifest_values(plan: FaceProjectionPlan) -> dict[str, Any]:
    return {
        'face_projection_available': bool(plan.available),
        'face_projection_sources': list(plan.preferred_keys),
        'face_crop_weight': float(plan.crop_weight),
        'face_warp_strength': float(plan.warp_strength),
    }
