from __future__ import annotations

from pathlib import Path
import asyncio
import json
import shutil

from .config import Settings
from .provider import HunyuanProvider, ProviderQuotaExceeded
from .refiner import BlenderRefiner
from .store import JobStore, after_seconds_iso


class JobCancelled(RuntimeError):
    pass


async def process_job(
    store: JobStore,
    settings: Settings,
    job_id: str,
    *,
    provider=None,
    refiner=None,
):
    job = store.get_job(job_id)
    if job is None:
        return
    provider = provider or HunyuanProvider(settings)
    is_v3 = (job.get("quality_mode") or "legacy") in {"standard", "pro_hq", "pro_fidelity", "ultra_detail"}
    generation_mode = (job.get("generation_mode") or "cloud_only").lower()
    output_mode = (job.get("output_mode") or "full_glb").lower()
    texture_mode = (job.get("texture_mode") or "auto").lower()

    def ensure_not_cancelled():
        if store.is_cancelled(job_id):
            raise JobCancelled(job_id)

    def on_update(provider_name: str, status: str, progress: int, message: str):
        if store.is_cancelled(job_id):
            return
        store.update_job(
            job_id,
            status=status,
            progress=max(0, min(99, int(progress))),
            message=message,
            provider=provider_name,
        )

    try:
        ensure_not_cancelled()
        store.update_job(
            job_id,
            status="waiting_provider",
            progress=10,
            message="Generation worker accepted the job",
            attempt_count=int(job.get("attempt_count") or 0) + 1,
            last_error=None,
            retry_after_at=None,
            local_fallback_required=0,
        )

        if not is_v3:
            output = settings.jobs_dir / job_id / "output" / "character.glb"
            await asyncio.to_thread(
                provider.generate,
                front=Path(job["front_path"]),
                back=Path(job["back_path"]),
                left=Path(job["left_path"]),
                right=Path(job["right_path"]),
                output=output,
                on_update=on_update,
            )
            ensure_not_cancelled()
            if not output.exists() or output.stat().st_size < 4:
                raise RuntimeError("Provider completed without a valid GLB output")
            store.update_job(
                job_id,
                status="completed",
                progress=100,
                message="character.glb is ready",
                output_path=str(output),
                last_error=None,
            )
            return

        ensure_not_cancelled()
        work_dir = settings.jobs_dir / job_id / "work"
        output_dir = settings.jobs_dir / job_id / "output"
        base_glb = work_dir / "base.glb"
        preview_glb = output_dir / "preview.glb"
        high_quality_glb = output_dir / "high_quality.glb"
        work_dir.mkdir(parents=True, exist_ok=True)
        output_dir.mkdir(parents=True, exist_ok=True)

        existing_base = Path(job.get("base_path") or base_glb)
        if existing_base.exists() and existing_base.is_file() and existing_base.stat().st_size >= 4:
            base_glb = existing_base
            store.update_job(
                job_id,
                base_path=str(base_glb),
                status="refining",
                progress=max(58, int(job.get("progress") or 0)),
                message="Reusing saved base geometry; resuming Blender Pro refinement",
                preview_path=None,
                high_quality_path=None,
                output_path=None,
                local_fallback_required=0,
            )
        else:
            reusable_base = await asyncio.to_thread(store.find_reusable_base, job_id)
            if reusable_base is not None:
                base_glb.parent.mkdir(parents=True, exist_ok=True)
                await asyncio.to_thread(shutil.copyfile, reusable_base, base_glb)
                store.update_job(
                    job_id,
                    base_path=str(base_glb),
                    status="refining",
                    progress=58,
                    message="Reusing geometry from an identical previous photo set; skipping GPU generation",
                    preview_path=None,
                    high_quality_path=None,
                    output_path=None,
                    local_fallback_required=0,
                )
            else:
                await asyncio.to_thread(
                    provider.generate,
                    front=Path(job["front_path"]),
                    back=Path(job["back_path"]),
                    left=Path(job["left_path"]),
                    right=Path(job["right_path"]),
                    output=base_glb,
                    on_update=on_update,
                )
            ensure_not_cancelled()
            if not base_glb.exists() or base_glb.stat().st_size < 4:
                raise RuntimeError("Provider completed without a valid base GLB")
            store.update_job(
                job_id,
                base_path=str(base_glb),
                status="refining",
                progress=58,
                message="Base geometry stored; starting Blender Pro refinement",
                preview_path=None,
                high_quality_path=None,
                output_path=None,
                local_fallback_required=0,
            )

        texture_project_value = job.get("texture_project_path")
        has_texture_project = bool(texture_project_value and Path(texture_project_value).exists())
        if (output_mode == "mesh_only" or texture_mode == "none") and not has_texture_project:
            # v5.0 ZERO pipeline: never publish the provider/base mesh immediately.  Run the
            # same high-quality geometry repair/refinement stage used by Pro output, but with
            # texture projection disabled.  This keeps provider facial/clothing geometry while
            # repairing topology and prevents a draft/base GLB from leaking as a final result.
            zero_images: dict[str, Path] = {
                "front": Path(job["front_path"]), "back": Path(job["back_path"]),
                "left": Path(job["left_path"]), "right": Path(job["right_path"]),
            }
            for source_name, column in (("front_45", "front_45_path"), ("back_45", "back_45_path"),
                                        ("face_front", "face_front_path"), ("face_45", "face_45_path"),
                                        ("face_left_45", "face_left_45_path"), ("face_right_45", "face_right_45_path"),
                                        ("face_left_profile", "face_left_profile_path"), ("face_right_profile", "face_right_profile_path")):
                value = job.get(column)
                if value:
                    zero_images[source_name] = Path(value)

            zero_refiner = refiner or BlenderRefiner(settings)
            def on_zero_update(status: str, progress: int, message: str):
                if not store.is_cancelled(job_id):
                    store.update_job(job_id, status=status, progress=max(58, min(99, int(progress))),
                                     message=f"ZERO geometry · {message}", provider="Blender 4.5 ZERO Geometry")
            await asyncio.to_thread(
                zero_refiner.refine,
                base_glb=base_glb, image_paths=zero_images, preview_glb=preview_glb,
                high_quality_glb=high_quality_glb, quality_mode=job.get("quality_mode") or "ultra_detail",
                remesh=False, on_update=on_zero_update, manifest_extra={"texture_mode": "none", "manual_regions": []},
            )
            ensure_not_cancelled()
            if not high_quality_glb.exists() or high_quality_glb.stat().st_size < 4:
                raise RuntimeError("ZERO geometry refinement completed without a valid high-quality GLB")
            store.update_job(
                job_id, status="completed", progress=100,
                message="ZERO high-detail geometry GLB is ready", provider="Blender 4.5 ZERO Geometry",
                output_path=str(high_quality_glb), preview_path=str(preview_glb if preview_glb.exists() else high_quality_glb),
                high_quality_path=str(high_quality_glb), last_error=None, local_fallback_required=0,
            )
            return

        image_paths: dict[str, Path] = {
            "front": Path(job["front_path"]),
            "back": Path(job["back_path"]),
            "left": Path(job["left_path"]),
            "right": Path(job["right_path"]),
        }
        for source_name, column in (
            ("front_45", "front_45_path"),
            ("back_45", "back_45_path"),
            ("face_front", "face_front_path"),
            ("face_45", "face_45_path"),
            ("face_left_45", "face_left_45_path"),
            ("face_right_45", "face_right_45_path"),
            ("face_left_profile", "face_left_profile_path"),
            ("face_right_profile", "face_right_profile_path"),
            ("left_hand", "left_hand_path"),
            ("right_hand", "right_hand_path"),
            ("hair_detail", "hair_detail_path"),
            ("clothes_detail", "clothes_detail_path"),
        ):
            value = job.get(column)
            if value:
                image_paths[source_name] = Path(value)

        ensure_not_cancelled()
        refiner = refiner or BlenderRefiner(settings)

        def on_refine_update(status: str, progress: int, message: str):
            if store.is_cancelled(job_id):
                return
            store.update_job(
                job_id,
                status=status,
                progress=max(58, min(99, int(progress))),
                message=message,
                provider="Blender 4.5 Ultra Detail" if (job.get("quality_mode") or "") == "ultra_detail" else "Blender 4.5 Pro Fidelity",
            )

        refine_kwargs = dict(
            base_glb=base_glb,
            image_paths=image_paths,
            preview_glb=preview_glb,
            high_quality_glb=high_quality_glb,
            quality_mode=job.get("quality_mode") or "pro_fidelity",
            remesh=bool(job.get("remesh")),
            on_update=on_refine_update,
        )
        import inspect
        if "should_cancel" in inspect.signature(refiner.refine).parameters:
            refine_kwargs["should_cancel"] = lambda: store.is_cancelled(job_id)
        manifest_extra = {"texture_mode": texture_mode}
        if texture_project_value and Path(texture_project_value).exists():
            project_path = Path(texture_project_value)
            project = json.loads(project_path.read_text(encoding="utf-8"))
            manual_regions = []
            for region in project.get("regions") or []:
                item = dict(region)
                source = str(item.get("source") or "")
                source_path = None
                if source.startswith("asset:"):
                    asset_id = source.split(":", 1)[1]
                    matches = sorted((project_path.parent / "manual_textures").glob(f"{asset_id}.*"))
                    if matches:
                        source_path = matches[0]
                elif source in image_paths:
                    source_path = image_paths[source]
                if source_path is None or not Path(source_path).exists():
                    continue
                item["image_path"] = str(Path(source_path).resolve())
                manual_regions.append(item)
            manifest_extra["texture_mode"] = str(project.get("mode") or texture_mode)
            manifest_extra["manual_regions"] = manual_regions
        calibration_file = settings.jobs_dir / job_id / 'calibration.json'
        if calibration_file.is_file():
            calibration = json.loads(calibration_file.read_text(encoding='utf-8'))
            manifest_extra['multiview_landmarks'] = calibration.get('landmarks', {})
        if manifest_extra.get("texture_mode") != "auto" or manifest_extra.get("manual_regions") or manifest_extra.get('multiview_landmarks'):
            refine_kwargs["manifest_extra"] = manifest_extra

        await asyncio.to_thread(refiner.refine, **refine_kwargs)
        ensure_not_cancelled()
        if not preview_glb.exists() or preview_glb.stat().st_size < 4:
            raise RuntimeError("Blender completed without preview.glb")
        if not high_quality_glb.exists() or high_quality_glb.stat().st_size < 4:
            raise RuntimeError("Blender completed without high_quality.glb")

        mode = (job.get("quality_mode") or "").lower()
        final_provider = (
            "Hunyuan + Blender 4.5 Ultra Detail"
            if mode == "ultra_detail"
            else "Hunyuan + Blender 4.5 Pro Fidelity"
            if mode == "pro_fidelity"
            else "Hunyuan + Blender 4.5 Pro"
        )
        store.update_job(
            job_id,
            status="completed",
            progress=100,
            message="preview.glb and high_quality.glb are ready",
            provider=final_provider,
            preview_path=str(preview_glb),
            high_quality_path=str(high_quality_glb),
            output_path=str(high_quality_glb),
            last_error=None,
        )
        store.prune_terminal_jobs(settings.jobs_dir, settings.retain_terminal_jobs)
    except JobCancelled:
        return
    except ProviderQuotaExceeded as exc:
        if store.is_cancelled(job_id):
            return
        wait_seconds = max(60, int(exc.retry_after_seconds))
        progress = max(20, min(int((store.get_job(job_id) or {}).get("progress") or 20), 55))
        if generation_mode == "auto":
            store.update_job(
                job_id,
                status="awaiting_local",
                progress=progress,
                message="Cloud GPU quota reached; local Android fallback requested",
                provider="Android Local Fallback",
                last_error=str(exc)[:1000],
                retry_after_at=None,
                local_fallback_required=1,
            )
        else:
            hours, rem = divmod(wait_seconds, 3600)
            minutes = rem // 60
            store.update_job(
                job_id,
                status="queued",
                progress=progress,
                message=f"ZeroGPU quota reached; automatic retry scheduled in {hours}h {minutes}m",
                provider="Hugging Face ZeroGPU",
                last_error=str(exc)[:1000],
                retry_after_at=after_seconds_iso(wait_seconds),
                local_fallback_required=0,
            )
        return
    except asyncio.CancelledError:
        if not store.is_cancelled(job_id):
            store.update_job(
                job_id,
                status="queued",
                progress=5,
                message="Backend restart interrupted processing; job will resume",
            )
        raise
    except BaseException as exc:
        if store.is_cancelled(job_id):
            return
        store.update_job(
            job_id,
            status="failed",
            progress=min(int((store.get_job(job_id) or {}).get("progress") or 0), 99),
            message="Generation could not complete after server-side retries",
            last_error=str(exc)[:1000],
        )


async def worker_loop(store: JobStore, settings: Settings):
    while True:
        job = store.next_queued()
        if job is None:
            await asyncio.sleep(settings.poll_interval_seconds)
            continue
        await process_job(store, settings, job["id"])
        await asyncio.sleep(0)
