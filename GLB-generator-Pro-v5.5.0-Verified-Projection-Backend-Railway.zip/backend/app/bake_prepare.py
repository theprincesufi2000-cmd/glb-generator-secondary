"""Preserve alpha, physical proportions and original camera colors for baking.

Unlike the legacy per-view atlas, this stage neither stretches a face to a
square tile nor fills transparency with RGB black.  The silhouette is used only
for camera fitting, not as the final color map.
"""
from __future__ import annotations
from pathlib import Path
from typing import Mapping
from PIL import Image, ImageOps
from .imagefit import _foreground_mask


def prepare_multiview_inputs(images: Mapping[str, Path], output_dir: Path, *,
                             body_cap: int = 2048, face_cap: int = 2048):
    output_dir.mkdir(parents=True, exist_ok=True)
    result = {}
    for name, path in images.items():
        try:
            source_handle = Image.open(path)
        except (OSError, ValueError):
            # Legacy stubs in existing SDK tests are not real image files.
            # Skip them; the refiner retains the legacy fallback route.
            continue
        with source_handle as source:
            source = ImageOps.exif_transpose(source)
            has_alpha = 'A' in source.getbands() or 'transparency' in source.info
            rgba = source.convert('RGBA')
            if not has_alpha or rgba.getchannel('A').getextrema()[0] >= 250:
                inferred = _foreground_mask(source)
                if inferred.size != rgba.size:
                    inferred = inferred.resize(rgba.size, Image.Resampling.BILINEAR)
                rgba.putalpha(inferred)
            max_dim = face_cap if name.startswith('face_') else body_cap
            rgba.thumbnail((max(512, max_dim), max(512, max_dim)), Image.Resampling.LANCZOS)
            outfile = output_dir / f'{name}.png'
            rgba.save(outfile, format='PNG', optimize=False)
            result[name] = outfile.resolve()
    return result
