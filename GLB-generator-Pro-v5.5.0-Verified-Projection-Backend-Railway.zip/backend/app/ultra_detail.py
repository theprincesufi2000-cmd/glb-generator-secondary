from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class UltraDetailPlan:
    enabled: bool
    body_texture_cap: int
    face_texture_cap: int
    hand_texture_cap: int
    pbr_map_cap: int
    target_hq_triangles: int
    target_preview_triangles: int
    face_subdivide_budget: int
    hand_subdivide_budget: int
    clothing_subdivide_budget: int
    hair_subdivide_budget: int
    staged_blender: bool


def build_ultra_detail_plan(quality_mode: str, memory_profile: str) -> UltraDetailPlan:
    ultra = (quality_mode or "").strip().lower() == "ultra_detail"
    profile = (memory_profile or "1gb").strip().lower()
    if not ultra:
        return UltraDetailPlan(False, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, False)
    if profile == "1gb":
        return UltraDetailPlan(True, 1664, 3328, 2048, 2048, 320000, 90000, 110000, 70000, 65000, 50000, True)
    if profile == "2gb":
        return UltraDetailPlan(True, 2816, 4608, 3328, 3328, 560000, 150000, 200000, 140000, 120000, 80000, True)
    return UltraDetailPlan(True, 4608, 6656, 4608, 4608, 980000, 240000, 340000, 240000, 210000, 120000, False)


def manifest_values(plan: UltraDetailPlan) -> dict[str, Any]:
    return {
        "ultra_detail": bool(plan.enabled),
        "projection_body_max_size": int(plan.body_texture_cap),
        "projection_face_max_size": int(plan.face_texture_cap),
        "projection_hand_max_size": int(plan.hand_texture_cap),
        "pbr_map_max_size": int(plan.pbr_map_cap),
        "hq_max_triangles": int(plan.target_hq_triangles),
        "preview_max_triangles": int(plan.target_preview_triangles),
        "face_subdivide_budget": int(plan.face_subdivide_budget),
        "hand_subdivide_budget": int(plan.hand_subdivide_budget),
        "clothing_subdivide_budget": int(plan.clothing_subdivide_budget),
        "hair_subdivide_budget": int(plan.hair_subdivide_budget),
    }
