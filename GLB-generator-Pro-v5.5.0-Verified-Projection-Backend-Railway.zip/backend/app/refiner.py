from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
import os
import subprocess
import tempfile
from typing import Callable, Mapping, Any

from .config import Settings
from .imagefit import estimate_projection_crop, prepare_projection_texture
from .geometry_repair import build_geometry_repair_plan, manifest_values as geometry_manifest_values
from .uv_pipeline import build_uv_policy, manifest_values as uv_manifest_values
from .face_projection import build_face_projection_plan, estimate_face_crops, manifest_values as face_manifest_values
from .body_projection import build_body_projection_plan, manifest_values as body_manifest_values
from .texture_cleanup import clean_projection_texture
from .glb_validation import validate_glb_file, validate_single_pbr_atlas
from .feature_regions import build_feature_reference_plan, manifest_values as feature_manifest_values
from .ultra_detail import build_ultra_detail_plan, manifest_values as ultra_manifest_values
from .pbr_maps import generate_pbr_set
from .texture_atlas import build_projection_atlas
from .bake_prepare import prepare_multiview_inputs


class RefinementError(RuntimeError):
    pass


@dataclass(frozen=True)
class RefinementResult:
    preview_glb: Path
    high_quality_glb: Path


class BlenderRefiner:
    def __init__(self, settings: Settings, script_path: Path | None = None):
        self.settings = settings
        self.script_path = script_path or (Path(__file__).resolve().parent.parent / 'blender' / 'refine_glb.py')

    @staticmethod
    def _valid_glb(path: Path) -> bool:
        return path.exists() and path.is_file() and path.stat().st_size >= 4

    def refine(
        self,
        *,
        base_glb: Path,
        image_paths: Mapping[str, Path],
        preview_glb: Path,
        high_quality_glb: Path,
        quality_mode: str,
        remesh: bool,
        on_update: Callable[[str, int, str], None],
        manifest_extra: Mapping[str, Any] | None = None,
        should_cancel: Callable[[], bool] | None = None,
    ) -> RefinementResult:
        if not self._valid_glb(base_glb):
            raise RefinementError('Base GLB is missing or invalid')
        if quality_mode not in {'standard', 'pro_hq', 'pro_fidelity', 'ultra_detail'}:
            raise RefinementError(f'Unsupported quality mode: {quality_mode}')
        if not self.script_path.exists():
            raise RefinementError(f'Blender refinement script is missing: {self.script_path}')

        preview_glb.parent.mkdir(parents=True, exist_ok=True)
        high_quality_glb.parent.mkdir(parents=True, exist_ok=True)
        if quality_mode == 'standard':
            texture_size = self.settings.standard_texture_size
        elif quality_mode == 'ultra_detail':
            texture_size = self.settings.ultra_detail_texture_size
        elif quality_mode == 'pro_fidelity':
            texture_size = self.settings.pro_fidelity_texture_size
        else:
            texture_size = self.settings.hq_texture_size
        profile = self.settings.blender_memory_profile
        if profile == '1gb':
            body_cap, face_cap = 1536, 2304
            preview_triangles = min(self.settings.preview_max_triangles, 60000)
            requested_hq = min(self.settings.ultra_detail_max_triangles, 280000) if quality_mode == 'ultra_detail' else (min(self.settings.pro_fidelity_max_triangles, 260000) if quality_mode == 'pro_fidelity' else min(self.settings.hq_max_triangles, 150000))
        elif profile == '2gb':
            body_cap, face_cap = 2048, 3072
            preview_triangles = min(max(self.settings.preview_max_triangles, 100000), 130000)
            requested_hq = max(self.settings.ultra_detail_max_triangles, 520000) if quality_mode == 'ultra_detail' else (max(self.settings.pro_fidelity_max_triangles, 420000) if quality_mode == 'pro_fidelity' else max(self.settings.hq_max_triangles, 300000))
        else:
            body_cap, face_cap = 3072, 4096
            preview_triangles = max(self.settings.preview_max_triangles, 140000)
            requested_hq = max(self.settings.ultra_detail_max_triangles, 900000) if quality_mode == 'ultra_detail' else (max(self.settings.pro_fidelity_max_triangles, 700000) if quality_mode == 'pro_fidelity' else max(self.settings.hq_max_triangles, 500000))

        ultra_plan = build_ultra_detail_plan(quality_mode, profile)
        if ultra_plan.enabled:
            body_cap = ultra_plan.body_texture_cap
            face_cap = ultra_plan.face_texture_cap
        valid_images = {key: Path(value).resolve() for key, value in image_paths.items() if value and Path(value).exists()}
        on_update('preprocessing', 60, 'Preparing source photos for region-aware high-detail projection')
        prepared_dir = base_glb.parent / ('prepared_projection_v480' if quality_mode == 'ultra_detail' else ('prepared_projection_v470' if quality_mode == 'pro_fidelity' else 'prepared_projection_v309'))
        prepared_dir.mkdir(parents=True, exist_ok=True)
        prepared_images: dict[str, Path] = {}
        projection_crops: dict[str, list[float]] = {}
        detail_keys = {'left_hand', 'right_hand', 'hair_detail', 'clothes_detail'}
        for key, image_path in valid_images.items():
            prepared = prepared_dir / f'{key}.png'
            cleaned = prepared_dir / f'{key}_clean.png'
            is_face = key.startswith('face_')
            is_detail_closeup = key in detail_keys
            try:
                if is_detail_closeup:
                    clean_projection_texture(image_path, cleaned, face=False, max_size=(ultra_plan.hand_texture_cap if key.endswith('_hand') and ultra_plan.enabled else body_cap))
                    prepared_images[key] = cleaned.resolve()
                else:
                    prepare_projection_texture(image_path, prepared, face=is_face)
                    if quality_mode in {'pro_fidelity', 'ultra_detail'}:
                        clean_projection_texture(prepared, cleaned, face=is_face, max_size=(face_cap if is_face else body_cap))
                        prepared_images[key] = cleaned.resolve()
                    else:
                        prepared_images[key] = prepared.resolve()
                projection_crops[key] = [0.0, 0.0, 1.0, 1.0]
            except Exception:
                prepared_images[key] = image_path
                try:
                    projection_crops[key] = [0.0, 0.0, 1.0, 1.0] if is_detail_closeup else list(estimate_projection_crop(image_path, face=is_face))
                except Exception:
                    projection_crops[key] = [0.0, 0.0, 1.0, 1.0]

        geometry_plan = build_geometry_repair_plan(
            quality_mode=quality_mode,
            remesh=remesh,
            memory_profile=profile,
            requested_hq_triangles=requested_hq,
            requested_preview_triangles=preview_triangles,
        )
        uv_policy = build_uv_policy(quality_mode, texture_size)
        face_plan = build_face_projection_plan(prepared_images, quality_mode)
        body_plan = build_body_projection_plan(prepared_images, quality_mode)
        feature_plan = build_feature_reference_plan(prepared_images, quality_mode)
        # Prepared face photos are ALREADY head-cropped and edge-filled.
        # Re-estimating a second face crop on them warps eye/lip placement.
        face_projection_crops = {key: list(projection_crops.get(key, [0., 0., 1., 1.]))
                                 for key in prepared_images if key.startswith('face_')}
        # Each atlas channel uses the exact same pixel-to-UV transform.
        # Allocate conservatively on the 1GB Railway image; override via
        # GLB_ATLAS_MAX_SIZE only when the cloud container has enough RAM.
        import os
        atlas_budget = int(os.getenv('GLB_ATLAS_MAX_SIZE',
                                  '3072' if profile == '1gb' else ('4096' if profile == '2gb' else '6144')))
        atlas_enabled = str((manifest_extra or {}).get('texture_mode', 'auto')).lower() in {'auto', 'hybrid'}
        bake_enabled = (atlas_enabled and str(os.getenv('GLB_MULTIVIEW_BAKE_ENABLED', '1')).lower() not in {'0','false','off'}
                        and bool((manifest_extra or {}).get('multiview_baking', True)))
        # The old packed tile atlas cannot produce seam-safe multiview baking.
        # Preserve it for explicit fallback only; default to the true surface bake.
        projection_atlas = (build_projection_atlas(prepared_images, prepared_dir / 'atlas', max_size=atlas_budget)
                            if atlas_enabled and not bake_enabled else {})
        bake_images = (prepare_multiview_inputs(
            valid_images, prepared_dir / 'bake_input',
            body_cap=1024 if profile == '1gb' else body_cap,
            face_cap=1280 if profile == '1gb' else face_cap,
        ) if bake_enabled else {})
        if bake_enabled and not bake_images:
            bake_enabled = False
        strict_requested = (atlas_enabled and
                            str(os.getenv('GLB_STRICT_GEOMETRIC_TEXTURES','1')).lower()
                            not in {'0','false','off'})
        if strict_requested and not bake_enabled:
            # Fail closed: no silent reversion to the old eight-view tiled UV
            # shaders when an automatic photograph bake was requested.
            raise RefinementError('STRICT_TEXTURE_BAKE_UNAVAILABLE: true multiview input'
                                  ' or Blender baking is unavailable; legacy projection is forbidden')
        pbr_maps: dict[str, dict[str, str]] = {}
        if ultra_plan.enabled:
            on_update('face_refinement', 64, 'Preparing face/ear references for Ultra Detail')
            on_update('hand_refinement', 67, 'Preparing hand and finger close-ups')
            on_update('hair_refinement', 70, 'Preparing hairline and hairstyle detail')
            on_update('clothing_refinement', 73, 'Preparing clothing seams and fabric detail')
            # Legacy per-view maps remain supported by Blender when no atlas is
            # available; avoid duplicating them and exhausting 1GB Railway RAM.
            if not projection_atlas:
                pbr_maps = generate_pbr_set(prepared_images, prepared_dir / 'pbr', ultra_plan.pbr_map_cap)
            on_update('pbr_maps', 77, 'Generating tangent normal, roughness and occlusion detail maps')
        on_update('watertight_repair', 79 if ultra_plan.enabled else 64, 'Sealing boundaries while preserving provider geometry')
        on_update('uv_unwrap', 81 if ultra_plan.enabled else 68, 'Configuring region-priority UV projection')
        on_update('face_projection', 83 if ultra_plan.enabled else 72, 'Aligning face projection sources with tighter crops')
        on_update('body_projection', 85 if ultra_plan.enabled else 76, 'Preparing multiview body projections and gap filling')
        on_update('texture_baking', 87 if ultra_plan.enabled else 80, 'Cleaning seams and preparing high-detail PBR projection')

        manifest: dict[str, Any] = {
            'base_glb': str(base_glb.resolve()),
            'preview_glb': str(preview_glb.resolve()),
            'high_quality_glb': str(high_quality_glb.resolve()),
            'quality_mode': quality_mode,
            'remesh': bool(remesh),
            'texture_size': int(texture_size),
            'preview_texture_size': int(self.settings.preview_texture_size),
            'texture_strategy': 'ultra_feature_region_pbr_projection_v1' if quality_mode == 'ultra_detail' else ('cloud_pro_fidelity_segmented_projection' if quality_mode == 'pro_fidelity' else 'subject_fitted_edgefilled_multi_view_projection_v3'),
            'projection_crops': projection_crops,
            'face_projection_crops': face_projection_crops,
            'force_texture_coverage': quality_mode in {'pro_fidelity', 'ultra_detail'},
            'pbr_maps': pbr_maps,
            'projection_atlas': projection_atlas,
            'multiview_baking': bake_enabled,
            # Strict means never label silhouette-aligned approximate textures
            # as verified. Explicit calibration is required to produce HQ GLB.
            'strict_projection': str(os.getenv('GLB_STRICT_GEOMETRIC_TEXTURES', '1')).lower() not in {'0','false','off'},
            'multiview_images': {k: str(v) for k, v in bake_images.items()},
            'multiview_bake_size': int(os.getenv('GLB_MULTIVIEW_BAKE_SIZE',
                                                 '2048' if profile == '1gb' else
                                                 ('3072' if profile == '2gb' else '4096'))),
            'memory_profile': profile,
            'projection_body_max_size': int(body_cap if quality_mode in {'pro_hq', 'pro_fidelity'} else min(body_cap, 1024)),
            'projection_face_max_size': int(face_cap if quality_mode in {'pro_hq', 'pro_fidelity'} else min(face_cap, 1536)),
            'images': {key: str(value) for key, value in prepared_images.items()},
        }
        manifest.update(geometry_manifest_values(geometry_plan))
        manifest.update(uv_manifest_values(uv_policy))
        manifest.update(face_manifest_values(face_plan))
        manifest.update(body_manifest_values(body_plan))
        manifest.update(feature_manifest_values(feature_plan))
        if ultra_plan.enabled:
            manifest.update(ultra_manifest_values(ultra_plan))
        if manifest_extra:
            manifest.update(dict(manifest_extra))

        manifest_dir = base_glb.parent
        manifest_dir.mkdir(parents=True, exist_ok=True)
        fd, manifest_name = tempfile.mkstemp(prefix='refine-', suffix='.json', dir=manifest_dir)
        os.close(fd)
        manifest_path = Path(manifest_name)
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')

        def run_blender(stage_manifest: dict[str, Any], stage_name: str) -> str:
            fd2, stage_manifest_name = tempfile.mkstemp(prefix=f'refine-{stage_name}-', suffix='.json', dir=manifest_dir)
            os.close(fd2)
            stage_manifest_path = Path(stage_manifest_name)
            stage_manifest_path.write_text(json.dumps(stage_manifest, ensure_ascii=False, indent=2), encoding='utf-8')
            command = [
                self.settings.blender_executable,
                '-b',
                '--factory-startup',
                '--python',
                str(self.script_path),
                '--',
                str(stage_manifest_path),
            ]
            process = None
            output = ''
            log_fd, log_name = tempfile.mkstemp(prefix=f'blender-{stage_name}-', suffix='.log', dir=manifest_dir)
            os.close(log_fd)
            log_path = Path(log_name)
            try:
                with log_path.open('w+', encoding='utf-8', errors='replace') as log_handle:
                    process = subprocess.Popen(
                        command,
                        stdout=log_handle,
                        stderr=subprocess.STDOUT,
                        text=True,
                    )
                    deadline = __import__('time').monotonic() + float(self.settings.blender_timeout_seconds)
                    while process.poll() is None:
                        if should_cancel is not None and should_cancel():
                            process.terminate()
                            try:
                                process.wait(timeout=5)
                            except subprocess.TimeoutExpired:
                                process.kill()
                                process.wait(timeout=5)
                            raise RefinementError('Generation cancelled by user')
                        if __import__('time').monotonic() >= deadline:
                            process.terminate()
                            try:
                                process.wait(timeout=5)
                            except subprocess.TimeoutExpired:
                                process.kill()
                                process.wait(timeout=5)
                            raise RefinementError(f'Blender {stage_name} stage timed out after {self.settings.blender_timeout_seconds}s')
                        __import__('time').sleep(0.35)
                    log_handle.flush()
                    log_handle.seek(0)
                    output = log_handle.read() or ''
                returncode = int(process.returncode or 0)
            except FileNotFoundError as exc:
                raise RefinementError(f'Blender executable not found: {self.settings.blender_executable}') from exc
            finally:
                stage_manifest_path.unlink(missing_ok=True)
                log_path.unlink(missing_ok=True)
            if returncode != 0:
                tail = output[-7000:]
                raise RefinementError(f'Blender {stage_name} stage failed (exit {returncode}): {tail}')
            return output

        manifest_path.unlink(missing_ok=True)
        if quality_mode in {'pro_fidelity', 'ultra_detail'} and profile == '1gb':
            # Railway's 1 GB worker cannot safely keep the provider mesh, its detail
            # duplicate, voxel remesh, 8 decoded source photos, and GLB export buffers
            # alive in one Blender process. Use isolated processes so memory is fully
            # returned to the OS between geometry, HQ texturing, and preview export.
            stage_geometry_glb = base_glb.parent / ('ultra_detail_geometry_stage.glb' if quality_mode == 'ultra_detail' else 'pro_fidelity_geometry_stage.glb')
            on_update('watertight_repair', 88 if quality_mode == 'ultra_detail' else 84, 'Stage 1/3: sealing geometry and densifying high-value feature regions')
            geometry_manifest = dict(manifest)
            geometry_manifest.update({
                'pipeline_stage': 'geometry',
                'stage_geometry_glb': str(stage_geometry_glb.resolve()),
                'images': {},
                'watertight_strategy': 'boundary_seal',
                'restore_detail': False,
                'feature_subdivide': bool(manifest.get('feature_subdivide')),
                'face_subdivide_budget': int(manifest.get('face_subdivide_budget', 0)),
                'hand_subdivide_budget': int(manifest.get('hand_subdivide_budget', 0)),
                'clothing_subdivide_budget': int(manifest.get('clothing_subdivide_budget', 0)),
            })
            try:
                run_blender(geometry_manifest, 'geometry')
            except RefinementError:
                # Automatic rescue pass for unusually dense provider meshes. Keep
                # the model watertight but reduce voxel peak and skip the temporary
                # detail duplicate only when the maximum-detail pass cannot fit.
                stage_geometry_glb.unlink(missing_ok=True)
                rescue_geometry = dict(geometry_manifest)
                rescue_geometry.update({
                    'voxel_resolution_divisor': 420.0,
                    'hq_max_triangles': min(int(manifest.get('hq_max_triangles', 240000)), 190000),
                    'smoothing_passes': 0,
                    'restore_detail': False,
                    'watertight_strategy': 'boundary_seal',
                })
                on_update('watertight_repair', 86, 'Stage 1/3 rescue: memory-safe watertight topology')
                run_blender(rescue_geometry, 'geometry-rescue')
            geometry_result = validate_glb_file(stage_geometry_glb)
            if not geometry_result.ok:
                raise RefinementError(f'Geometry stage did not produce a valid GLB: {geometry_result.message}')

            on_update('texture_baking', 93 if quality_mode == 'ultra_detail' else 90, 'Stage 2/3: projecting region-specific textures and PBR detail maps')
            hq_manifest = dict(manifest)
            hq_manifest.update({
                'pipeline_stage': 'hq',
                'base_glb': str(stage_geometry_glb.resolve()),
                'watertight_pass': False,
                'remesh': False,
            })
            try:
                run_blender(hq_manifest, 'hq')
            except RefinementError:
                high_quality_glb.unlink(missing_ok=True)
                rescue_hq = dict(hq_manifest)
                rescue_hq['projection_body_max_size'] = min(int(body_cap), 1280)
                rescue_hq['projection_face_max_size'] = min(int(face_cap), 1920)
                preferred = {'front', 'back', 'left', 'right', 'face_front', 'face_left_45', 'face_right_45', 'left_hand', 'right_hand', 'hair_detail', 'clothes_detail'}
                rescue_hq['images'] = {k: v for k, v in dict(hq_manifest.get('images') or {}).items() if k in preferred}
                on_update('texture_baking', 92, 'Stage 2/3 rescue: reduced-memory Pro Fidelity texture projection')
                run_blender(rescue_hq, 'hq-rescue')

            on_update('optimizing_preview', 97 if quality_mode == 'ultra_detail' else 95, 'Stage 3/3: building memory-safe preview from validated HQ output')
            preview_manifest = {
                'pipeline_stage': 'preview',
                'base_glb': str(high_quality_glb.resolve()),
                'preview_glb': str(preview_glb.resolve()),
                'high_quality_glb': str(high_quality_glb.resolve()),
                'memory_profile': profile,
                'preview_texture_size': int(self.settings.preview_texture_size),
                'preview_max_triangles': int(preview_triangles),
                'quality_mode': quality_mode,
            }
            run_blender(preview_manifest, 'preview')
            stage_geometry_glb.unlink(missing_ok=True)
        else:
            on_update('refining', 88 if quality_mode == 'ultra_detail' else 84, 'Blender 4.5 Ultra Detail: feature mesh refinement and PBR projection' if quality_mode == 'ultra_detail' else 'Blender 4.5 Pro Fidelity: geometry repair and high-detail projection')
            run_blender(manifest, 'full')

        hq_result = validate_glb_file(high_quality_glb)
        if not hq_result.ok:
            raise RefinementError(f'Blender did not produce a valid high-quality output: {hq_result.message}')
        # Avoid silently delivering a legacy view-projection model when the
        # cloud process was expected to bake a single atlas. Small stubbed GLB
        # fixtures are used by unit tests; real exported GLBs contain JSON.
        if (projection_atlas or bake_enabled) and not manifest.get('manual_regions') and high_quality_glb.stat().st_size > 256:
            atlas_check = validate_single_pbr_atlas(high_quality_glb)
            if not atlas_check.ok:
                raise RefinementError('PBR UV atlas validation failed: ' + atlas_check.message)
        on_update('optimizing_preview', 92, 'Optimizing preview mesh and lightweight texture set')
        preview_result = validate_glb_file(preview_glb)
        if not preview_result.ok:
            raise RefinementError(f'Blender did not produce a valid preview output: {preview_result.message}')
        return RefinementResult(preview_glb=preview_glb, high_quality_glb=high_quality_glb)
