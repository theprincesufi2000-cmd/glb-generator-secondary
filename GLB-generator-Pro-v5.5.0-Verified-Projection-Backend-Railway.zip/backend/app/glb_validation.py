from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class GlbValidationResult:
    ok: bool
    message: str
    size_bytes: int


def validate_glb_file(path: Path) -> GlbValidationResult:
    path = Path(path)
    if not path.exists() or not path.is_file():
        return GlbValidationResult(False, 'GLB file was not created', 0)
    size = int(path.stat().st_size)
    if size < 4:
        return GlbValidationResult(False, 'GLB file is too small', size)
    with path.open('rb') as f:
        magic = f.read(4)
    if magic != b'glTF':
        return GlbValidationResult(False, 'GLB header is invalid', size)
    return GlbValidationResult(True, 'ok', size)


def validate_single_pbr_atlas(path: Path) -> GlbValidationResult:
    """Reject a valid-looking but legacy 8-material/8-UV cloud result.

    Expected for automatic atlas mode: one material, all primitives using
    TEXCOORD_0 only, shared base/ORM/normal atlas images and no old UV1..UV7.
    The check intentionally avoids Blender imports and uses bounded JSON only.
    """
    import json
    import struct
    try:
        with Path(path).open('rb') as stream:
            header = stream.read(20)
            if len(header) != 20:
                raise ValueError('missing glTF header')
            magic, version, total, json_len, json_type = struct.unpack('<4sIII4s', header)
            if magic != b'glTF' or version != 2 or json_type != b'JSON':
                raise ValueError('not binary glTF 2.0')
            if total != Path(path).stat().st_size or json_len < 20 or json_len > 10_000_000:
                raise ValueError('invalid GLB length')
            doc = json.loads(stream.read(json_len))
        mats = doc.get('materials', [])
        if len(mats) != 1:
            raise ValueError(f'legacy multi-material output ({len(mats)} materials)')
        primitives = [prim for mesh in doc.get('meshes', []) for prim in mesh.get('primitives', [])]
        if not primitives or any(set(k for k in p.get('attributes', {}) if k.startswith('TEXCOORD_')) != {'TEXCOORD_0'} for p in primitives):
            raise ValueError('UV0 atlas is absent or extra legacy UV maps are present')
        mat = mats[0]
        channels = (mat.get('pbrMetallicRoughness', {}).get('baseColorTexture'),
                    mat.get('pbrMetallicRoughness', {}).get('metallicRoughnessTexture'),
                    mat.get('normalTexture'))
        if any(not ch or ch.get('texCoord', 0) != 0 for ch in channels):
            raise ValueError('albedo, normal and ORM must use shared UV0')
        return GlbValidationResult(True, 'single PBR UV atlas is present', int(Path(path).stat().st_size))
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        return GlbValidationResult(False, str(exc), int(Path(path).stat().st_size) if Path(path).exists() else 0)
