from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os


def _bool_env(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    data_dir: Path = Path(os.getenv("GLB_DATA_DIR", "/data"))
    public_base_url: str = os.getenv("GLB_PUBLIC_BASE_URL", "http://127.0.0.1:8000")
    disable_worker: bool = _bool_env("GLB_DISABLE_WORKER", False)
    client_token: str = os.getenv("GLB_CLIENT_TOKEN", "")
    hf_token: str = os.getenv("HF_TOKEN", os.getenv("HUGGINGFACE_TOKEN", os.getenv("HUGGING_FACE_HUB_TOKEN", "")))
    max_upload_mb: int = int(os.getenv("GLB_MAX_UPLOAD_MB", "40"))
    provider_retry_minutes: int = int(os.getenv("GLB_PROVIDER_RETRY_MINUTES", "180"))
    poll_interval_seconds: float = float(os.getenv("GLB_WORKER_POLL_SECONDS", "2"))
    blender_executable: str = os.getenv("GLB_BLENDER_EXECUTABLE", "/home/headless/blender/blender")
    blender_timeout_seconds: int = int(os.getenv("GLB_BLENDER_TIMEOUT_SECONDS", "5400"))
    hq_texture_size: int = int(os.getenv("GLB_HQ_TEXTURE_SIZE", "8192"))
    pro_fidelity_texture_size: int = int(os.getenv("GLB_PRO_FIDELITY_TEXTURE_SIZE", "8192"))
    ultra_detail_texture_size: int = int(os.getenv("GLB_ULTRA_DETAIL_TEXTURE_SIZE", "8192"))
    standard_texture_size: int = int(os.getenv("GLB_STANDARD_TEXTURE_SIZE", "4096"))
    preview_texture_size: int = int(os.getenv("GLB_PREVIEW_TEXTURE_SIZE", "2048"))
    preview_max_triangles: int = int(os.getenv("GLB_PREVIEW_MAX_TRIANGLES", "60000"))
    blender_memory_profile: str = os.getenv("GLB_BLENDER_MEMORY_PROFILE", "1gb").strip().lower()
    hq_max_triangles: int = int(os.getenv("GLB_HQ_MAX_TRIANGLES", "150000"))
    pro_fidelity_max_triangles: int = int(os.getenv("GLB_PRO_FIDELITY_MAX_TRIANGLES", "420000"))
    ultra_detail_max_triangles: int = int(os.getenv("GLB_ULTRA_DETAIL_MAX_TRIANGLES", "520000"))
    retain_terminal_jobs: int = int(os.getenv("GLB_RETAIN_TERMINAL_JOBS", "2"))

    @property
    def jobs_dir(self) -> Path:
        return self.data_dir / "jobs"

    @property
    def database_path(self) -> Path:
        return self.data_dir / "jobs.sqlite3"
