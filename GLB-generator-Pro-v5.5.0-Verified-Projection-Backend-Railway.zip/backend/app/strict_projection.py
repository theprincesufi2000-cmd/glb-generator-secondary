"""Fail-closed multi-view projection checks.

This is *not* a claim of ground-truth accuracy. It checks the evidence needed
before presenting an estimated image projection as a verified/high-quality map.
Images cannot reveal surfaces hidden from every view, or true BRDF parameters.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np
from .multiview_core import calibrate_orthographic, project_points


@dataclass(frozen=True)
class CalibrationCheck:
    accepted: bool
    name: str
    points: int
    rms_px: float
    max_px: float
    reason: str

    def as_dict(self):
        return {"accepted": self.accepted, "name": self.name, "landmark_count": self.points,
                "rms_px": round(self.rms_px, 3), "max_px": round(self.max_px, 3),
                "reason": self.reason}


def validate_calibration(points_xyz, rgba, name, supplied, *, face=False,
                         min_landmarks=6, rms_tolerance_px=7.,
                         max_tolerance_px=18., min_span=.12):
    """Reject weak camera fitting rather than silently using silhouette bounds.

    Check source image pixel reprojection (not a visual-perceptual similarity
    test). A low reprojection error does not prove photos share identical
    geometry, appearance, pose, or lighting.
    """
    n = len(supplied or [])
    fail = lambda message: CalibrationCheck(False, name, n, math.inf, math.inf, message)
    if n < min_landmarks:
        return fail(f"CALIBRATION_REQUIRED: {name} needs >= {min_landmarks} matched image/mesh landmarks; found {n}")
    xyz = np.asarray([p['world_xyz'] for p in supplied], dtype=np.float64)
    uv = np.asarray([p['image_uv'] for p in supplied], dtype=np.float64)
    if xyz.shape != (n, 3) or uv.shape != (n, 2) or not (np.isfinite(xyz).all() and np.isfinite(uv).all()):
        return fail('Malformed or non-finite image/mesh landmarks')
    if np.any((uv < 0) | (uv > 1)):
        return fail('Image landmark outside normalized UV range')
    # Reject points concentrated on e.g. both eyes only: it cannot calibrate a
    # full-body photo (or even the nose + jaw) with reliable scale.
    if (np.ptp(uv[:, 0]) < min_span or np.ptp(uv[:, 1]) < min_span):
        return fail('Landmarks do not span enough of BOTH image axes')
    height, width = np.asarray(rgba).shape[:2]
    if height < 32 or width < 32:
        return fail('Invalid source image dimensions')
    try:
        cam = calibrate_orthographic(points_xyz, rgba[:, :, 3], name,
                                    landmarks=supplied, face=face)
        residual = (project_points(xyz, cam) - uv) * [width, height]
        errors = np.linalg.norm(residual, axis=1)
    except (ValueError, IndexError, TypeError, np.linalg.LinAlgError) as exc:
        return fail('Calibration could not be solved: ' + str(exc))
    rms = float(np.sqrt(np.mean(errors**2)))
    max_error = float(np.max(errors))
    if not np.isfinite([rms, max_error]).all():
        return fail('Non-finite image reprojection error')
    if rms > rms_tolerance_px or max_error > max_tolerance_px:
        return CalibrationCheck(False, name, n, rms, max_error,
                                'ALIGNMENT_ERROR: image reprojection exceeds pixel tolerance')
    return CalibrationCheck(True, name, n, rms, max_error, 'Geometric landmark reprojection passed')


def choose_consistent_color(samples, weights, *, threshold=.17):
    """Choose supported view color and refuse conflicting views.

    Each sample is Nx4 (RGB, alpha); each weight has length N.  Differently
    exposed/misaligned overlapping photos should not be averaged into ghosting.
    Return RGB, valid, conflict, confidence.  Pixels with two strong, strongly
    disagreeing views are deliberately marked ambiguous, not hallucinated.
    """
    if not samples or len(samples) != len(weights):
        raise ValueError('Expected matching sample and weight arrays')
    rgb = np.stack([np.asarray(s, dtype=np.float32)[:, :3] for s in samples], axis=0)
    w = np.stack([np.asarray(v, dtype=np.float32) for v in weights], axis=0)
    if rgb.shape[:2] != w.shape:
        raise ValueError('Mismatched candidate pixel arrays')
    w = np.maximum(np.where(np.isfinite(w), w, 0.), 0.)
    count = w.shape[1]
    sort_idx = np.argsort(w, axis=0)
    idx = np.arange(count)
    best = sort_idx[-1]
    strongest = w[best, idx]
    picked = rgb[best, idx]
    if len(samples) > 1:
        runner = sort_idx[-2]
        second = w[runner, idx]
        colors2 = rgb[runner, idx]
        delta = np.sqrt(np.mean((picked - colors2)**2, axis=1))
        # A competing view matters only if its reliability is material.
        ambiguous = (second >= strongest * .40) & (second > .08) & (delta > threshold)
    else:
        ambiguous = np.zeros(count, dtype=bool)
    accepted = (strongest > 1e-5) & ~ambiguous
    picked = np.where(accepted[:, None], picked, .62)
    confidence = strongest / np.maximum(np.sum(w, axis=0), 1e-9)
    confidence[~accepted] = 0.
    return picked, accepted, ambiguous, confidence


def validate_multiview_request(photos, landmarks, *, required=('front', 'back', 'left', 'right')):
    """Lightweight API/worker precheck; full reprojection is done in Blender.

    Coordinates are mesh-specific; they can be validated only after geometry
    generation, so this function validates presence and payload shape only.
    """
    problems = []
    for view in required:
        if view not in photos:
            problems.append(f'Missing reference photo: {view}')
        if len((landmarks or {}).get(view, [])) < 6:
            problems.append(f'Missing >=6 mesh-to-photo landmark pairs: {view}')
    for name in photos:
        if name not in required and len((landmarks or {}).get(name, [])) < 6:
            problems.append(f'Missing >=6 mesh-to-photo landmark pairs: {name}')
    return problems
