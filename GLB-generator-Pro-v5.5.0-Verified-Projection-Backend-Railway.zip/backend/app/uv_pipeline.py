from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class UvPolicy:
    segmented: bool
    face_weight: float
    body_weight: float
    padding_px: int
    seam_strategy: str


def build_uv_policy(quality_mode: str, texture_size: int) -> UvPolicy:
    quality_mode = (quality_mode or 'pro_hq').strip().lower()
    if quality_mode == 'ultra_detail':
        return UvPolicy(segmented=True, face_weight=3.6, body_weight=1.0, padding_px=max(48, texture_size // 192), seam_strategy='ultra_feature_region_priority')
    if quality_mode == 'pro_fidelity':
        return UvPolicy(segmented=True, face_weight=2.6, body_weight=1.0, padding_px=max(32, texture_size // 256), seam_strategy='segmented_face_body_priority')
    return UvPolicy(segmented=True, face_weight=1.8, body_weight=1.0, padding_px=max(16, texture_size // 384), seam_strategy='multi_view_region_priority')


def manifest_values(policy: UvPolicy) -> dict[str, Any]:
    return {
        'uv_segmented': bool(policy.segmented),
        'uv_face_weight': float(policy.face_weight),
        'uv_body_weight': float(policy.body_weight),
        'uv_padding_px': int(policy.padding_px),
        'uv_seam_strategy': str(policy.seam_strategy),
    }
