from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Any


@dataclass(frozen=True)
class BodyProjectionPlan:
    views: tuple[str, ...]
    blend_mode: str
    fill_gaps: bool


def build_body_projection_plan(image_paths: Mapping[str, Path], quality_mode: str) -> BodyProjectionPlan:
    views = tuple(key for key in ('front', 'front_45', 'right', 'back', 'back_45', 'left') if key in image_paths and Path(image_paths[key]).exists())
    quality_mode = (quality_mode or 'pro_hq').lower()
    return BodyProjectionPlan(
        views=views,
        blend_mode='feature_weighted_multiview' if quality_mode == 'ultra_detail' else ('angle_weighted_multiview' if quality_mode == 'pro_fidelity' else 'best_view'),
        fill_gaps=True,
    )


def manifest_values(plan: BodyProjectionPlan) -> dict[str, Any]:
    return {
        'body_projection_views': list(plan.views),
        'body_blend_mode': str(plan.blend_mode),
        'body_fill_gaps': bool(plan.fill_gaps),
    }
