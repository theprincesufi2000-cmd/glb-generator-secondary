from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Any


FACE_KEYS = (
    "face_front",
    "face_left_45",
    "face_right_45",
    "face_left_profile",
    "face_right_profile",
)
HAND_KEYS = ("left_hand", "right_hand")
DETAIL_KEYS = ("hair_detail", "clothes_detail")


@dataclass(frozen=True)
class FeatureReferencePlan:
    face_sources: tuple[str, ...]
    hand_sources: tuple[str, ...]
    hair_source: str | None
    clothes_source: str | None
    feature_subdivide: bool
    face_weight: float
    hand_weight: float
    clothing_weight: float


def build_feature_reference_plan(image_paths: Mapping[str, Path], quality_mode: str) -> FeatureReferencePlan:
    existing = {k for k, p in image_paths.items() if p and Path(p).exists()}
    face = tuple(k for k in FACE_KEYS if k in existing)
    hands = tuple(k for k in HAND_KEYS if k in existing)
    ultra = (quality_mode or "").strip().lower() == "ultra_detail"
    return FeatureReferencePlan(
        face_sources=face,
        hand_sources=hands,
        hair_source="hair_detail" if "hair_detail" in existing else None,
        clothes_source="clothes_detail" if "clothes_detail" in existing else None,
        feature_subdivide=ultra,
        face_weight=3.6 if ultra else 2.6,
        hand_weight=2.8 if ultra else 1.4,
        clothing_weight=1.9 if ultra else 1.0,
    )


def manifest_values(plan: FeatureReferencePlan) -> dict[str, Any]:
    return {
        "feature_face_sources": list(plan.face_sources),
        "feature_hand_sources": list(plan.hand_sources),
        "feature_hair_source": plan.hair_source,
        "feature_clothes_source": plan.clothes_source,
        "feature_subdivide": bool(plan.feature_subdivide),
        "feature_face_weight": float(plan.face_weight),
        "feature_hand_weight": float(plan.hand_weight),
        "feature_clothing_weight": float(plan.clothing_weight),
    }
