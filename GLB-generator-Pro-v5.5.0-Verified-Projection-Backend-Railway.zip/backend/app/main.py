from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path
from uuid import uuid4
import asyncio
import json
import shutil

from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, UploadFile, Request, status
from fastapi.responses import FileResponse, HTMLResponse
from starlette.datastructures import UploadFile as StarletteUploadFile

from .config import Settings
from .models import HealthResponse, JobResponse, V3JobResponse, V4JobResponse
from .store import JobStore
from .texture_project import TextureProjectSpec
from .multiview_schema import CalibrationProject

VERSION = "5.5.0"


def _job_response(job: dict, settings: Settings) -> JobResponse:
    model_url = None
    if job["status"] == "completed" and job.get("output_path"):
        model_url = f"{settings.public_base_url.rstrip('/')}/v1/jobs/{job['id']}/model"
    return JobResponse(
        job_id=job["id"], status=job["status"], progress=int(job["progress"]),
        message=job["message"], provider=job.get("provider"),
        attempt_count=int(job.get("attempt_count") or 0), last_error=job.get("last_error"),
        created_at=job["created_at"], updated_at=job["updated_at"], model_url=model_url,
    )


def _v3_job_response(job: dict, settings: Settings) -> V3JobResponse:
    root = settings.public_base_url.rstrip("/")
    preview_url = None
    high_quality_url = None
    if job.get("preview_path"):
        preview_url = f"{root}/v3/jobs/{job['id']}/preview"
    if job.get("high_quality_path"):
        high_quality_url = f"{root}/v3/jobs/{job['id']}/high-quality"
    return V3JobResponse(
        job_id=job["id"], status=job["status"], progress=int(job["progress"]),
        message=job["message"], provider=job.get("provider"),
        attempt_count=int(job.get("attempt_count") or 0), last_error=job.get("last_error"),
        created_at=job["created_at"], updated_at=job["updated_at"],
        quality_mode=job.get("quality_mode") or "pro_hq", remesh=bool(job.get("remesh")),
        preview_url=preview_url, high_quality_url=high_quality_url,
    )


def _v4_job_response(job: dict, settings: Settings) -> V4JobResponse:
    root = settings.public_base_url.rstrip("/")
    preview_url = f"{root}/v4/jobs/{job['id']}/preview" if job.get("preview_path") else None
    high_quality_url = f"{root}/v4/jobs/{job['id']}/high-quality" if job.get("high_quality_path") else None
    mesh_value = job.get("base_path") or (job.get("output_path") if (job.get("output_mode") or "") == "mesh_only" else None)
    mesh_url = f"{root}/v4/jobs/{job['id']}/mesh" if mesh_value else None
    return V4JobResponse(
        job_id=job["id"], status=job["status"], progress=int(job["progress"]),
        message=job["message"], provider=job.get("provider"),
        attempt_count=int(job.get("attempt_count") or 0), last_error=job.get("last_error"),
        created_at=job["created_at"], updated_at=job["updated_at"],
        quality_mode=job.get("quality_mode") or "pro_hq", remesh=bool(job.get("remesh")),
        preview_url=preview_url, high_quality_url=high_quality_url,
        generation_mode=job.get("generation_mode") or "auto",
        output_mode=job.get("output_mode") or "full_glb",
        texture_mode=job.get("texture_mode") or "auto",
        local_fallback_required=bool(job.get("local_fallback_required")),
        mesh_url=mesh_url,
    )


async def _persist_upload(upload: UploadFile, destination: Path, max_bytes: int):
    content_type = (upload.content_type or "").lower()
    if not content_type.startswith("image/"):
        raise HTTPException(status_code=415, detail=f"Unsupported content type: {content_type or 'unknown'}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    written = 0
    try:
        with destination.open("wb") as out:
            while True:
                chunk = await upload.read(1024 * 1024)
                if not chunk:
                    break
                written += len(chunk)
                if written > max_bytes:
                    raise HTTPException(status_code=413, detail="Image is too large")
                out.write(chunk)
            out.flush()
        if written == 0:
            raise HTTPException(status_code=400, detail="Empty image upload")
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    finally:
        await upload.close()


async def _persist_glb_upload(upload: UploadFile, destination: Path, max_bytes: int):
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_suffix(destination.suffix + ".part")
    written = 0
    header = bytearray()
    try:
        with temp.open("wb") as out:
            while True:
                chunk = await upload.read(1024 * 1024)
                if not chunk:
                    break
                if len(header) < 4:
                    header.extend(chunk[: 4 - len(header)])
                written += len(chunk)
                if written > max_bytes:
                    raise HTTPException(status_code=413, detail="Base GLB is too large")
                out.write(chunk)
            out.flush()
        if written < 4 or bytes(header[:4]) != b"glTF":
            raise HTTPException(status_code=400, detail="Uploaded base mesh is not a valid binary GLB")
        temp.replace(destination)
    except Exception:
        temp.unlink(missing_ok=True)
        raise
    finally:
        await upload.close()


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or Settings()
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    settings.jobs_dir.mkdir(parents=True, exist_ok=True)
    store = JobStore(settings.database_path)
    worker_task: asyncio.Task | None = None

    async def require_token(x_glb_token: str | None = Header(default=None)):
        if settings.client_token and x_glb_token != settings.client_token:
            raise HTTPException(status_code=401, detail="Invalid client token")

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        nonlocal worker_task
        store.normalize_interrupted()
        store.prune_terminal_jobs(settings.jobs_dir, settings.retain_terminal_jobs)
        if not settings.disable_worker:
            from .worker import worker_loop
            worker_task = asyncio.create_task(worker_loop(store, settings))
        try:
            yield
        finally:
            if worker_task is not None:
                worker_task.cancel()
                try:
                    await worker_task
                except asyncio.CancelledError:
                    pass

    app = FastAPI(title="GLB generator Pro backend", version=VERSION, lifespan=lifespan)
    app.state.store = store
    app.state.settings = settings

    @app.get('/calibration-studio', response_class=HTMLResponse)
    async def calibration_studio():
        # Static client; no server secrets embedded in HTML. Job APIs require
        # an X-GLB-Token header as usual. External Three.js CDN needs Internet.
        return HTMLResponse((Path(__file__).parents[1] / 'static' /
                             'calibration_studio.html').read_text(encoding='utf-8'))

    @app.get("/health", response_model=HealthResponse)
    async def health():
        return HealthResponse(ok=True, service="glb-generator-pro-backend", version=VERSION)

    @app.post("/v1/jobs", response_model=JobResponse, status_code=status.HTTP_202_ACCEPTED, dependencies=[Depends(require_token)])
    async def create_job(
        front: UploadFile = File(...), back: UploadFile = File(...),
        left: UploadFile = File(...), right: UploadFile = File(...),
    ):
        job_id = uuid4().hex
        job_dir = settings.jobs_dir / job_id
        input_dir = job_dir / "input"
        max_bytes = settings.max_upload_mb * 1024 * 1024
        try:
            paths: dict[str, str] = {}
            for name, upload in {"front": front, "back": back, "left": left, "right": right}.items():
                destination = input_dir / f"{name}.jpg"
                await _persist_upload(upload, destination, max_bytes)
                paths[name] = str(destination)
            return _job_response(store.create_job(job_id=job_id, paths=paths), settings)
        except Exception:
            shutil.rmtree(job_dir, ignore_errors=True)
            raise

    @app.get("/v1/jobs/{job_id}", response_model=JobResponse, dependencies=[Depends(require_token)])
    async def get_job(job_id: str):
        job = store.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")
        return _job_response(job, settings)

    @app.post("/v1/jobs/{job_id}/retry", response_model=JobResponse, dependencies=[Depends(require_token)])
    async def retry_job(job_id: str):
        job = store.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")
        if job["status"] == "completed":
            return _job_response(job, settings)
        for key in ("front_path", "back_path", "left_path", "right_path"):
            if not Path(job[key]).exists():
                raise HTTPException(status_code=409, detail="Original images are no longer available")
        job = store.update_job(job_id, status="queued", progress=5, message="Retry queued", last_error=None, retry_after_at=None)
        return _job_response(job, settings)

    @app.post("/v1/jobs/{job_id}/cancel", response_model=JobResponse, dependencies=[Depends(require_token)])
    async def cancel_job(job_id: str):
        job = store.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")
        if job.get("status") == "completed":
            return _job_response(job, settings)
        return _job_response(store.cancel_job(job_id), settings)

    @app.get("/v1/jobs/{job_id}/model", dependencies=[Depends(require_token)])
    async def get_model(job_id: str):
        job = store.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")
        if job["status"] != "completed" or not job.get("output_path"):
            raise HTTPException(status_code=409, detail="Model is not ready")
        path = Path(job["output_path"])
        if not path.exists():
            raise HTTPException(status_code=410, detail="Model file is missing")
        return FileResponse(path, media_type="model/gltf-binary", filename="character.glb")

    @app.post("/v3/jobs", response_model=V3JobResponse, status_code=status.HTTP_202_ACCEPTED, dependencies=[Depends(require_token)])
    async def create_v3_job(
        front: UploadFile = File(...), back: UploadFile = File(...),
        left: UploadFile = File(...), right: UploadFile = File(...),
        front_45: UploadFile | None = File(default=None),
        back_45: UploadFile | None = File(default=None),
        face_front: UploadFile | None = File(default=None),
        face_45: UploadFile | None = File(default=None),
        quality_mode: str = Form(default="pro_fidelity"),
        remesh: bool = Form(default=False),
    ):
        if quality_mode not in {"standard", "pro_hq", "pro_fidelity", "ultra_detail"}:
            raise HTTPException(status_code=422, detail="quality_mode must be standard, pro_hq, pro_fidelity or ultra_detail")
        job_id = uuid4().hex
        job_dir = settings.jobs_dir / job_id
        input_dir = job_dir / "input"
        max_bytes = settings.max_upload_mb * 1024 * 1024
        try:
            paths: dict[str, str] = {}
            required = {"front": front, "back": back, "left": left, "right": right}
            for name, upload in required.items():
                destination = input_dir / f"{name}.jpg"
                await _persist_upload(upload, destination, max_bytes)
                paths[name] = str(destination)
            optional_paths: dict[str, str | None] = {}
            optional = {
                "front_45": front_45, "back_45": back_45,
                "face_front": face_front, "face_45": face_45,
            }
            for name, upload in optional.items():
                if upload is None:
                    optional_paths[name] = None
                    continue
                destination = input_dir / f"{name}.jpg"
                await _persist_upload(upload, destination, max_bytes)
                optional_paths[name] = str(destination)
            job = store.create_job(
                job_id=job_id, paths=paths, quality_mode=quality_mode,
                remesh=remesh, optional_paths=optional_paths,
            )
            return _v3_job_response(job, settings)
        except Exception:
            shutil.rmtree(job_dir, ignore_errors=True)
            raise

    @app.get("/v3/jobs/{job_id}", response_model=V3JobResponse, dependencies=[Depends(require_token)])
    async def get_v3_job(job_id: str):
        job = store.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")
        return _v3_job_response(job, settings)

    @app.post("/v3/jobs/{job_id}/retry", response_model=V3JobResponse, dependencies=[Depends(require_token)])
    async def retry_v3_job(job_id: str):
        job = store.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")
        if job["status"] == "completed":
            return _v3_job_response(job, settings)
        for key in ("front_path", "back_path", "left_path", "right_path"):
            if not Path(job[key]).exists():
                raise HTTPException(status_code=409, detail="Original images are no longer available")
        for key in ("front_45_path", "back_45_path", "face_front_path", "face_45_path"):
            if job.get(key) and not Path(job[key]).exists():
                raise HTTPException(status_code=409, detail=f"Stored reference image is missing: {key}")
        job = store.update_job(
            job_id, status="queued", progress=5, message="Pro refinement retry queued",
            last_error=None, preview_path=None, high_quality_path=None, retry_after_at=None,
        )
        return _v3_job_response(job, settings)

    def _v3_file(job_id: str, field: str, filename: str):
        job = store.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")
        path_value = job.get(field)
        if not path_value:
            raise HTTPException(status_code=409, detail="Model is not ready")
        path = Path(path_value)
        if not path.exists():
            raise HTTPException(status_code=410, detail="Model file is missing")
        return FileResponse(path, media_type="model/gltf-binary", filename=filename)

    @app.post("/v3/jobs/{job_id}/cancel", response_model=V3JobResponse, dependencies=[Depends(require_token)])
    async def cancel_v3_job(job_id: str):
        job = store.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")
        if job.get("status") == "completed":
            return _v3_job_response(job, settings)
        return _v3_job_response(store.cancel_job(job_id), settings)

    @app.get("/v3/jobs/{job_id}/preview", dependencies=[Depends(require_token)])
    async def get_v3_preview(job_id: str):
        return _v3_file(job_id, "preview_path", "preview.glb")

    @app.get("/v3/jobs/{job_id}/high-quality", dependencies=[Depends(require_token)])
    async def get_v3_high_quality(job_id: str):
        return _v3_file(job_id, "high_quality_path", "high_quality.glb")


    @app.post("/v4/jobs", response_model=V4JobResponse, status_code=status.HTTP_202_ACCEPTED, dependencies=[Depends(require_token)])
    async def create_v4_job(
        front: UploadFile = File(...), back: UploadFile = File(...),
        left: UploadFile = File(...), right: UploadFile = File(...),
        front_45: UploadFile | None = File(default=None),
        back_45: UploadFile | None = File(default=None),
        face_front: UploadFile | None = File(default=None),
        face_45: UploadFile | None = File(default=None),
        face_left_45: UploadFile | None = File(default=None),
        face_right_45: UploadFile | None = File(default=None),
        face_left_profile: UploadFile | None = File(default=None),
        face_right_profile: UploadFile | None = File(default=None),
        left_hand: UploadFile | None = File(default=None),
        right_hand: UploadFile | None = File(default=None),
        hair_detail: UploadFile | None = File(default=None),
        clothes_detail: UploadFile | None = File(default=None),
        quality_mode: str = Form(default="ultra_detail"),
        remesh: bool = Form(default=False),
        generation_mode: str = Form(default="auto"),
        output_mode: str = Form(default="full_glb"),
        texture_mode: str = Form(default="auto"),
    ):
        if quality_mode not in {"standard", "pro_hq", "pro_fidelity", "ultra_detail"}:
            raise HTTPException(status_code=422, detail="quality_mode must be standard, pro_hq, pro_fidelity or ultra_detail")
        if generation_mode not in {"auto", "cloud_only", "local_only"}:
            raise HTTPException(status_code=422, detail="generation_mode must be auto, cloud_only or local_only")
        if output_mode not in {"full_glb", "mesh_only"}:
            raise HTTPException(status_code=422, detail="output_mode must be full_glb or mesh_only")
        if texture_mode not in {"auto", "manual", "hybrid", "none"}:
            raise HTTPException(status_code=422, detail="texture_mode must be auto, manual, hybrid or none")
        if output_mode == "mesh_only":
            texture_mode = "none"

        job_id = uuid4().hex
        job_dir = settings.jobs_dir / job_id
        input_dir = job_dir / "input"
        max_bytes = settings.max_upload_mb * 1024 * 1024
        try:
            paths: dict[str, str] = {}
            for name, upload in {"front": front, "back": back, "left": left, "right": right}.items():
                destination = input_dir / f"{name}.jpg"
                await _persist_upload(upload, destination, max_bytes)
                paths[name] = str(destination)
            optional_paths: dict[str, str | None] = {}
            for name, upload in {
                "front_45": front_45, "back_45": back_45,
                "face_front": face_front, "face_45": face_45,
                "face_left_45": face_left_45, "face_right_45": face_right_45,
                "face_left_profile": face_left_profile, "face_right_profile": face_right_profile,
                "left_hand": left_hand, "right_hand": right_hand,
                "hair_detail": hair_detail, "clothes_detail": clothes_detail,
            }.items():
                if upload is None:
                    optional_paths[name] = None
                    continue
                destination = input_dir / f"{name}.jpg"
                await _persist_upload(upload, destination, max_bytes)
                optional_paths[name] = str(destination)
            job = store.create_job(
                job_id=job_id,
                paths=paths,
                quality_mode=quality_mode,
                remesh=remesh,
                optional_paths=optional_paths,
                generation_mode=generation_mode,
                output_mode=output_mode,
                texture_mode=texture_mode,
            )
            if generation_mode == "local_only":
                job = store.update_job(
                    job_id,
                    status="awaiting_local",
                    progress=10,
                    message="Local generation selected; waiting for Android base mesh",
                    provider="Android Local Fallback",
                    local_fallback_required=1,
                )
            return _v4_job_response(job, settings)
        except Exception:
            shutil.rmtree(job_dir, ignore_errors=True)
            raise

    @app.get("/v4/jobs/{job_id}", response_model=V4JobResponse, dependencies=[Depends(require_token)])
    async def get_v4_job(job_id: str):
        job = store.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")
        return _v4_job_response(job, settings)

    @app.post("/v4/jobs/{job_id}/retry", response_model=V4JobResponse, dependencies=[Depends(require_token)])
    async def retry_v4_job(job_id: str):
        job = store.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")
        if job["status"] == "completed":
            return _v4_job_response(job, settings)
        for key in ("front_path", "back_path", "left_path", "right_path"):
            if not Path(job[key]).exists():
                raise HTTPException(status_code=409, detail="Original images are no longer available")
        generation_mode = (job.get("generation_mode") or "auto").lower()
        if generation_mode == "local_only":
            job = store.update_job(
                job_id, status="awaiting_local", progress=10,
                message="Local retry requested; waiting for Android base mesh",
                last_error=None, retry_after_at=None, local_fallback_required=1,
            )
        else:
            job = store.update_job(
                job_id, status="queued", progress=5, message="Professional v4 retry queued",
                last_error=None, retry_after_at=None, local_fallback_required=0,
                preview_path=None, high_quality_path=None,
            )
        return _v4_job_response(job, settings)

    @app.post("/v4/jobs/{job_id}/cancel", response_model=V4JobResponse, dependencies=[Depends(require_token)])
    async def cancel_v4_job(job_id: str):
        job = store.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")
        if job.get("status") == "completed":
            return _v4_job_response(job, settings)
        job = store.cancel_job(job_id)
        return _v4_job_response(job, settings)

    @app.post("/v4/jobs/{job_id}/base-mesh", response_model=V4JobResponse, dependencies=[Depends(require_token)])
    async def upload_v4_base_mesh(job_id: str, base_mesh: UploadFile = File(...)):
        job = store.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")
        work_dir = settings.jobs_dir / job_id / "work"
        destination = work_dir / "base.glb"
        await _persist_glb_upload(base_mesh, destination, settings.max_upload_mb * 4 * 1024 * 1024)
        job = store.update_job(
            job_id,
            base_path=str(destination),
            status="queued",
            progress=52,
            message="Local base mesh received; Blender refinement queued",
            provider="Android Local + Blender 4.5 Pro",
            last_error=None,
            retry_after_at=None,
            local_fallback_required=0,
            preview_path=None,
            high_quality_path=None,
            output_path=None,
        )
        return _v4_job_response(job, settings)


    @app.get("/v4/jobs/{job_id}/bake-report", dependencies=[Depends(require_token)])
    async def get_v4_bake_report(job_id: str):
        job = store.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")
        report = settings.jobs_dir / job_id / 'work' / 'surface_bake_v540' / 'bake_metrics.json'
        # The output GLB normally resides in `work`; the folder follows it.
        if job.get('high_quality_path'):
            report = Path(job['high_quality_path']).parent / 'surface_bake_v540' / 'bake_metrics.json'
        if not report.is_file():
            raise HTTPException(status_code=404, detail='Bake report is not available')
        return json.loads(report.read_text(encoding='utf-8'))

    @app.get('/v4/jobs/{job_id}/calibration-report', dependencies=[Depends(require_token)])
    async def get_v4_calibration_report(job_id: str):
        job = store.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail='Job not found')
        report = settings.jobs_dir / job_id / 'work' / 'surface_bake_v540' / 'calibration_report.json'
        if job.get('high_quality_path'):
            report = Path(job['high_quality_path']).parent / 'surface_bake_v540' / 'calibration_report.json'
        if not report.is_file():
            raise HTTPException(status_code=404, detail='Calibration report is not available')
        return json.loads(report.read_text(encoding='utf-8'))

    @app.post("/v4/jobs/{job_id}/calibration", response_model=V4JobResponse,
              dependencies=[Depends(require_token)])
    async def save_v4_calibration(job_id: str, payload: CalibrationProject):
        """Attach image-to-mesh landmark matches before starting refinement.

        Send `landmarks` object: each view name maps to world_xyz/image_uv
        pairs; both calibrated and silhouette-only requests share one pipeline.
        """
        job = store.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")
        if job['status'] in {'processing', 'refining', 'waiting_provider'}:
            raise HTTPException(status_code=409, detail='Wait for the current generation before changing calibration')
        path = settings.jobs_dir / job_id / 'calibration.json'
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_suffix('.json.tmp')
        temp.write_text(payload.model_dump_json(indent=2), encoding='utf-8')
        temp.replace(path)
        if job['status'] in {'completed', 'failed'}:
            # When a valid base mesh is present, re-run refinement against it.
            if job.get('base_path') and Path(job['base_path']).is_file():
                job = store.update_job(job_id, status='queued', progress=52,
                                       message='Landmark calibration updated; refining again',
                                       preview_path=None, high_quality_path=None,
                                       output_path=None, last_error=None)
        return _v4_job_response(job, settings)

    @app.post("/v4/jobs/{job_id}/texture-project", response_model=V4JobResponse, dependencies=[Depends(require_token)])
    async def save_v4_texture_project(job_id: str, request: Request):
        job = store.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")

        form = await request.form()
        raw = form.get("project_json")
        if not isinstance(raw, str) or not raw.strip():
            raise HTTPException(status_code=422, detail="project_json is required")
        try:
            project = TextureProjectSpec.model_validate_json(raw)
        except Exception as exc:
            raise HTTPException(status_code=422, detail=f"Invalid texture project: {exc}") from exc
        if not job.get("base_path"):
            raise HTTPException(status_code=409, detail="Base mesh is not ready yet")

        job_dir = settings.jobs_dir / job_id
        project_dir = job_dir / "texture_project"
        asset_dir = project_dir / "manual_textures"
        project_dir.mkdir(parents=True, exist_ok=True)
        max_bytes = settings.max_upload_mb * 1024 * 1024

        referenced_assets = {
            region.source.split(":", 1)[1]
            for region in project.regions
            if region.source.startswith("asset:")
        }
        for key, value in form.multi_items():
            if not key.startswith("asset_") or not isinstance(value, StarletteUploadFile):
                continue
            asset_id = key[len("asset_"):].strip()
            if not asset_id or asset_id not in referenced_assets:
                await value.close()
                continue
            suffix = Path(value.filename or "texture.png").suffix.lower()
            if suffix not in {".png", ".jpg", ".jpeg", ".webp"}:
                suffix = ".png"
            destination = asset_dir / f"{asset_id}{suffix}"
            await _persist_upload(value, destination, max_bytes)

        missing_assets = []
        for asset_id in referenced_assets:
            matches = list(asset_dir.glob(f"{asset_id}.*"))
            if not matches:
                missing_assets.append(asset_id)
        if missing_assets:
            raise HTTPException(status_code=422, detail=f"Missing texture assets: {', '.join(sorted(missing_assets))}")

        project_path = project_dir / "texture_project.json"
        temp = project_path.with_suffix(".json.tmp")
        temp.write_text(project.model_dump_json(indent=2), encoding="utf-8")
        temp.replace(project_path)
        job = store.update_job(
            job_id,
            texture_project_path=str(project_path),
            texture_mode=project.mode,
            status="queued",
            progress=max(52, int(job.get("progress") or 0)),
            message="Manual texture project saved; Blender render queued",
            provider="Blender 4.5 Texture Studio",
            last_error=None,
            preview_path=None,
            high_quality_path=None,
        )
        return _v4_job_response(job, settings)

    def _v4_file(job_id: str, field: str, fallback_field: str | None, filename: str):
        job = store.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")
        candidate_fields = [field]
        if fallback_field:
            candidate_fields.append(fallback_field)
        # v4.8.7 reliability: tolerate a completed refinement where one exported
        # GLB alias is missing but the equivalent finalized GLB exists.
        if field == "preview_path":
            candidate_fields.extend(["high_quality_path", "output_path"])
        elif field == "high_quality_path":
            candidate_fields.extend(["output_path", "preview_path"])
        # v4.9.2 contract: no-texture / mesh-only jobs intentionally have no
        # separately baked preview/HQ artifact. The finalized geometry itself is
        # the correct downloadable result. This also recovers older rows created
        # before all aliases were populated.
        if str(job.get("output_mode") or "").lower() == "mesh_only" or str(job.get("texture_mode") or "").lower() == "none":
            candidate_fields.append("base_path")
        seen = set()
        had_value = False
        for candidate in candidate_fields:
            if not candidate or candidate in seen:
                continue
            seen.add(candidate)
            path_value = job.get(candidate)
            if not path_value:
                continue
            had_value = True
            path = Path(path_value)
            if path.exists() and path.is_file() and path.stat().st_size >= 4:
                return FileResponse(path, media_type="model/gltf-binary", filename=filename)
        if had_value:
            raise HTTPException(status_code=410, detail="Finalized model file is missing")
        raise HTTPException(status_code=409, detail="Model is not ready")

    @app.get("/v4/jobs/{job_id}/mesh", dependencies=[Depends(require_token)])
    async def get_v4_mesh(job_id: str):
        return _v4_file(job_id, "base_path", "output_path", "mesh.glb")

    @app.get("/v4/jobs/{job_id}/preview", dependencies=[Depends(require_token)])
    async def get_v4_preview(job_id: str):
        return _v4_file(job_id, "preview_path", None, "preview.glb")

    @app.get("/v4/jobs/{job_id}/high-quality", dependencies=[Depends(require_token)])
    async def get_v4_high_quality(job_id: str):
        return _v4_file(job_id, "high_quality_path", None, "high_quality.glb")

    return app


app = create_app()

# GLB_V487_LOCAL_FALLBACK_RELIABILITY

# GLB_V488_PHONE_STAGED_MESH_FIX
