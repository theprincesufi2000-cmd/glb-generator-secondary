"""Numerical camera calibration and UV-texel raster helpers.

Coordinates: mesh is (x,y,z); image (u,v) starts at the TOP-left.  The
camera is orthographic; this is a deliberate limitation, not a metric camera
recovery claim.  A user-provided 2D/3D point correspondence overrides the
silhouette-fit heuristic.  Functions are also importable outside Blender.
"""
from __future__ import annotations
import math
import numpy as np

DIRECTIONS = {
    'front': (0., -1., 0.), 'back': (0., 1., 0.),
    'left': (-1., 0., 0.), 'right': (1., 0., 0.),
    'front_45': (1., -1., 0.), 'back_45': (-1., 1., 0.),
    'face_front': (0., -1., 0.), 'face_45': (1., -1., 0.),
    'face_left_45': (-1., -1., 0.), 'face_right_45': (1., -1., 0.),
    'face_left_profile': (-1., 0., 0.), 'face_right_profile': (1., 0., 0.),
    'left_hand': (0., -1., 0.), 'right_hand': (0., -1., 0.),
    'hair_detail': (0., -1., 0.), 'clothes_detail': (0., -1., 0.),
}


def camera_basis(view: str):
    direction = np.array(DIRECTIONS[view], dtype=np.float64)
    direction /= np.linalg.norm(direction)
    right = np.cross(np.array((0., 0., 1.)), direction)
    right /= np.linalg.norm(right)
    return direction, right


def silhouette_rect(alpha: np.ndarray, *, threshold: float = .25):
    """Return (u0,v0,u1,v1) in normalized top-left image coordinates."""
    mask = np.asarray(alpha) > threshold
    if mask.ndim != 2:
        raise ValueError('Alpha must be 2-dimensional')
    ys, xs = np.where(mask)
    if len(xs) < 12:
        return (0., 0., 1., 1.)
    h, w = mask.shape
    return (float(xs.min()) / w, float(ys.min()) / h,
            float(xs.max() + 1) / w, float(ys.max() + 1) / h)


def face_head_rect(alpha: np.ndarray):
    """Estimate head silhouette above wider shoulders in a face-closeup.

    This is explicitly a heuristic; manually matched landmarks should be used
    for exact eye/nose alignment.  A transition is accepted only when it
    occurs below half the visible person's bounding box.
    """
    mask = np.asarray(alpha) > .25
    if mask.ndim != 2 or np.count_nonzero(mask) < 12:
        return silhouette_rect(alpha)
    ys, xs = np.where(mask)
    top, bottom = int(ys.min()), int(ys.max())+1
    height, width = mask.shape
    row_width = mask.sum(axis=1).astype(np.float64)
    active = row_width[top:bottom]
    if len(active) < 10:
        return silhouette_rect(alpha)
    ref_a = top + int(.20*(bottom-top))
    ref_b = top + int(.45*(bottom-top))
    head_width = float(np.percentile(row_width[ref_a:ref_b], 70)) if ref_b>ref_a else max(1.,float(active.max()))
    # Smooth the widths to avoid seams caused by hair strands or shadows.
    smooth = np.convolve(row_width, np.ones(9)/9., mode='same')
    start = top + int(.53*(bottom-top))
    shoulder_rows = np.where(smooth[start:bottom] > max(10.,head_width*1.25))[0]
    if len(shoulder_rows):
        end = min(bottom, start + int(shoulder_rows[0]))
    else:
        end = top + int(.83*(bottom-top))
    end = max(top + int(.57*(bottom-top)), min(end, top+int(.94*(bottom-top))))
    head_mask = mask[top:end]
    head_y,head_x=np.where(head_mask)
    if len(head_x) < 12:
        return silhouette_rect(alpha)
    return (float(head_x.min())/width, float(top+head_y.min())/height,
            float(head_x.max()+1)/width, float(top+head_y.max()+1)/height)


def calibrate_orthographic(points_xyz, image_alpha, view, *, landmarks=None,
                           face=False, mask_rect=None):
    """Return camera (right, direction, su, ou, sv, ov).

    Camera transform: u = su * (point dot right) + ou;
                      v = sv * (-point.z) + ov.
    su/sv are normalized image units per mesh unit.  Manual landmarks must
    carry mesh XYZ world positions and corresponding image normalized UVs;
    3 or more pairs are recommended.  No 3D landmarks are invented by this API.
    """
    pts = np.asarray(points_xyz, dtype=np.float64)
    if pts.ndim != 2 or pts.shape[1] != 3 or len(pts) < 3:
        raise ValueError('Need Nx3 mesh point coordinates')
    direction, right = camera_basis(view)
    xy = np.column_stack((pts @ right, -pts[:, 2]))
    bounds = np.column_stack((np.percentile(xy, 0.15, axis=0),
                              np.percentile(xy, 99.85, axis=0)))
    if mask_rect is None:
        mask_rect = face_head_rect(image_alpha) if face else silhouette_rect(image_alpha)
    u0, v0, u1, v1 = (float(t) for t in mask_rect)
    rect = ((u0, u1), (v0, v1))
    scales, offsets = [], []
    for axis in range(2):
        span = max(1e-6, float(bounds[axis, 1] - bounds[axis, 0]))
        pixel_span = rect[axis][1] - rect[axis][0]
        scales.append(pixel_span / span)
        offsets.append(rect[axis][0] - scales[-1] * bounds[axis, 0])
    # With paired landmarks solve least-squares affine scale/translation
    # separately in u/v; clamp bad correspondences rather than exploding UVs.
    if landmarks and len(landmarks) >= 2:
        xyz = np.asarray([p['world_xyz'] for p in landmarks], dtype=np.float64)
        uv = np.asarray([p['image_uv'] for p in landmarks], dtype=np.float64)
        if xyz.shape == (len(landmarks), 3) and uv.shape == (len(landmarks), 2) and np.isfinite(xyz).all() and np.isfinite(uv).all():
            q = np.column_stack((xyz @ right, -xyz[:, 2]))
            for axis in range(2):
                if np.ptp(q[:, axis]) > 1e-5:
                    fitted, _, _, _ = np.linalg.lstsq(
                        np.column_stack((q[:, axis], np.ones(len(q)))), uv[:, axis], rcond=None)
                    if fitted[0] > 0 and 0.1 * scales[axis] <= fitted[0] <= 10 * scales[axis]:
                        scales[axis], offsets[axis] = map(float, fitted)
    return (right, direction, float(scales[0]), float(offsets[0]),
            float(scales[1]), float(offsets[1]))


def project_points(points_xyz, camera):
    pts = np.asarray(points_xyz)
    right, _, su, ou, sv, ov = camera
    return np.column_stack((su * (pts @ right) + ou, sv * (-pts[:, 2]) + ov))


def barycentric_pixels(uv_triangle: np.ndarray, size: int):
    """Return raster pixel coordinates and barycentrics for a UV triangle.

    UV origin at bottom-left, image origin at top-left.  Degenerate triangles
    are dropped.  Pixel-center sampling prevents bleeding along UV edges.
    """
    tri = np.asarray(uv_triangle, dtype=np.float64)
    if tri.shape != (3, 2):
        raise ValueError('Triangle UV must be (3,2)')
    x = tri[:, 0] * size
    y = (1. - tri[:, 1]) * size
    xmin = max(0, int(np.floor(x.min())))
    xmax = min(size, int(np.ceil(x.max())))
    ymin = max(0, int(np.floor(y.min())))
    ymax = min(size, int(np.ceil(y.max())))
    if xmax <= xmin or ymax <= ymin:
        return None
    denominator = (y[1] - y[2]) * (x[0] - x[2]) + (x[2] - x[1]) * (y[0] - y[2])
    if abs(denominator) < 1e-8:
        return None
    # Skip pathological UVs; invalid tiles must not exhaust worker memory.
    if (xmax - xmin) * (ymax - ymin) > int(size * size * .90):
        return None
    gy, gx = np.mgrid[ymin:ymax, xmin:xmax]
    px, py = gx.ravel() + .5, gy.ravel() + .5
    a = ((y[1] - y[2]) * (px - x[2]) + (x[2] - x[1]) * (py - y[2])) / denominator
    b = ((y[2] - y[0]) * (px - x[2]) + (x[0] - x[2]) * (py - y[2])) / denominator
    c = 1. - a - b
    inside = (a >= -1e-6) & (b >= -1e-6) & (c >= -1e-6)
    if not inside.any():
        return None
    return (gx.ravel()[inside], gy.ravel()[inside],
            np.column_stack((a[inside], b[inside], c[inside])).astype(np.float32))


def sample_rgba_nearest(image_rgba: np.ndarray, uv: np.ndarray):
    """Image is HxWx4 float32 top-left; avoid sampling outside cutout."""
    h, w, _ = image_rgba.shape
    uvs = np.asarray(uv)
    x = np.clip(np.rint(uvs[:, 0] * (w - 1)), 0, w - 1).astype(np.intp)
    y = np.clip(np.rint(uvs[:, 1] * (h - 1)), 0, h - 1).astype(np.intp)
    result = image_rgba[y, x]
    in_image = ((uvs[:, 0] >= 0) & (uvs[:, 0] <= 1) &
                (uvs[:, 1] >= 0) & (uvs[:, 1] <= 1))
    result = result.copy()
    result[~in_image, 3] = 0.
    return result



def sample_rgba_bilinear(image_rgba: np.ndarray, uv: np.ndarray):
    """Sample cutout photos smoothly without introducing black alpha fringes.

    Colors are combined in premultiplied-alpha space. Sampling outside the
    original photograph is fully transparent instead of edge-clamped.
    """
    img = np.asarray(image_rgba, dtype=np.float32)
    h, w, _ = img.shape
    coords = np.asarray(uv, dtype=np.float64)
    x = np.clip(coords[:, 0] * (w - 1), 0, w - 1)
    y = np.clip(coords[:, 1] * (h - 1), 0, h - 1)
    x0, y0 = np.floor(x).astype(np.int64), np.floor(y).astype(np.int64)
    x1, y1 = np.minimum(x0 + 1, w - 1), np.minimum(y0 + 1, h - 1)
    dx, dy = (x-x0).astype(np.float32), (y-y0).astype(np.float32)
    sampled = (img[y0,x0] * ((1-dx)*(1-dy))[:, None] +
               img[y0,x1] * (dx*(1-dy))[:, None] +
               img[y1,x0] * ((1-dx)*dy)[:, None] +
               img[y1,x1] * (dx*dy)[:, None])
    # Above is straight-alpha interpolation: correct RGB around cutout edges
    # by repeating interpolation with alpha-premultiplied inputs.
    def corner(ix, iy):
        rgba = img[iy, ix]
        return rgba[:, :3] * rgba[:, 3:4]
    pm = (corner(x0,y0) * ((1-dx)*(1-dy))[:, None] +
          corner(x1,y0) * (dx*(1-dy))[:, None] +
          corner(x0,y1) * ((1-dx)*dy)[:, None] +
          corner(x1,y1) * (dx*dy)[:, None])
    out = np.empty_like(sampled)
    out[:, 3] = sampled[:, 3]
    out[:, :3] = pm / np.maximum(sampled[:, 3:4], 1e-7)
    in_bounds = np.isfinite(coords).all(axis=1) & (coords[:, 0] >= 0) & (coords[:, 0] <= 1) & (coords[:, 1] >= 0) & (coords[:, 1] <= 1)
    out[~in_bounds] = 0.
    return out


def seam_dilate(rgb: np.ndarray, coverage: np.ndarray, *, iterations: int = 8):
    """Pad UV islands outwards into gutters, without toroidal wrap-around."""
    image = np.asarray(rgb, dtype=np.float32).copy()
    filled = np.asarray(coverage, dtype=bool).copy()
    for _ in range(iterations):
        expanded = filled.copy()
        for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            ny0, ny1 = max(0, dy), min(filled.shape[0], filled.shape[0]+dy)
            nx0, nx1 = max(0, dx), min(filled.shape[1], filled.shape[1]+dx)
            src_y0, src_y1 = max(0, -dy), min(filled.shape[0], filled.shape[0]-dy)
            src_x0, src_x1 = max(0, -dx), min(filled.shape[1], filled.shape[1]-dx)
            src_f = filled[src_y0:src_y1, src_x0:src_x1]
            needs = ~expanded[ny0:ny1, nx0:nx1] & src_f
            image[ny0:ny1, nx0:nx1][needs] = image[src_y0:src_y1, src_x0:src_x1][needs]
            expanded[ny0:ny1, nx0:nx1][needs] = True
        if np.array_equal(expanded, filled):
            break
        filled = expanded
    return image, filled
