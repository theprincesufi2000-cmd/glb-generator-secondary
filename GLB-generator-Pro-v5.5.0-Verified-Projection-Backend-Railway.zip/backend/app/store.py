from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
import hashlib
import sqlite3
from threading import RLock
from typing import Any


TERMINAL_STATES = {"completed", "failed", "cancelled"}

TRANSIENT_STATES = {
    "uploading",
    "waiting_provider",
    "generating",
    "preprocessing",
    "refining",
    "watertight_repair",
    "geometry_refinement",
    "face_refinement",
    "hand_refinement",
    "hair_refinement",
    "clothing_refinement",
    "uv_unwrap",
    "face_projection",
    "body_projection",
    "pbr_maps",
    "texture_baking",
    "optimizing_preview",
    "downloading",
}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def after_seconds_iso(seconds: int) -> str:
    return (datetime.now(timezone.utc) + timedelta(seconds=max(0, int(seconds)))).isoformat()


class JobStore:
    def __init__(self, database_path: Path):
        self.database_path = Path(database_path)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()
        self._init_db()

    def _connect(self):
        conn = sqlite3.connect(self.database_path, timeout=30, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=FULL")
        return conn

    def _init_db(self):
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS jobs (
                    id TEXT PRIMARY KEY,
                    status TEXT NOT NULL,
                    progress INTEGER NOT NULL,
                    message TEXT NOT NULL,
                    front_path TEXT NOT NULL,
                    back_path TEXT NOT NULL,
                    left_path TEXT NOT NULL,
                    right_path TEXT NOT NULL,
                    output_path TEXT,
                    provider TEXT,
                    attempt_count INTEGER NOT NULL DEFAULT 0,
                    last_error TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            existing = {row[1] for row in conn.execute("PRAGMA table_info(jobs)").fetchall()}
            migrations = {
                "quality_mode": "TEXT NOT NULL DEFAULT 'legacy'",
                "remesh": "INTEGER NOT NULL DEFAULT 0",
                "front_45_path": "TEXT",
                "back_45_path": "TEXT",
                "face_front_path": "TEXT",
                "face_45_path": "TEXT",
                "face_left_45_path": "TEXT",
                "face_right_45_path": "TEXT",
                "face_left_profile_path": "TEXT",
                "face_right_profile_path": "TEXT",
                "left_hand_path": "TEXT",
                "right_hand_path": "TEXT",
                "hair_detail_path": "TEXT",
                "clothes_detail_path": "TEXT",
                "base_path": "TEXT",
                "preview_path": "TEXT",
                "high_quality_path": "TEXT",
                "retry_after_at": "TEXT",
                "generation_mode": "TEXT NOT NULL DEFAULT 'cloud_only'",
                "output_mode": "TEXT NOT NULL DEFAULT 'full_glb'",
                "texture_mode": "TEXT NOT NULL DEFAULT 'auto'",
                "local_fallback_required": "INTEGER NOT NULL DEFAULT 0",
                "texture_project_path": "TEXT",
            }
            for column, ddl in migrations.items():
                if column not in existing:
                    conn.execute(f"ALTER TABLE jobs ADD COLUMN {column} {ddl}")
            conn.commit()

    def create_job(
        self,
        *,
        job_id: str,
        paths: dict[str, str],
        quality_mode: str = "legacy",
        remesh: bool = False,
        optional_paths: dict[str, str | None] | None = None,
        generation_mode: str = "cloud_only",
        output_mode: str = "full_glb",
        texture_mode: str = "auto",
    ) -> dict[str, Any]:
        optional_paths = optional_paths or {}
        stamp = now_iso()
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT INTO jobs (
                    id,status,progress,message,front_path,back_path,left_path,right_path,
                    output_path,provider,attempt_count,last_error,created_at,updated_at,
                    quality_mode,remesh,front_45_path,back_45_path,face_front_path,face_45_path,
                    face_left_45_path,face_right_45_path,face_left_profile_path,face_right_profile_path,
                    left_hand_path,right_hand_path,hair_detail_path,clothes_detail_path,
                    base_path,preview_path,high_quality_path,
                    generation_mode,output_mode,texture_mode,local_fallback_required,texture_project_path
                ) VALUES (
                    ?, 'queued', 1, 'Job accepted and stored', ?, ?, ?, ?,
                    NULL, NULL, 0, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL, NULL,
                    ?, ?, ?, 0, NULL
                )
                """,
                (
                    job_id,
                    paths["front"],
                    paths["back"],
                    paths["left"],
                    paths["right"],
                    stamp,
                    stamp,
                    quality_mode,
                    1 if remesh else 0,
                    optional_paths.get("front_45"),
                    optional_paths.get("back_45"),
                    optional_paths.get("face_front"),
                    optional_paths.get("face_45"),
                    optional_paths.get("face_left_45"),
                    optional_paths.get("face_right_45"),
                    optional_paths.get("face_left_profile"),
                    optional_paths.get("face_right_profile"),
                    optional_paths.get("left_hand"),
                    optional_paths.get("right_hand"),
                    optional_paths.get("hair_detail"),
                    optional_paths.get("clothes_detail"),
                    generation_mode,
                    output_mode,
                    texture_mode,
                ),
            )
            conn.commit()
        return self.get_job(job_id)  # type: ignore[return-value]

    def get_job(self, job_id: str) -> dict[str, Any] | None:
        with self._lock, self._connect() as conn:
            row = conn.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
            return dict(row) if row else None

    def update_job(self, job_id: str, **changes) -> dict[str, Any]:
        if not changes:
            job = self.get_job(job_id)
            if job is None:
                raise KeyError(job_id)
            return job
        changes["updated_at"] = now_iso()
        columns = ", ".join(f"{key} = ?" for key in changes)
        values = list(changes.values()) + [job_id]
        with self._lock, self._connect() as conn:
            cursor = conn.execute(f"UPDATE jobs SET {columns} WHERE id = ?", values)
            if cursor.rowcount == 0:
                raise KeyError(job_id)
            conn.commit()
        return self.get_job(job_id)  # type: ignore[return-value]

    def cancel_job(self, job_id: str, message: str = "Generation cancelled by user") -> dict[str, Any]:
        job = self.get_job(job_id)
        if job is None:
            raise KeyError(job_id)
        if job.get("status") in TERMINAL_STATES:
            return job
        return self.update_job(
            job_id,
            status="cancelled",
            progress=min(int(job.get("progress") or 0), 99),
            message=message,
            retry_after_at=None,
            local_fallback_required=0,
            last_error=None,
        )

    def is_cancelled(self, job_id: str) -> bool:
        job = self.get_job(job_id)
        return bool(job and job.get("status") == "cancelled")

    def next_queued(self) -> dict[str, Any] | None:
        with self._lock, self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM jobs WHERE status = 'queued' AND (retry_after_at IS NULL OR retry_after_at <= ?) ORDER BY created_at ASC LIMIT 1"
                , (now_iso(),)
            ).fetchone()
            return dict(row) if row else None


    @staticmethod
    def _input_signature(job: dict[str, Any]) -> tuple[str, str, str, str] | None:
        digests: list[str] = []
        for key in ("front_path", "back_path", "left_path", "right_path"):
            value = job.get(key)
            if not value:
                return None
            path = Path(value)
            if not path.exists() or not path.is_file():
                return None
            hasher = hashlib.sha256()
            with path.open("rb") as handle:
                for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                    hasher.update(chunk)
            digests.append(hasher.hexdigest())
        return tuple(digests)  # type: ignore[return-value]

    def find_reusable_base(self, job_id: str) -> Path | None:
        current = self.get_job(job_id)
        if current is None:
            return None
        signature = self._input_signature(current)
        if signature is None:
            return None
        with self._lock, self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM jobs WHERE id != ? AND base_path IS NOT NULL ORDER BY updated_at DESC",
                (job_id,),
            ).fetchall()
        for row in rows:
            candidate = dict(row)
            base_value = candidate.get("base_path")
            if not base_value:
                continue
            base = Path(base_value)
            if not base.exists() or not base.is_file() or base.stat().st_size < 4:
                continue
            if self._input_signature(candidate) == signature:
                return base
        return None

    def normalize_interrupted(self) -> int:
        placeholders = ",".join("?" for _ in TRANSIENT_STATES)
        stamp = now_iso()
        with self._lock, self._connect() as conn:
            cur = conn.execute(
                f"UPDATE jobs SET status='queued', progress=5, message='Resuming after backend restart', updated_at=? WHERE status IN ({placeholders})",
                [stamp, *sorted(TRANSIENT_STATES)],
            )
            conn.commit()
            return cur.rowcount
    def prune_terminal_jobs(self, jobs_dir: Path, keep_recent: int = 2) -> int:
        import shutil
        jobs_dir = Path(jobs_dir)
        keep_recent = max(0, int(keep_recent))
        with self._lock, self._connect() as conn:
            rows = conn.execute(
                "SELECT id, status, updated_at FROM jobs WHERE status IN ('completed','failed','cancelled') ORDER BY updated_at DESC"
            ).fetchall()
            doomed = [dict(row) for row in rows[keep_recent:]]
            removed = 0
            for row in doomed:
                job_id = str(row['id'])
                shutil.rmtree(jobs_dir / job_id, ignore_errors=True)
                conn.execute("DELETE FROM jobs WHERE id = ?", (job_id,))
                removed += 1
            conn.commit()
        return removed

