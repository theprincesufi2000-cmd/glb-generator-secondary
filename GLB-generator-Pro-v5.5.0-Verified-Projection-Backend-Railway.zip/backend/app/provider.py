from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import random
import re
import shutil
import time
from typing import Callable, Any

from gradio_client import Client, handle_file

from .config import Settings


RETRY_MARKERS = (
    "408", "425", "429", "500", "502", "503", "504",
    "timeout", "timed out", "temporarily unavailable", "service unavailable",
    "bad gateway", "gateway timeout", "connection reset", "connection refused",
    "remote disconnected", "dns", "name resolution", "no gpu", "queue",
)


@dataclass(frozen=True)
class SpaceTarget:
    space_id: str
    display_name: str
    include_caption: bool


class ProviderUnavailable(RuntimeError):
    pass


class ProviderQuotaExceeded(ProviderUnavailable):
    def __init__(self, message: str, *, retry_after_seconds: int):
        super().__init__(message)
        self.retry_after_seconds = max(60, int(retry_after_seconds))


class HunyuanProvider:
    def __init__(
        self,
        settings: Settings,
        *,
        client_factory: Callable[[str], Any] | None = None,
        file_adapter: Callable[[str], Any] | None = None,
        sleep_fn: Callable[[float], None] | None = None,
        monotonic_fn: Callable[[], float] | None = None,
    ):
        self.settings = settings
        self.client_factory = client_factory
        self.file_adapter = file_adapter or handle_file
        self.sleep_fn = sleep_fn or time.sleep
        self.monotonic_fn = monotonic_fn or time.monotonic
        self.targets = (
            SpaceTarget("tencent/Hunyuan3D-2mv", "Hunyuan3D-2MV", True),
            SpaceTarget("tencent/Hunyuan3D-2.1", "Hunyuan3D-2.1", False),
        )


    @staticmethod
    def _quota_retry_seconds(exc: BaseException) -> int | None:
        text = str(exc)
        lowered = text.lower()
        if "zerogpu quota" not in lowered and "exceeded your zerogpu" not in lowered:
            return None
        match = re.search(r"try\s+again\s+in\s+(?:(\d+)\s+day[s]?[,:]?\s*)?(\d+):(\d+):(\d+)", text, re.IGNORECASE)
        if match:
            days = int(match.group(1) or 0)
            hours = int(match.group(2))
            minutes = int(match.group(3))
            seconds = int(match.group(4))
            return days * 86400 + hours * 3600 + minutes * 60 + seconds + 60
        match = re.search(r"try\s+again\s+in\s+(\d+)\s*(?:s|sec|secs|second|seconds)\b", text, re.IGNORECASE)
        if match:
            return int(match.group(1)) + 15
        return 3600

    def _client(self, space_id: str):
        if self.client_factory is not None:
            return self.client_factory(space_id)
        return Client(space_id, token=(self.settings.hf_token or None), verbose=False)

    @staticmethod
    def _retryable(exc: BaseException) -> bool:
        if isinstance(exc, ProviderUnavailable):
            return True
        text = f"{type(exc).__name__}: {exc}".lower()
        return any(marker in text for marker in RETRY_MARKERS)

    @classmethod
    def _extract_result_path(cls, value: Any) -> Path:
        if isinstance(value, Path):
            return value
        if isinstance(value, str):
            return Path(value)
        if isinstance(value, dict):
            for key in ("path", "name", "file"):
                candidate = value.get(key)
                if candidate:
                    try:
                        return cls._extract_result_path(candidate)
                    except ProviderUnavailable:
                        pass
            for candidate in value.values():
                try:
                    return cls._extract_result_path(candidate)
                except ProviderUnavailable:
                    continue
        if isinstance(value, (list, tuple)):
            for candidate in value:
                try:
                    return cls._extract_result_path(candidate)
                except ProviderUnavailable:
                    continue
        for attr in ("path", "name"):
            candidate = getattr(value, attr, None)
            if candidate:
                try:
                    return cls._extract_result_path(candidate)
                except ProviderUnavailable:
                    pass
        raise ProviderUnavailable("Provider returned an unsupported model-file response")

    def _generate_target(
        self,
        target: SpaceTarget,
        *,
        front: Path,
        back: Path,
        left: Path,
        right: Path,
        output: Path,
    ) -> Path:
        client = self._client(target.space_id)
        common = dict(
            image=None,
            mv_image_front=self.file_adapter(str(front)),
            mv_image_back=self.file_adapter(str(back)),
            mv_image_left=self.file_adapter(str(left)),
            mv_image_right=self.file_adapter(str(right)),
            steps=30,
            guidance_scale=5.0,
            seed=1234,
            octree_resolution=512,
            check_box_rembg=True,
            num_chunks=12000,
            randomize_seed=False,
            api_name="/shape_generation",
        )
        if target.include_caption:
            result = client.predict(caption="", **common)
        else:
            result = client.predict(**common)

        if result is None:
            raise ProviderUnavailable("Provider returned no model file")
        source = self._extract_result_path(result)
        if not source.exists() or source.stat().st_size == 0:
            raise ProviderUnavailable("Provider model file is empty or missing")
        output.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, output)
        if output.stat().st_size < 4:
            raise ProviderUnavailable("Generated GLB is invalid")
        return output

    def generate(
        self,
        *,
        front: Path,
        back: Path,
        left: Path,
        right: Path,
        output: Path,
        on_update: Callable[[str, str, int, str], None],
    ) -> Path:
        deadline = self.monotonic_fn() + max(1, self.settings.provider_retry_minutes) * 60
        cycle = 0
        last_error: BaseException | None = None

        while True:
            for target in self.targets:
                on_update(target.display_name, "waiting_provider", 20, f"Connecting to {target.display_name}")
                try:
                    on_update(target.display_name, "generating", 55, f"Generating with {target.display_name}")
                    return self._generate_target(
                        target,
                        front=front,
                        back=back,
                        left=left,
                        right=right,
                        output=output,
                    )
                except BaseException as exc:
                    quota_wait = self._quota_retry_seconds(exc)
                    if quota_wait is not None:
                        raise ProviderQuotaExceeded(str(exc), retry_after_seconds=quota_wait) from exc
                    last_error = exc
                    if not self._retryable(exc):
                        raise
                    on_update(
                        target.display_name,
                        "waiting_provider",
                        25,
                        f"{target.display_name} is temporarily unavailable; trying another provider",
                    )

            if self.monotonic_fn() >= deadline:
                raise ProviderUnavailable(
                    f"3D providers stayed unavailable for {self.settings.provider_retry_minutes} minutes: {last_error}"
                ) from last_error

            cycle += 1
            base = min(60.0, 5.0 * (2 ** min(cycle - 1, 4)))
            wait = base + random.uniform(0.0, 2.0)
            on_update("Hunyuan", "waiting_provider", 25, f"All providers busy; retrying in {int(wait)}s")
            self.sleep_fn(wait)
