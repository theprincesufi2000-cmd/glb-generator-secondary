from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Any


@dataclass(frozen=True)
class GeometryRepairPlan:
    watertight_pass: bool
    shell_thickness_ratio: float
    voxel_resolution_divisor: float
    hq_max_triangles: int
    preview_max_triangles: int
    smoothing_passes: int


def build_geometry_repair_plan(*, quality_mode: str, remesh: bool, memory_profile: str, requested_hq_triangles: int, requested_preview_triangles: int) -> GeometryRepairPlan:
    quality_mode = (quality_mode or 'pro_hq').strip().lower()
    memory_profile = (memory_profile or '1gb').strip().lower()
    if quality_mode in {'pro_fidelity', 'ultra_detail'}:
        if memory_profile == '1gb':
            hq = max(requested_hq_triangles, 280000 if quality_mode == 'ultra_detail' else 240000)
            prev = max(requested_preview_triangles, 90000)
            divisor = 560.0
        elif memory_profile == '2gb':
            hq = max(requested_hq_triangles, 520000 if quality_mode == 'ultra_detail' else 420000)
            prev = max(requested_preview_triangles, 130000)
            divisor = 980.0
        else:
            hq = max(requested_hq_triangles, 900000 if quality_mode == 'ultra_detail' else 700000)
            prev = max(requested_preview_triangles, 180000)
            divisor = 1240.0
        return GeometryRepairPlan(
            watertight_pass=True,
            shell_thickness_ratio=1.0 / (920.0 if quality_mode == 'ultra_detail' else 850.0),
            voxel_resolution_divisor=divisor,
            hq_max_triangles=hq,
            preview_max_triangles=prev,
            smoothing_passes=1 if memory_profile == '1gb' else 2,
        )

    if memory_profile == '1gb':
        hq = max(requested_hq_triangles, 150000)
        prev = max(requested_preview_triangles, 60000)
    elif memory_profile == '2gb':
        hq = max(requested_hq_triangles, 300000)
        prev = max(requested_preview_triangles, 100000)
    else:
        hq = max(requested_hq_triangles, 500000)
        prev = max(requested_preview_triangles, 120000)
    return GeometryRepairPlan(
        watertight_pass=bool(remesh),
        shell_thickness_ratio=1.0 / 1150.0,
        voxel_resolution_divisor=640.0,
        hq_max_triangles=hq,
        preview_max_triangles=prev,
        smoothing_passes=1,
    )


def manifest_values(plan: GeometryRepairPlan) -> dict[str, Any]:
    return {
        'watertight_pass': bool(plan.watertight_pass),
        'shell_thickness_ratio': float(plan.shell_thickness_ratio),
        'voxel_resolution_divisor': float(plan.voxel_resolution_divisor),
        'hq_max_triangles': int(plan.hq_max_triangles),
        'preview_max_triangles': int(plan.preview_max_triangles),
        'smoothing_passes': int(plan.smoothing_passes),
    }
