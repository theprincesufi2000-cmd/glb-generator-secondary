from __future__ import annotations

from collections import deque
from pathlib import Path
from typing import Iterable
import math

from PIL import Image, ImageFilter


Crop = tuple[float, float, float, float]


def _distance(a: tuple[int, int, int], b: tuple[int, int, int]) -> float:
    return math.sqrt(sum((int(x) - int(y)) ** 2 for x, y in zip(a, b)))


def _border_samples(image: Image.Image) -> list[tuple[int, int, int]]:
    px = image.load()
    width, height = image.size
    out: list[tuple[int, int, int]] = []
    step_x = max(1, width // 96)
    step_y = max(1, height // 96)
    for x in range(0, width, step_x):
        out.append(px[x, 0])
        out.append(px[x, height - 1])
    for y in range(0, height, step_y):
        out.append(px[0, y])
        out.append(px[width - 1, y])
    return out


def _median(values: Iterable[int]) -> int:
    ordered = sorted(values)
    if not ordered:
        return 0
    return ordered[len(ordered) // 2]


def _foreground_mask(image: Image.Image) -> Image.Image:
    """Separate a person from a wall *and* a differently colored floor.

    The older global border flood-fill used a single background color for the
    entire photo, so a floor/wall horizon was misclassified as part of the body.
    A row-adaptive chroma reference handles background changes with height.
    Keep the central, connected subject and discard off-person noise.
    """
    if 'A' in image.getbands():
        # Real alpha from cut-out photos is more reliable than inferring subject
        # edges from black background RGB. Black clothes and hair must remain.
        alpha = image.getchannel('A')
        if alpha.getextrema()[0] < 32 and alpha.getextrema()[1] > 160:
            if max(alpha.size) > 512:
                scale = 512.0 / float(max(alpha.size))
                alpha = alpha.resize((max(1, round(alpha.width * scale)),
                                      max(1, round(alpha.height * scale))),
                                     Image.Resampling.LANCZOS)
            return alpha.point(lambda v: 255 if v >= 90 else 0)
    rgb = image.convert('RGB')
    if max(rgb.size) > 512:
        scale = 512.0 / float(max(rgb.size))
        rgb = rgb.resize((max(1, round(rgb.width * scale)), max(1, round(rgb.height * scale))),
                         Image.Resampling.LANCZOS)
    w, h = rgb.size
    pix = rgb.load()
    inset = max(1, round(w * 0.022))
    width = max(2, round(w * 0.038))
    reference = []
    # Sample outer vertical bands separately by row; the median is robust to
    # occasional hands approaching the left or right edge in T-pose shots.
    for y in range(h):
        pts = [pix[x, y] for x in range(inset, min(w, inset + width))]
        pts.extend(pix[x, y] for x in range(max(0, w - inset - width), w - inset))
        reference.append(tuple(_median(c[i] for c in pts) for i in range(3)))
    # Replace short-lived border occlusions (such as hands) with neighboring
    # row statistics, without smoothing out a persistent wall/floor boundary.
    smoothed = []
    radius = 8
    for y in range(h):
        window = reference[max(0, y - radius):min(h, y + radius + 1)]
        smoothed.append(tuple(_median(c[i] for c in window) for i in range(3)))

    raw = Image.new('L', (w, h), 0)
    mask_pix = raw.load()
    for y in range(h):
        bg = smoothed[y]
        for x in range(w):
            # A moderately high tolerance avoids interpreting wall grain or
            # sidewalk speckles as skin/cloth detail.
            color = pix[x, y]
            delta = tuple(int(color[i]) - int(bg[i]) for i in range(3))
            brightness = sum(delta) / 3.0
            chroma = sum(abs(d - brightness) for d in delta)
            # Neutral wall/floor shadows affect brightness but largely retain
            # background chromaticity; do not stretch the UV silhouette to them.
            if _distance(color, bg) > 34 and (chroma > 14 or abs(brightness) > 64):
                mask_pix[x, y] = 255
    # Close isolated foreground flecks and connect narrow skin/cloth surfaces.
    raw = raw.filter(ImageFilter.MaxFilter(5)).filter(ImageFilter.MinFilter(3))
    raw_pixels = raw.load()
    seen = bytearray(w * h)
    best_component = []
    central_components = []
    seed_target_x = w * .5
    # Prefer the central person's connected component over low sidewalk
    # patterns; border-connected floor alone must never define body height.
    for y in range(h):
        for x in range(w):
            index = y * w + x
            if seen[index] or raw_pixels[x, y] < 128:
                continue
            queue = deque([(x, y)])
            seen[index] = 1
            component = []
            central = False
            while queue:
                qx, qy = queue.popleft()
                component.append((qx, qy))
                if abs(qx - seed_target_x) < w * .20 and h * .12 < qy < h * .82:
                    central = True
                for nx, ny in ((qx-1, qy), (qx+1, qy), (qx, qy-1), (qx, qy+1)):
                    if 0 <= nx < w and 0 <= ny < h:
                        ni = ny * w + nx
                        if not seen[ni] and raw_pixels[nx, ny] >= 128:
                            seen[ni] = 1
                            queue.append((nx, ny))
            if central:
                central_components.append(component)
                if len(component) > len(best_component):
                    best_component = component
    if not best_component:
        return raw
    result = Image.new('L', (w, h), 0)
    rp = result.load()
    main_ys = [y for _, y in best_component]
    main_top, main_bottom = min(main_ys), max(main_ys)
    main_height = max(1, main_bottom - main_top)
    for candidate in central_components:
        ys_candidate = [y for _, y in candidate]
        overlap = max(0, min(main_bottom, max(ys_candidate)) - max(main_top, min(ys_candidate)))
        # Preserve substantial disconnected limbs/body sections, but reject
        # shadow flecks and floor fragments.
        if (len(candidate) >= len(best_component) * 0.14 and
                overlap >= main_height * 0.55):
            for x, y in candidate:
                rp[x, y] = 255
    # T-pose fingertips may disconnect from the main silhouette for a few
    # rows where skin and wall have similar brightness. Reinstate candidate
    # skin pixels only in the upper shoulder/arm strip (not on the floor).
    ys = [pt[1] for pt in best_component]
    top, bottom = min(ys), max(ys)
    for y in range(max(0, top + round((bottom-top)*0.12)),
                   min(h, top + round((bottom-top)*0.35))):
        for x in range(w):
            if raw_pixels[x, y] >= 128:
                rp[x, y] = 255
    return result.filter(ImageFilter.MaxFilter(3))


def _bbox_from_mask(mask: Image.Image) -> tuple[int, int, int, int] | None:
    bbox = mask.getbbox()
    if not bbox:
        return None
    left, top, right, bottom = bbox
    if right - left < mask.width * 0.08 or bottom - top < mask.height * 0.12:
        return None
    return left, top, right, bottom


def _body_bbox(mask: Image.Image, subject: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    left, top, right, bottom = subject
    px = mask.load()
    height = max(1, bottom - top)
    # Ignore the lowest band when measuring horizontal extent: floor shadows are
    # common in studio photos and must not make the clothing texture wider.
    y_end = max(top + 1, bottom - int(height * 0.08))
    row_lefts: list[int] = []
    row_rights: list[int] = []
    for y in range(top, y_end):
        xs = [x for x in range(left, right) if px[x, y] >= 128]
        if xs:
            row_lefts.append(min(xs))
            row_rights.append(max(xs) + 1)
    if not row_lefts:
        return subject

    row_lefts.sort()
    row_rights.sort()
    li = min(len(row_lefts) - 1, max(0, int(len(row_lefts) * 0.06)))
    ri = min(len(row_rights) - 1, max(0, int(len(row_rights) * 0.94)))
    robust_left = row_lefts[li]
    robust_right = row_rights[ri]
    # Arms occupy only a few vertical rows in T-pose images. The previous
    # 6th/94th percentile row crop literally removed both forearms, causing
    # them to sample torso colors. Recover consistent *wide* shoulder rows.
    shoulder_start = top + round(height * 0.12)
    shoulder_end = top + round(height * 0.36)
    wide_rows = []
    for y in range(shoulder_start, min(bottom, shoulder_end)):
        xs = [x for x in range(left, right) if px[x, y] >= 128]
        if xs and max(xs) - min(xs) >= (robust_right - robust_left) * 1.55:
            wide_rows.append((min(xs), max(xs) + 1))
    if len(wide_rows) >= 3:
        robust_left = min(robust_left, sorted(p[0] for p in wide_rows)[len(wide_rows)//5])
        robust_right = max(robust_right, sorted(p[1] for p in wide_rows)[4*len(wide_rows)//5])
    # A frontal T-pose can almost touch both image edges for only 8-12 rows.
    # Do not discard the outstretched hands as statistical outliers.
    tpose_rows = []
    for y in range(shoulder_start, min(bottom, shoulder_end)):
        xs = [x for x in range(left, right) if px[x, y] >= 128]
        if xs and max(xs) - min(xs) >= mask.width * 0.77:
            tpose_rows.append((min(xs), max(xs) + 1))
    if len(tpose_rows) >= 3:
        robust_left = min(robust_left, min(p[0] for p in tpose_rows))
        robust_right = max(robust_right, max(p[1] for p in tpose_rows))
    pad_x = max(2, int((robust_right - robust_left) * 0.025))
    pad_y = max(2, int(height * 0.012))
    return (
        max(0, robust_left - pad_x),
        max(0, top - pad_y),
        min(mask.width, robust_right + pad_x),
        min(mask.height, bottom + pad_y),
    )


def _head_bbox(mask: Image.Image, subject: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    left, top, right, bottom = subject
    px = mask.load()
    fg_height = max(1, bottom - top)

    widths: list[tuple[int, int, int]] = []
    for y in range(top, bottom):
        xs = [x for x in range(left, right) if px[x, y] >= 128]
        if xs:
            widths.append((y, min(xs), max(xs) + 1))

    if not widths:
        return subject

    upper = [r - l for y, l, r in widths if top + fg_height * 0.15 <= y <= top + fg_height * 0.55]
    median_width = _median(upper) if upper else max(1, right - left)
    shoulder_y = None
    search_start = top + int(fg_height * 0.50)
    for y, row_left, row_right in widths:
        if y < search_start:
            continue
        if row_right - row_left > median_width * 1.30:
            shoulder_y = y
            break

    if shoulder_y is None:
        head_bottom = top + int(fg_height * 0.78)
    else:
        head_bottom = min(bottom, shoulder_y + int(fg_height * 0.08))

    horizontal_limit = shoulder_y - 1 if shoulder_y is not None else head_bottom
    head_rows = [(y, l, r) for y, l, r in widths if y <= horizontal_limit]
    if not head_rows:
        head_rows = [(y, l, r) for y, l, r in widths if y <= head_bottom]
    head_left = min(l for _, l, _ in head_rows)
    head_right = max(r for _, _, r in head_rows)

    pad_x = max(2, int((head_right - head_left) * 0.035))
    pad_y = max(2, int((head_bottom - top) * 0.025))
    return (
        max(0, head_left - pad_x),
        max(0, top - pad_y),
        min(mask.width, head_right + pad_x),
        min(mask.height, head_bottom + pad_y),
    )


def estimate_projection_crop(path: Path, *, face: bool = False) -> Crop:
    """Return a normalized image crop (left, top, right, bottom).

    The crop is derived from the actual subject silhouette instead of assuming the
    person fills the entire photograph. This prevents projected textures from being
    stretched whenever source images contain different camera margins.
    """
    with Image.open(path) as source:
        original_size = source.size
        mask = _foreground_mask(source)

    bbox = _bbox_from_mask(mask)
    if bbox is None:
        return (0.0, 0.0, 1.0, 1.0)
    if face:
        bbox = _head_bbox(mask, bbox)
    else:
        bbox = _body_bbox(mask, bbox)

    left, top, right, bottom = bbox
    # Mask may have been resized to max 512; normalization makes that irrelevant.
    crop = (
        left / float(mask.width),
        top / float(mask.height),
        right / float(mask.width),
        bottom / float(mask.height),
    )

    min_span = 0.08 if face else 0.15
    l, t, r, b = crop
    if r - l < min_span or b - t < min_span:
        return (0.0, 0.0, 1.0, 1.0)

    if face and r - l > 0.818:
        center = 0.5
        half = 0.409
        l = center - half
        r = center + half
        if l < 0.0:
            r -= l
            l = 0.0
        if r > 1.0:
            l -= r - 1.0
            r = 1.0
    if face:
        b = min(b, 0.86)

    return tuple(max(0.0, min(1.0, float(v))) for v in (l, t, r, b))  # type: ignore[return-value]



def _nearest_foreground_fill(rgb: Image.Image, mask: Image.Image) -> Image.Image:
    """Fill every background pixel with the nearest foreground color.

    The working image is intentionally small (<=512px on its longest side), so
    a multi-source BFS is both deterministic and memory-safe. This removes the
    white/empty channels between arms, torso and legs before projection.
    """
    rgb = rgb.convert("RGB")
    mask = mask.convert("L")
    width, height = rgb.size
    if mask.size != rgb.size:
        mask = mask.resize(rgb.size, Image.Resampling.NEAREST)
    src = rgb.load()
    mp = mask.load()
    out = Image.new("RGB", rgb.size)
    dst = out.load()
    visited = bytearray(width * height)
    q: deque[tuple[int, int]] = deque()

    for y in range(height):
        for x in range(width):
            if mp[x, y] >= 128:
                dst[x, y] = src[x, y]
                visited[y * width + x] = 1
                q.append((x, y))

    if not q:
        return rgb.copy()

    while q:
        x, y = q.popleft()
        color = dst[x, y]
        for nx, ny in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
            if nx < 0 or nx >= width or ny < 0 or ny >= height:
                continue
            idx = ny * width + nx
            if visited[idx]:
                continue
            visited[idx] = 1
            dst[nx, ny] = color
            q.append((nx, ny))
    return out


def prepare_projection_texture(path: Path, output: Path, *, face: bool = False) -> Path:
    """Create a subject-fitted, background-free projection texture.

    The source is cropped to the detected person/head and every remaining
    background channel is edge-filled from the nearest subject pixel. Keeping the
    output opaque avoids white halos and transparent holes after GLB/JPEG export.
    """
    path = Path(path)
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)

    with Image.open(path) as opened:
        mask = _foreground_mask(opened)
        source = opened.convert("RGB")
        bbox = _bbox_from_mask(mask)
        if bbox is None:
            source.save(output, format="PNG" if output.suffix.lower() == '.png' else "JPEG")
            return output
        bbox = _head_bbox(mask, bbox) if face else _body_bbox(mask, bbox)

        ml, mt, mr, mb = bbox
        # Convert low-resolution mask coordinates back to source coordinates.
        sx = source.width / float(mask.width)
        sy = source.height / float(mask.height)
        left = max(0, int(math.floor(ml * sx)))
        top = max(0, int(math.floor(mt * sy)))
        right = min(source.width, int(math.ceil(mr * sx)))
        bottom = min(source.height, int(math.ceil(mb * sy)))
        if right <= left or bottom <= top:
            source.save(output, format="PNG" if output.suffix.lower() == '.png' else "JPEG")
            return output

        source_crop = source.crop((left, top, right, bottom))
        mask_crop = mask.crop((ml, mt, mr, mb))
        # Remove the outermost anti-aliased/background fringe before compositing.
        if mask_crop.width >= 3 and mask_crop.height >= 3:
            mask_crop = mask_crop.filter(ImageFilter.MinFilter(5))

        small_source = source.resize(mask.size, Image.Resampling.LANCZOS).crop((ml, mt, mr, mb))
        filled_small = _nearest_foreground_fill(small_source, mask_crop)
        filler = filled_small.resize(source_crop.size, Image.Resampling.BICUBIC)
        alpha = mask_crop.resize(source_crop.size, Image.Resampling.LANCZOS)
        prepared = Image.composite(source_crop, filler, alpha)
        if output.suffix.lower() == '.png':
            prepared.save(output, format='PNG', optimize=True)
        else:
            prepared.save(output, format="JPEG", quality=97, subsampling=0, optimize=True)
    return output
