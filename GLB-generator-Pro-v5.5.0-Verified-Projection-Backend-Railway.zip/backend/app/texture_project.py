from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, Field, model_validator


BodyRegion = Literal[
    "face", "head", "neck",
    "chest_upper", "chest_lower", "abdomen", "pelvis",
    "back_upper", "back_lower",
    "shoulder_left", "shoulder_right",
    "upper_arm_left", "upper_arm_right",
    "forearm_left", "forearm_right",
    "hand_left", "hand_right",
    "thigh_left", "thigh_right",
    "calf_left", "calf_right",
    "foot_left", "foot_right",
]
ProjectionDirection = Literal["front", "back", "left", "right", "front_45", "back_45"]
TextureMode = Literal["auto", "manual", "hybrid", "none"]


class TextureRegionSpec(BaseModel):
    region: BodyRegion
    source: str = Field(min_length=1, max_length=128)
    direction: ProjectionDirection = "front"
    offset_x: float = Field(default=0.0, ge=-2.0, le=2.0)
    offset_y: float = Field(default=0.0, ge=-2.0, le=2.0)
    scale_x: float = Field(default=1.0, ge=0.05, le=8.0)
    scale_y: float = Field(default=1.0, ge=0.05, le=8.0)
    rotation_deg: float = Field(default=0.0, ge=-360.0, le=360.0)
    mirror_x: bool = False
    mirror_y: bool = False
    opacity: float = Field(default=1.0, ge=0.0, le=1.0)
    feather: float = Field(default=0.0, ge=0.0, le=0.5)
    x_min: float | None = Field(default=None, ge=0.0, le=1.0)
    x_max: float | None = Field(default=None, ge=0.0, le=1.0)
    z_min: float | None = Field(default=None, ge=0.0, le=1.0)
    z_max: float | None = Field(default=None, ge=0.0, le=1.0)

    @model_validator(mode="after")
    def validate_bounds(self):
        if self.x_min is not None and self.x_max is not None and self.x_min >= self.x_max:
            raise ValueError("x_min must be lower than x_max")
        if self.z_min is not None and self.z_max is not None and self.z_min >= self.z_max:
            raise ValueError("z_min must be lower than z_max")
        if self.source.startswith("asset:") and len(self.source.split(":", 1)[1].strip()) == 0:
            raise ValueError("asset source must include an id")
        return self


class TextureProjectSpec(BaseModel):
    mode: TextureMode = "hybrid"
    regions: list[TextureRegionSpec] = Field(default_factory=list, max_length=32)
