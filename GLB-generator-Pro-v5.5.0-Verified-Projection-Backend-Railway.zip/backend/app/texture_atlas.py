"""Packed albedo/normal/ORM atlases with a single shared UV layout.

Packing a view to a cell is lossless geometrically: the Blender projector
converts each view's normalized UV into that cell before export. Its channels
are resampled with the *same transform* (never separate UVs or crop estimates).
"""
from __future__ import annotations

from pathlib import Path
from typing import Mapping
import math

from PIL import Image

from .pbr_maps import build_pbr_channels, _kind

VIEW_ORDER = (
    'front', 'back', 'left', 'right', 'front_45', 'back_45',
    'face_front', 'face_45', 'face_left_45', 'face_right_45',
    'face_left_profile', 'face_right_profile',
    'left_hand', 'right_hand', 'hair_detail', 'clothes_detail',
)


def _grid(count: int):
    # Wide grid avoids 4-by-4 unless there are > 12 views.
    columns = min(4, max(1, math.ceil(math.sqrt(count))))
    rows = math.ceil(count / columns)
    return columns, rows


def _edge_bleed(atlas: Image.Image, tile: Image.Image, x: int, y: int, pad: int) -> None:
    w, h = tile.size
    atlas.paste(tile, (x, y))
    # Always replicate outer texels into gutters; never interpolate with
    # neutral neighboring channels (visible rectangular color seams).
    atlas.paste(tile.crop((0, 0, 1, h)).resize((pad, h)), (x - pad, y))
    atlas.paste(tile.crop((w - 1, 0, w, h)).resize((pad, h)), (x + w, y))
    atlas.paste(tile.crop((0, 0, w, 1)).resize((w, pad)), (x, y - pad))
    atlas.paste(tile.crop((0, h - 1, w, h)).resize((w, pad)), (x, y + h))
    for box, dst in [((0, 0, 1, 1), (x-pad, y-pad)),
                     ((w-1, 0, w, 1), (x+w, y-pad)),
                     ((0, h-1, 1, h), (x-pad, y+h)),
                     ((w-1, h-1, w, h), (x+w, y+h))]:
        atlas.paste(tile.crop(box).resize((pad, pad)), dst)


def build_projection_atlas(
    images: Mapping[str, Path], output_dir: Path, *, max_size: int = 3072,
) -> dict:
    ordered = [(k, Path(images[k])) for k in VIEW_ORDER if k in images and Path(images[k]).is_file()]
    # Some legacy importer tests pass placeholder bytes rather than actual
    # JPEG data; preserve the old per-view route for unsupported image files.
    readable = []
    for name, path in ordered:
        try:
            with Image.open(path) as src:
                src.verify()
            readable.append((name, path))
        except (OSError, ValueError):
            continue
    ordered = readable
    if not ordered:
        return {}
    max_size = max(512, min(8192, int(max_size)))
    columns, rows = _grid(len(ordered))
    # Dimensions are exact integer multiples to avoid rounding across UV layers.
    pad = 4
    cell = max(16, max_size // max(columns, rows))
    width, height = cell * columns, cell * rows
    content = cell - 2 * pad
    albedo = Image.new('RGB', (width, height), (184, 184, 184))
    normal = Image.new('RGB', (width, height), (128, 128, 255))
    orm = Image.new('RGB', (width, height), (255, 194, 0))
    rects: dict[str, list[float]] = {}
    for index, (name, path) in enumerate(ordered):
        col, row = index % columns, index // columns
        x, y = col * cell + pad, row * cell + pad
        with Image.open(path) as raw:
            photo = raw.convert('RGB')
        # All PBR channels derive from *the exact color pixels projected*.
        photo = photo.resize((content, content), Image.Resampling.LANCZOS)
        map_normal, _, _, map_orm = build_pbr_channels(photo, _kind(name))
        _edge_bleed(albedo, photo, x, y, pad)
        _edge_bleed(normal, map_normal, x, y, pad)
        _edge_bleed(orm, map_orm, x, y, pad)
        # glTF/Blender UV origin is bottom-left, Pillow atlas origin top-left.
        # A half-pixel inset prevents linear filtering outside the source tile.
        rects[name] = [(x + .5) / width, (height - y - content + .5) / height,
                       (x + content - .5) / width, (height - y - .5) / height]
    output_dir.mkdir(parents=True, exist_ok=True)
    paths = {channel: output_dir / f'pbr_atlas_{channel}.png'
             for channel in ('albedo', 'normal', 'orm')}
    for channel, img in [('albedo', albedo), ('normal', normal), ('orm', orm)]:
        img.save(paths[channel], format='PNG', optimize=True)
        img.close()
    return {**{k: str(p.resolve()) for k, p in paths.items()},
            'rects': rects, 'width': width, 'height': height,
            'gutter_px': pad, 'version': 1}
