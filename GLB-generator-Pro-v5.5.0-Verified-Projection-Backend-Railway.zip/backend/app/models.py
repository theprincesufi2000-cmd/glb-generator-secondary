from __future__ import annotations

from typing import Optional

from pydantic import BaseModel


class JobResponse(BaseModel):
    job_id: str
    status: str
    progress: int
    message: str
    provider: Optional[str] = None
    attempt_count: int = 0
    last_error: Optional[str] = None
    created_at: str
    updated_at: str
    model_url: Optional[str] = None


class V3JobResponse(BaseModel):
    job_id: str
    status: str
    progress: int
    message: str
    provider: Optional[str] = None
    attempt_count: int = 0
    last_error: Optional[str] = None
    created_at: str
    updated_at: str
    quality_mode: str = "pro_hq"
    remesh: bool = False
    preview_url: Optional[str] = None
    high_quality_url: Optional[str] = None


class V4JobResponse(V3JobResponse):
    generation_mode: str = "auto"
    output_mode: str = "full_glb"
    texture_mode: str = "auto"
    local_fallback_required: bool = False
    mesh_url: Optional[str] = None


class HealthResponse(BaseModel):
    ok: bool
    service: str
    version: str
