"""Quality gates for genuinely usable multi-view baked atlases.

The previous structural GLB validator passed deformed textures solely because
there was one UV set and three PBR images. This module checks the actual bake.
No structural or confidence metric can prove identity-level photo alignment:
visual verification and calibrated camera/landmark correspondences remain essential.
"""
from __future__ import annotations


def assess_bake_metrics(metrics: dict, *, min_coverage: float = 0.95,
                        max_sub_2px_fraction: float = 0.55) -> dict:
    total = int(metrics.get('mesh_covered_pixels', 0))
    valid = int(metrics.get('valid_pixels', 0))
    triangles = int(metrics.get('triangle_count', 0))
    micro = int(metrics.get('sub_2px_triangle_count', 0))
    ratio = min(1., valid/max(1, total))
    micro_ratio = micro/max(1, triangles)
    issues: list[str] = []
    if total < 128:
        issues.append('Almost no pixels in atlas map to the mesh UVs')
    if ratio < min_coverage:
        issues.append(f'Photographic UV coverage only {ratio:.1%}; minimum {min_coverage:.0%}')
    if triangles > 0 and micro_ratio > max_sub_2px_fraction:
        issues.append(f'{micro_ratio:.1%} of UV triangles occupy less than 2 pixels; increase atlas resolution')
    if triangles <= 0:
        issues.append('Missing UV triangle density metrics')
    # Extra requirements apply only to v5.5 strict photo projection reports.
    # An atlas with nearly full coverage can still contain visibly misplaced
    # faces, wrong clothing and overlapping islands: coverage is NOT accuracy.
    if metrics.get('strict_projection'):
        if not metrics.get('calibration_verified'):
            issues.append('Image/mesh geometry was not calibrated and verified')
        if metrics.get('visibility_mode') != 'per_texel_bvh':
            issues.append('Occlusion validation must be applied at UV texel level')
        if metrics.get('conflicting_texels', 0) / max(1, total) > .005:
            issues.append(f"Photometric disagreements on {int(metrics['conflicting_texels'])} UV texels")
        if metrics.get('overlapping_uv_texels', 0) / max(1, total) > .002:
            issues.append(f"UV overlaps on {int(metrics['overlapping_uv_texels'])} UV texels")
    return {'quality_ok': not issues,
            'covered_ratio': round(ratio, 5),
            'sub_2px_triangle_fraction': round(micro_ratio, 5),
            'issues': issues}
