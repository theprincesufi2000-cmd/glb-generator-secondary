"""Validate opt-in 2D/3D landmark correspondence payloads."""
from __future__ import annotations
import math
from pydantic import BaseModel, Field, field_validator
from .multiview_core import DIRECTIONS


class LandmarkPair(BaseModel):
    # XYZ are world-space coordinates in the imported GLB geometry system.
    world_xyz: tuple[float, float, float]
    # Image UV starts TOP-left. UV=0,0 is the image top-left corner.
    image_uv: tuple[float, float]

    @field_validator('world_xyz', 'image_uv')
    @classmethod
    def finite(cls, value):
        if not all(math.isfinite(float(v)) for v in value):
            raise ValueError('Landmark values must be finite')
        return value

    @field_validator('image_uv')
    @classmethod
    def unit_interval(cls, value):
        if any(float(v) < 0 or float(v) > 1 for v in value):
            raise ValueError('Image landmarks must be in [0,1]')
        return value


class CalibrationProject(BaseModel):
    # Explicit matches are optional; otherwise a silhouette calibration is used.
    landmarks: dict[str, list[LandmarkPair]] = Field(default_factory=dict)

    @field_validator('landmarks')
    @classmethod
    def known_views(cls, value):
        if any(key not in DIRECTIONS for key in value):
            raise ValueError('Unknown camera direction')
        if any(len(pairs) > 32 for pairs in value.values()):
            raise ValueError('No more than 32 landmarks per direction')
        if sum(map(len, value.values())) > 128:
            raise ValueError('Too many landmarks')
        return value
