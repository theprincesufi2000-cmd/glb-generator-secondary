from __future__ import annotations

from pathlib import Path
from PIL import Image, ImageFilter, ImageOps


def _brighten_if_dark(image: Image.Image) -> Image.Image:
    rgb = image.convert('RGB')
    stat = ImageOps.grayscale(rgb)
    mean = sum(stat.getdata()) / float(stat.width * stat.height)
    if mean < 18.0:
        rgb = ImageOps.autocontrast(rgb)
    return rgb


def _fill_black(image: Image.Image) -> Image.Image:
    rgb = image.convert('RGB')
    bg = rgb.filter(ImageFilter.GaussianBlur(radius=10))
    out = Image.new('RGB', rgb.size)
    px = rgb.load()
    bpx = bg.load()
    opx = out.load()
    for y in range(rgb.height):
        for x in range(rgb.width):
            r, g, b = px[x, y]
            if r < 8 and g < 8 and b < 8:
                opx[x, y] = bpx[x, y]
            else:
                opx[x, y] = (r, g, b)
    return out


def clean_projection_texture(source: Path, target: Path, *, face: bool = False, max_size: int | None = None) -> Path:
    target.parent.mkdir(parents=True, exist_ok=True)
    with Image.open(source) as im:
        rgb = im.convert('RGB')
        if max_size and max(rgb.size) > int(max_size):
            ratio = int(max_size) / float(max(rgb.size))
            rgb = rgb.resize((max(1, round(rgb.width * ratio)), max(1, round(rgb.height * ratio))), Image.Resampling.LANCZOS)
        # Subject exterior was already filled from a true alpha matte in
        # imagefit. Do not modify nearly-black pixels: hair, dark trousers,
        # pupils and eyelash details would otherwise be blurred into patches.
        rgb = _brighten_if_dark(rgb)
        if face:
            rgb = rgb.filter(ImageFilter.UnsharpMask(radius=1.2, percent=135, threshold=2))
        else:
            rgb = rgb.filter(ImageFilter.UnsharpMask(radius=0.8, percent=110, threshold=3))
        if target.suffix.lower() == '.png':
            rgb.save(target, format='PNG', optimize=True)
        else:
            rgb.save(target, format='JPEG', quality=96, subsampling=0)
    return target
