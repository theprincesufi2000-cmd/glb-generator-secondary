# GLB Generator Pro Backend v4.7.0

# GLB generator Pro v3 backend

Durable FastAPI + Blender 4.5 backend for GLB generator Pro v3.0.

The backend accepts four required views plus optional 45-degree and face closeups, stores them on persistent disk, runs Hunyuan multi-view geometry, refines the mesh in headless Blender, and stores both `preview.glb` and `high_quality.glb`.

## Pro HQ defaults

- Railway 1 GB memory profile is the safe default.
- HQ body projection textures: up to 1280 px per view.
- HQ face closeups: up to 2048 px per view.
- HQ triangle budget: 150,000.
- Preview texture target: up to 1024 px.
- Preview triangle budget: 60,000.
- Optional voxel remesh.
- Provider retry window is configurable.
- `2gb` and `high` memory profiles raise the mesh/texture budgets on larger workers.

A persistent volume must be mounted at `/data`. The included Dockerfile uses `blenderkit/headless-blender:blender-4.5-stable` and installs FastAPI dependencies in the same container so the worker can invoke Blender directly.

Required production variables include `GLB_CLIENT_TOKEN`, `GLB_PUBLIC_BASE_URL`, and `GLB_DATA_DIR=/data`. Texture sizes and Blender timeout can be overridden through `GLB_*` environment variables.

Run tests with:

```bash
cd ..
PYTHONPATH=backend python3 -m pytest backend/tests -q
```


### Blender memory profiles
`GLB_BLENDER_MEMORY_PROFILE=1gb` is the safe default for Railway 1 GB workers. It caps HQ geometry and projection textures before GLB export while preserving the original `base.glb` and source photos. `2gb` and `high` profiles raise the limits on larger workers.


## v4.7.0 Pro Fidelity additions
- New quality mode: `pro_fidelity` for cloud texture refinement.
- Added staged geometry repair helpers (`geometry_repair.py`) and watertight shell settings.
- Added segmented UV policy and separate face/body projection planning.
- Added projection texture cleanup to reduce black texels before Blender import.
- Blender script now supports a fuller shell pass before projection to reduce hollow interiors.
