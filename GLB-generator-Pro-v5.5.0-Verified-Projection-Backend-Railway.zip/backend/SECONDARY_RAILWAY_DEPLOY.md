# Secondary Railway deployment — v5.2.5 verified runtime

## Production service

- GitHub source: `theprincesufi2000-cmd/glb-generator-secondary`
- Public backend: `https://glb-generator-secondary-github-production.up.railway.app`
- Health endpoint: `/health`
- Container port: `8000`

## Verified deployment

The production deployment is built from a Dockerfile based on
`blenderkit/headless-blender:blender-4.5-stable`. The inherited VNC entrypoint is
explicitly cleared with `ENTRYPOINT []`, so Uvicorn is the foreground API process.

The deployed backend source bundle is reconstructed during the Docker build and
verified with SHA-256 before extraction. This avoids runtime base64/environment
variable corruption and prevents a deployment from reporting success while only
the VNC desktop process is running.

Expected health response:

```json
{"ok": true, "service": "glb-generator-pro-backend", "version": "5.1.2"}
```

## Android routing contract

- `AUTO`: Primary Railway -> Secondary Railway -> phone fallback.
- `CLOUD_ONLY`: Primary Railway -> Secondary Railway only. Never phone fallback.
- `LOCAL_ONLY`: phone directly.

The Android app stores Secondary jobs with an `s--` prefix locally so polling,
download, cancel, retry and resume remain routed to the backend that owns the job.
